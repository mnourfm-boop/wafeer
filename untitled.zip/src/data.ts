export const STORES = [
  { 
    id: 1, 
    name: "Noon", 
    nameAr: "نون", 
    discount: "خصم 10%", 
    code: "NOON50", 
    link: "https://noon.com", 
    logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e3/Noon_Logo.svg/320px-Noon_Logo.svg.png",
    expiryDate: "2026-07-20",
  },
  { 
    id: 2, 
    name: "Namshi", 
    nameAr: "نمشي", 
    discount: "خصم حتى 50%", 
    code: "NAM20", 
    link: "https://namshi.com", 
    logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/c/cd/Namshi_Logo.svg/320px-Namshi_Logo.svg.png",
    expiryDate: "2026-08-15",
  },
  { 
    id: 3, 
    name: "Amazon", 
    nameAr: "أمازون", 
    discount: "شحن مجاني", 
    code: "AMZFS", 
    link: "https://amazon.sa", 
    logo: "https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg",
    expiryDate: "2026-07-18",
  },
  { 
    id: 4, 
    name: "Nike", 
    nameAr: "نايكي", 
    discount: "خصم 30%", 
    code: "NIKE10", 
    link: "https://nike.com", 
    logo: "https://upload.wikimedia.org/wikipedia/commons/a/a6/Logo_NIKE.svg",
    expiryDate: "",
  },
  { 
    id: 5, 
    name: "H&M", 
    nameAr: "اتش اند ام", 
    discount: "خصم 15% إضافي", 
    code: "HM900", 
    link: "https://hm.com", 
    logo: "https://upload.wikimedia.org/wikipedia/commons/5/53/H%26M-Logo.svg",
    expiryDate: "2026-07-16",
  },
];

export const ARTICLES = [
  { 
    id: 1, 
    title: "كيف تختار أفضل كود خصم في الجمعة البيضاء؟", 
    titleEn: "How to choose the best coupon in Black Friday?", 
    text: "دليل شامل لتحقيق أقصى استفادة من عروض نهاية العام. هناك أوقات معينة في السنة تكون فيها التخفيضات في أعلى مستوياتها، مثل البلاك فرايداي ونهاية العام. احرص على تخطيط مشترياتك في هذه المواسم للحصول على أفضل الصفقات. نوصيك باستخدام كود خصم نون الحصري المرفق مع هذا المقال للحصول على خصم إضافي رائع عند إتمام الدفع.",
    hasCoupon: true,
    storeId: "1",
    customStoreName: "Noon",
    customStoreLogo: "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e3/Noon_Logo.svg/320px-Noon_Logo.svg.png",
    countryFlag: "🇸🇦",
    couponCode: "NOON50",
    referralLink: "https://noon.com",
    discountText: "خصم 10% إضافي في نون"
  },
  { 
    id: 2, 
    title: "أسرار استخدام كوبونات الخصم بفعالية", 
    titleEn: "Secrets of using discount coupons effectively", 
    text: "لا تكتفِ بكوبون واحد. أحياناً يمكنك دمج كوبون الخصم مع العروض الترويجية الحالية للمتجر للحصول على خصم مضاعف. ابحث دائماً عن العروض التي تمنحك شحناً مجانياً مع الخصم.",
    hasCoupon: false,
    storeId: "custom",
    customStoreName: "",
    customStoreLogo: "",
    countryFlag: "🌎",
    couponCode: "",
    referralLink: "",
    discountText: ""
  }
];

export const SOCIAL_LINKS = {
  twitter: "https://twitter.com",
  instagram: "https://instagram.com",
  facebook: "https://facebook.com",
  whatsappGroup: "https://chat.whatsapp.com/your-group-link"
};
