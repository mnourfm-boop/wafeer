/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Helmet, HelmetProvider } from 'react-helmet-async';
import useEmblaCarousel from 'embla-carousel-react';
import { 
  Moon, 
  Sun, 
  Globe, 
  Search, 
  Volume2, 
  Check, 
  MessageCircle, 
  Instagram, 
  Twitter, 
  Facebook, 
  ExternalLink, 
  Copy, 
  Settings, 
  Plus, 
  Trash2, 
  RotateCcw, 
  ChevronLeft, 
  ChevronRight, 
  ChevronDown,
  X, 
  Sliders, 
  Edit3,
  BookOpen,
  Sparkles,
  Wand2,
  Gauge,
  AlertTriangle,
  Info,
  Camera,
  LayoutGrid,
  Youtube,
  Send,
  Share2,
  Lock,
  Unlock,
  Key,
  LogOut,
  Mail,
  Phone,
  Clock,
  MapPin,
  ArrowUp,
  Watch,
  Laptop,
  Sofa,
  Shirt,
  Tv,
  Utensils,
  Heart,
  BriefcaseMedical,
  Baby,
  Gem,
  Plane,
  Dumbbell,
  Gift,
  Palette,
  Smartphone,
  Keyboard,
  Crown,
  Cpu,
  Armchair,
  ShoppingBag,
  Coffee,
  Pizza,
  Flower2,
  HeartPulse,
  Smile,
  Trophy,
  Wind,
  Brush
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { STORES as INITIAL_STORES, ARTICLES as INITIAL_ARTICLES, SOCIAL_LINKS as INITIAL_SOCIAL_LINKS } from './data';
import { PrivacyPolicyPage, AboutUsPage, ContactUsPage } from './components/Pages';
import { StoreDetailsPage } from './components/StoreDetailsPage';
import KeywordDensityChecker from './components/KeywordDensityChecker';
import SEOTools from './components/SEOTools';

// Translations
const t = {
  ar: {
    title: "وفير - أفضل كوبونات الخصم للمتاجر العربية",
    description: "احصل على أحدث الكوبونات وعروض الخصم الحصرية لأشهر المتاجر في السعودية والخليج.",
    heroTitle: "أكبر منصة لكوبونات الخصم العربية",
    heroSub: "وفر أموالك وتسوق بذكاء مع أحدث الكوبونات المحدثة يومياً",
    searchPlaceholder: "ابحث عن متجر...",
    searchBtn: "بحث ذكي",
    copyCode: "نسخ الكوبون",
    copied: "تم النسخ!",
    goToStore: "الذهاب للمتجر",
    latestOffers: "أحدث العروض",
    joinWhatsapp: "انضم لجروب الواتساب للعروض الحصرية",
    readArticle: "اقرأ المقال",
    articles: "مقالات التسوق الذكي",
    footerText: "جميع الحقوق محفوظة © 2026 منصة وفير",
    adminPanel: "لوحة تحكم القالب",
    editMode: "تفعيل وضع التعديل البصري",
    addStore: "إضافة متجر جديد",
    addArticle: "إضافة مقال جديد",
    resetColors: "إعادة تعيين الألوان الافتراضية",
    colorsLight: "ألوان المظهر المضيء",
    colorsDark: "ألوان المظهر الداكن",
    primaryColor: "اللون الرئيسي (البراند)",
    bgColor: "لون الخلفية",
    cardColor: "لون البطاقات والعناصر",
    textColor: "لون النصوص الأساسية",
    borderColor: "لون الحدود والفواصل",
    socialTitle: "تعديل روابط التواصل",
    saveSuccess: "تم الحفظ بنجاح!",
    deleteConfirm: "هل أنت متأكد من الحذف؟",
    storeNameEn: "اسم المتجر بالإنجليزية",
    storeNameAr: "اسم المتجر بالعربية",
    discountPercent: "نسبة أو قيمة الخصم",
    couponCode: "كود الكوبون",
    storeLink: "رابط المتجر الإلكتروني",
    logoUrl: "رابط صورة شعار المتجر",
    articleTitleAr: "عنوان المقال بالعربية",
    articleTitleEn: "عنوان المقال بالإنجليزية",
    articleContent: "محتوى المقال الكامل",
    expiryDate: "تاريخ انتهاء الكوبون (YYYY-MM-DD)",
    expiringSoon: "ينتهي قريباً ⏰",
    submitAdd: "إضافة الآن",
    noStores: "لا توجد متاجر مضافة حالياً.",
  },
  en: {
    title: "Wafeer - Best Coupon Codes for Arab Stores",
    description: "Get the latest exclusive coupons and discount offers for the most famous stores in Saudi Arabia and the Gulf.",
    heroTitle: "The Largest Arab Coupons Platform",
    heroSub: "Save money and shop smarter with daily updated coupons",
    searchPlaceholder: "Search for a store...",
    searchBtn: "Smart Search",
    copyCode: "Copy Code",
    copied: "Copied!",
    goToStore: "Go to Store",
    latestOffers: "Latest Offers",
    joinWhatsapp: "Join our WhatsApp for exclusive deals",
    readArticle: "Read Article",
    articles: "Smart Shopping Articles",
    footerText: "All rights reserved © 2026 Wafeer",
    adminPanel: "Template Control Panel",
    editMode: "Enable Visual Edit Mode",
    addStore: "Add New Store",
    addArticle: "Add New Article",
    resetColors: "Reset to Default Colors",
    colorsLight: "Light Theme Colors",
    colorsDark: "Dark Theme Colors",
    primaryColor: "Primary Color",
    bgColor: "Background Color",
    cardColor: "Card & Elements Color",
    textColor: "Primary Text Color",
    borderColor: "Border & Divider Color",
    socialTitle: "Edit Social Links",
    saveSuccess: "Saved successfully!",
    deleteConfirm: "Are you sure you want to delete?",
    storeNameEn: "Store Name (EN)",
    storeNameAr: "Store Name (AR)",
    discountPercent: "Discount Info (e.g. 20% OFF)",
    couponCode: "Coupon Code",
    storeLink: "Store Website URL",
    logoUrl: "Store Logo Image URL",
    articleTitleAr: "Article Title (AR)",
    articleTitleEn: "Article Title (EN)",
    articleContent: "Article Content",
    expiryDate: "Coupon Expiry Date (YYYY-MM-DD)",
    expiringSoon: "Expiring Soon ⏰",
    submitAdd: "Add Entry",
    noStores: "No stores currently added.",
  }
};

const DEFAULT_COLORS = {
  primary: '#059669',
  bg: '#f8fafc',
  card: '#ffffff',
  text: '#0f172a',
  border: '#e2e8f0',
  headerBg: '#ffffff',
  footerBg: '#064e3b',
  heroBgStart: '#059669',
  heroBgEnd: '#047857',
  sliderCardBg: '#ffffff',
  sliderCardText: '#0f172a',

  darkPrimary: '#10b981',
  darkBg: '#0f172a',
  darkCard: '#1e293b',
  darkText: '#f8fafc',
  darkBorder: '#334155',
  darkHeaderBg: '#1e293b',
  darkFooterBg: '#090d16',
  darkHeroBgStart: '#111827',
  darkHeroBgEnd: '#065f46',
  darkSliderCardBg: '#1e293b',
  darkSliderCardText: '#f8fafc',
};

const PALETTES = [
  {
    nameAr: "البنفسجي الإمبراطوري",
    nameEn: "Imperial Purple",
    colors: {
      primary: '#6366f1',
      bg: '#f8fafc',
      card: '#ffffff',
      text: '#0f172a',
      border: '#e2e8f0',
      headerBg: '#ffffff',
      footerBg: '#0f172a',
      heroBgStart: '#4f46e5',
      heroBgEnd: '#4338ca',
      sliderCardBg: '#ffffff',
      sliderCardText: '#0f172a',
      darkPrimary: '#818cf8',
      darkBg: '#0f172a',
      darkCard: '#1e293b',
      darkText: '#f8fafc',
      darkBorder: '#334155',
      darkHeaderBg: '#1e293b',
      darkFooterBg: '#020617',
      darkHeroBgStart: '#1e1b4b',
      darkHeroBgEnd: '#311042',
      darkSliderCardBg: '#1e293b',
      darkSliderCardText: '#f8fafc',
    }
  },
  {
    nameAr: "الذهب الصحراوي الدافئ",
    nameEn: "Golden Desert",
    colors: {
      primary: '#d97706',
      bg: '#fffbeb',
      card: '#ffffff',
      text: '#1e293b',
      border: '#fde68a',
      headerBg: '#fffdf5',
      footerBg: '#451a03',
      heroBgStart: '#d97706',
      heroBgEnd: '#92400e',
      sliderCardBg: '#fef3c7',
      sliderCardText: '#78350f',
      darkPrimary: '#fbbf24',
      darkBg: '#1c1917',
      darkCard: '#292524',
      darkText: '#f5f5f4',
      darkBorder: '#44403c',
      darkHeaderBg: '#292524',
      darkFooterBg: '#0c0a09',
      darkHeroBgStart: '#451a03',
      darkHeroBgEnd: '#292524',
      darkSliderCardBg: '#44403c',
      darkSliderCardText: '#fef3c7',
    }
  },
  {
    nameAr: "الزمرد الملكي الموثوق",
    nameEn: "Royal Emerald",
    colors: {
      primary: '#059669',
      bg: '#f0fdf4',
      card: '#ffffff',
      text: '#0f172a',
      border: '#bbf7d0',
      headerBg: '#f6fdf9',
      footerBg: '#064e3b',
      heroBgStart: '#059669',
      heroBgEnd: '#047857',
      sliderCardBg: '#dcfce7',
      sliderCardText: '#14532d',
      darkPrimary: '#34d399',
      darkBg: '#061c15',
      darkCard: '#0b2e24',
      darkText: '#ecfdf5',
      darkBorder: '#14532d',
      darkHeaderBg: '#0b2e24',
      darkFooterBg: '#020a07',
      darkHeroBgStart: '#064e3b',
      darkHeroBgEnd: '#042f22',
      darkSliderCardBg: '#0f4435',
      darkSliderCardText: '#dcfce7',
    }
  },
  {
    nameAr: "الأزرق الكلاسيكي الهادئ",
    nameEn: "Classic Blue",
    colors: {
      primary: '#2563eb',
      bg: '#f8fafc',
      card: '#ffffff',
      text: '#0f172a',
      border: '#e2e8f0',
      headerBg: '#ffffff',
      footerBg: '#1e3a8a',
      heroBgStart: '#2563eb',
      heroBgEnd: '#1d4ed8',
      sliderCardBg: '#eff6ff',
      sliderCardText: '#1e3a8a',
      darkPrimary: '#60a5fa',
      darkBg: '#0b1329',
      darkCard: '#132247',
      darkText: '#f8fafc',
      darkBorder: '#1e293b',
      darkHeaderBg: '#132247',
      darkFooterBg: '#050a14',
      darkHeroBgStart: '#111827',
      darkHeroBgEnd: '#1e3a8a',
      darkSliderCardBg: '#132247',
      darkSliderCardText: '#eff6ff',
    }
  },
  {
    nameAr: "ياقوت التوفير الناري",
    nameEn: "Ruby Spark",
    colors: {
      primary: '#dc2626',
      bg: '#fff5f5',
      card: '#ffffff',
      text: '#0f172a',
      border: '#fee2e2',
      headerBg: '#fffafa',
      footerBg: '#7f1d1d',
      heroBgStart: '#dc2626',
      heroBgEnd: '#b91c1c',
      sliderCardBg: '#fee2e2',
      sliderCardText: '#7f1d1d',
      darkPrimary: '#f87171',
      darkBg: '#180404',
      darkCard: '#2c0c0c',
      darkText: '#fef2f2',
      darkBorder: '#4c1d1d',
      darkHeaderBg: '#2c0c0c',
      darkFooterBg: '#0f0202',
      darkHeroBgStart: '#7f1d1d',
      darkHeroBgEnd: '#3f0c0c',
      darkSliderCardBg: '#4c1d1d',
      darkSliderCardText: '#fee2e2',
    }
  },
  {
    nameAr: "الغروب المرجاني الجريء",
    nameEn: "Coral Sunset",
    colors: {
      primary: '#f97316',
      bg: '#fff7ed',
      card: '#ffffff',
      text: '#1e293b',
      border: '#ffedd5',
      headerBg: '#fffbf7',
      footerBg: '#7c2d12',
      heroBgStart: '#f97316',
      heroBgEnd: '#ea580c',
      sliderCardBg: '#ffedd5',
      sliderCardText: '#7c2d12',
      darkPrimary: '#fb923c',
      darkBg: '#1c0a02',
      darkCard: '#2d1508',
      darkText: '#fff7ed',
      darkBorder: '#431407',
      darkHeaderBg: '#2d1508',
      darkFooterBg: '#0f0400',
      darkHeroBgStart: '#7c2d12',
      darkHeroBgEnd: '#431407',
      darkSliderCardBg: '#431407',
      darkSliderCardText: '#ffedd5',
    }
  },
  {
    nameAr: "الغابة النعناعية الهادئة",
    nameEn: "Mint Forest",
    colors: {
      primary: '#0d9488',
      bg: '#f0fdfa',
      card: '#ffffff',
      text: '#111827',
      border: '#ccfbf1',
      headerBg: '#f5fdfb',
      footerBg: '#115e59',
      heroBgStart: '#0d9488',
      heroBgEnd: '#0f766e',
      sliderCardBg: '#ccfbf1',
      sliderCardText: '#115e59',
      darkPrimary: '#2dd4bf',
      darkBg: '#021a17',
      darkCard: '#052e2a',
      darkText: '#f0fdfa',
      darkBorder: '#115e59',
      darkHeaderBg: '#052e2a',
      darkFooterBg: '#000c0a',
      darkHeroBgStart: '#115e59',
      darkHeroBgEnd: '#042f2e',
      darkSliderCardBg: '#0a423d',
      darkSliderCardText: '#ccfbf1',
    }
  },
  {
    nameAr: "الياقوت الأزرق الملكي",
    nameEn: "Royal Sapphire",
    colors: {
      primary: '#4f46e5',
      bg: '#eef2ff',
      card: '#ffffff',
      text: '#0f172a',
      border: '#c7d2fe',
      headerBg: '#f5f7ff',
      footerBg: '#312e81',
      heroBgStart: '#4f46e5',
      heroBgEnd: '#3730a3',
      sliderCardBg: '#e0e7ff',
      sliderCardText: '#1e1b4b',
      darkPrimary: '#818cf8',
      darkBg: '#030712',
      darkCard: '#111827',
      darkText: '#f9fafb',
      darkBorder: '#1f2937',
      darkHeaderBg: '#111827',
      darkFooterBg: '#030712',
      darkHeroBgStart: '#1e1b4b',
      darkHeroBgEnd: '#0f172a',
      darkSliderCardBg: '#1e293b',
      darkSliderCardText: '#e0e7ff',
    }
  },
  {
    nameAr: "منتصف الليل السيبراني",
    nameEn: "Cyber Midnight",
    colors: {
      primary: '#ec4899',
      bg: '#fdf2f8',
      card: '#ffffff',
      text: '#0f172a',
      border: '#fbcfe8',
      headerBg: '#fdf2f8',
      footerBg: '#831843',
      heroBgStart: '#ec4899',
      heroBgEnd: '#db2777',
      sliderCardBg: '#fbcfe8',
      sliderCardText: '#831843',
      darkPrimary: '#f472b6',
      darkBg: '#18000a',
      darkCard: '#2d0014',
      darkText: '#fdf2f8',
      darkBorder: '#500025',
      darkHeaderBg: '#2d0014',
      darkFooterBg: '#100005',
      darkHeroBgStart: '#831843',
      darkHeroBgEnd: '#500025',
      darkSliderCardBg: '#500025',
      darkSliderCardText: '#fbcfe8',
    }
  },
  {
    nameAr: "الموكا الذهبية الفاخرة",
    nameEn: "Golden Mocha",
    colors: {
      primary: '#854d0e',
      bg: '#fefcbf',
      card: '#ffffff',
      text: '#451a03',
      border: '#fef08a',
      headerBg: '#fffbeb',
      footerBg: '#422006',
      heroBgStart: '#a16207',
      heroBgEnd: '#854d0e',
      sliderCardBg: '#fef3c7',
      sliderCardText: '#451a03',
      darkPrimary: '#eab308',
      darkBg: '#1c1917',
      darkCard: '#292524',
      darkText: '#fefcbf',
      darkBorder: '#422006',
      darkHeaderBg: '#292524',
      darkFooterBg: '#0c0a09',
      darkHeroBgStart: '#422006',
      darkHeroBgEnd: '#1c1917',
      darkSliderCardBg: '#422006',
      darkSliderCardText: '#fef3c7',
    }
  },
  {
    nameAr: "خزامى الخزائن الراقي",
    nameEn: "Royal Lavender",
    colors: {
      primary: '#8b5cf6',
      bg: '#faf5ff',
      card: '#ffffff',
      text: '#2e1065',
      border: '#e9d5ff',
      headerBg: '#fdfafe',
      footerBg: '#4c1d95',
      heroBgStart: '#8b5cf6',
      heroBgEnd: '#6d28d9',
      sliderCardBg: '#f3e8ff',
      sliderCardText: '#4c1d95',
      darkPrimary: '#a78bfa',
      darkBg: '#0f051d',
      darkCard: '#1e0b36',
      darkText: '#faf5ff',
      darkBorder: '#4c1d95',
      darkHeaderBg: '#1e0b36',
      darkFooterBg: '#080110',
      darkHeroBgStart: '#4c1d95',
      darkHeroBgEnd: '#2e1065',
      darkSliderCardBg: '#3b0764',
      darkSliderCardText: '#e9d5ff',
    }
  },
  {
    nameAr: "الورد الوردي المخملي",
    nameEn: "Rose Gold Velvet",
    colors: {
      primary: '#db2777',
      bg: '#fff1f2',
      card: '#ffffff',
      text: '#4c0519',
      border: '#ffe4e6',
      headerBg: '#fff5f6',
      footerBg: '#881337',
      heroBgStart: '#db2777',
      heroBgEnd: '#be185d',
      sliderCardBg: '#ffe4e6',
      sliderCardText: '#881337',
      darkPrimary: '#f472b6',
      darkBg: '#1c020a',
      darkCard: '#300412',
      darkText: '#fff1f2',
      darkBorder: '#881337',
      darkHeaderBg: '#300412',
      darkFooterBg: '#0e0004',
      darkHeroBgStart: '#881337',
      darkHeroBgEnd: '#4c0519',
      darkSliderCardBg: '#4c0519',
      darkSliderCardText: '#ffe4e6',
    }
  },
  {
    nameAr: "فيروز الشواطئ الساحر",
    nameEn: "Coastal Turquoise",
    colors: {
      primary: '#06b6d4',
      bg: '#ecfeff',
      card: '#ffffff',
      text: '#083344',
      border: '#cffafe',
      headerBg: '#f2fefe',
      footerBg: '#164e63',
      heroBgStart: '#06b6d4',
      heroBgEnd: '#0891b2',
      sliderCardBg: '#cffafe',
      sliderCardText: '#164e63',
      darkPrimary: '#22d3ee',
      darkBg: '#02181e',
      darkCard: '#042d38',
      darkText: '#ecfeff',
      darkBorder: '#164e63',
      darkHeaderBg: '#042d38',
      darkFooterBg: '#010c0f',
      darkHeroBgStart: '#164e63',
      darkHeroBgEnd: '#083344',
      darkSliderCardBg: '#083344',
      darkSliderCardText: '#cffafe',
    }
  }
];

// Brand Logos
const NoonLogo = () => (
  <div className="w-full h-full bg-[#FFE600] flex items-center justify-center font-black rounded-lg select-none p-1">
    <div className="flex flex-col items-center justify-center leading-none">
      <span className="text-[17px] text-black tracking-tighter" style={{ fontFamily: 'system-ui, sans-serif' }}>noon</span>
      <span className="text-[9px] text-[#00E08F] font-bold" style={{ marginTop: '-1px' }}>نون</span>
    </div>
  </div>
);

const NamshiLogo = () => (
  <div className="w-full h-full bg-black flex items-center justify-center rounded-lg select-none p-1.5">
    <div className="flex flex-col items-center justify-center leading-none">
      <span className="text-[12px] font-black text-white tracking-widest uppercase">NAMSHI</span>
      <span className="text-[8px] text-white/85 font-medium mt-0.5">نمشي</span>
    </div>
  </div>
);

const AmazonLogo = () => (
  <div className="w-full h-full flex flex-col items-center justify-center select-none bg-white p-1">
    <span className="text-[14px] font-black text-slate-900 leading-none">amazon</span>
    <svg className="w-10 h-2 text-[#FF9900]" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 6" xmlns="http://www.w3.org/2000/svg">
      <path d="M2 2c5 3 15 3 20 0" strokeLinecap="round" />
      <path d="M19 1.5l3 .5-1.5 2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  </div>
);

const NikeLogo = () => (
  <div className="w-full h-full flex items-center justify-center select-none bg-white p-1">
    <svg className="w-12 h-12 text-black animate-none" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
      <path d="M21 6.5c-2.3 1.8-6.1 4.3-9.5 5.7-2.8 1.1-5.3 1.3-6.4.7-.6-.3-.7-1-.3-1.8.4-.9 1.5-2.2 2.8-3.5 1.1-1.1 2.2-2 2.6-2.2.3-.2.3-.4 0-.4-.5 0-2.2.9-4.2 2.5-2.2 1.8-4.2 4.3-4.9 6.2-.5 1.4-.2 2.6.9 3.2 1.4.8 4.4.5 8.2-1.1 3.9-1.6 8.3-4.8 10.9-7.5.3-.3.1-.6-.1-.3z" />
    </svg>
  </div>
);

const HMLogo = () => (
  <div className="w-full h-full flex items-center justify-center select-none bg-white p-1">
    <span className="text-[16px] font-extrabold text-[#E5001C] tracking-tighter italic" style={{ fontFamily: 'Georgia, serif' }}>H&M</span>
  </div>
);

interface StoreLogoProps {
  logo: string;
  name: string;
  nameAr?: string;
  className?: string;
}

const StoreLogo = ({ logo, name, nameAr, className = "max-w-full max-h-full object-contain" }: StoreLogoProps) => {
  const [imgError, setImgError] = useState(false);

  const cleanName = (name || '').toLowerCase().trim();
  const isDefaultWikimedia = logo && (logo.includes('wikimedia.org') || logo.includes('wikipedia'));

  if (!logo || imgError || isDefaultWikimedia) {
    if (cleanName.includes('noon') || nameAr?.includes('نون')) {
      return <NoonLogo />;
    }
    if (cleanName.includes('namshi') || nameAr?.includes('نمشي')) {
      return <NamshiLogo />;
    }
    if (cleanName.includes('amazon') || nameAr?.includes('أمازون')) {
      return <AmazonLogo />;
    }
    if (cleanName.includes('nike') || nameAr?.includes('نايكي')) {
      return <NikeLogo />;
    }
    if (cleanName.includes('h&m') || cleanName.includes('hm') || nameAr?.includes('اتش اند ام')) {
      return <HMLogo />;
    }
    return (
      <div className="w-full h-full bg-primary/10 text-primary flex items-center justify-center font-black rounded-lg text-sm uppercase">
        {name ? name.substring(0, 2) : 'C'}
      </div>
    );
  }

  return (
    <img 
      src={logo} 
      alt={name} 
      className={className} 
      onError={() => setImgError(true)} 
      referrerPolicy="no-referrer" 
      loading="lazy"
    />
  );
};

const CATEGORIES = [
  { id: 'all', nameAr: 'جميع الفئات', nameEn: 'All Categories', icon: LayoutGrid, imgUrl: 'https://cdn.jsdelivr.net/gh/microsoft/fluentui-emoji@main/assets/Grid/3D/grid_3d.png' },
  { id: 'watches', nameAr: 'ساعات واكسسوارات', nameEn: 'Watches & Accessories', icon: Crown, imgUrl: 'https://cdn.jsdelivr.net/gh/microsoft/fluentui-emoji@main/assets/Watch/3D/watch_3d.png' },
  { id: 'electronics', nameAr: 'الكترونيات', nameEn: 'Electronics', icon: Cpu, imgUrl: 'https://cdn.jsdelivr.net/gh/microsoft/fluentui-emoji@main/assets/Laptop/3D/laptop_3d.png' },
  { id: 'furniture', nameAr: 'الأثاث ومستلزمات المنزل', nameEn: 'Furniture & Home supplies', icon: Armchair, imgUrl: 'https://cdn.jsdelivr.net/gh/microsoft/fluentui-emoji@main/assets/Couch%20and%20lamp/3D/couch_and_lamp_3d.png' },
  { id: 'fashion', nameAr: 'ازياء', nameEn: 'Fashion', icon: ShoppingBag, imgUrl: 'https://cdn.jsdelivr.net/gh/microsoft/fluentui-emoji@main/assets/T-shirt/3D/t-shirt_3d.png' },
  { id: 'appliances', nameAr: 'اجهزة منزلية', nameEn: 'Home Appliances', icon: Coffee, imgUrl: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=150&h=150&q=80' },
  { id: 'food', nameAr: 'أكل و توصيل', nameEn: 'Food & Delivery', icon: Pizza, imgUrl: 'https://cdn.jsdelivr.net/gh/microsoft/fluentui-emoji@main/assets/Pizza/3D/pizza_3d.png' },
  { id: 'personal_care', nameAr: 'مستلزمات العناية الشخصية', nameEn: 'Personal Care', icon: Flower2, imgUrl: 'https://cdn.jsdelivr.net/gh/microsoft/fluentui-emoji@main/assets/Soap/3D/soap_3d.png' },
  { id: 'medical', nameAr: 'مستلزمات طبية', nameEn: 'Medical Supplies', icon: HeartPulse, imgUrl: 'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=150&h=150&q=80' },
  { id: 'baby', nameAr: 'مستلزمات اطفال', nameEn: 'Baby Supplies', icon: Smile, imgUrl: 'https://images.unsplash.com/photo-1519689680058-324335c77eba?auto=format&fit=crop&w=150&h=150&q=80' },
  { id: 'jewelry', nameAr: 'مجوهرات', nameEn: 'Jewelry', icon: Gem, imgUrl: 'https://cdn.jsdelivr.net/gh/microsoft/fluentui-emoji@main/assets/Gem%20stone/3D/gem_stone_3d.png' },
  { id: 'travel', nameAr: 'فنادق و حجز تذاكر طيران', nameEn: 'Hotels & Flights', icon: Plane, imgUrl: 'https://cdn.jsdelivr.net/gh/microsoft/fluentui-emoji@main/assets/Airplane/3D/airplane_3d.png' },
  { id: 'perfumes', nameAr: 'عطور', nameEn: 'Perfumes', icon: Wind, imgUrl: 'https://cdn.jsdelivr.net/gh/microsoft/fluentui-emoji@main/assets/Lotion%20bottle/3D/lotion_bottle_3d.png' },
  { id: 'sports', nameAr: 'ملابس رياضية و احذية', nameEn: 'Sportswear & Shoes', icon: Trophy, imgUrl: 'https://cdn.jsdelivr.net/gh/microsoft/fluentui-emoji@main/assets/Running%20shoe/3D/running_shoe_3d.png' },
  { id: 'gifts', nameAr: 'هدايا', nameEn: 'Gifts', icon: Gift, imgUrl: 'https://cdn.jsdelivr.net/gh/microsoft/fluentui-emoji@main/assets/Wrapped%20gift/3D/wrapped_gift_3d.png' },
  { id: 'makeup', nameAr: 'ميك اب', nameEn: 'Makeup', icon: Brush, imgUrl: 'https://cdn.jsdelivr.net/gh/microsoft/fluentui-emoji@main/assets/Lipstick/3D/lipstick_3d.png' },
  { id: 'mobiles', nameAr: 'موبايلات', nameEn: 'Mobiles', icon: Smartphone, imgUrl: 'https://cdn.jsdelivr.net/gh/microsoft/fluentui-emoji@main/assets/Mobile%20phone/3D/mobile_phone_3d.png' }
];

const COUNTRIES = [
  { id: 'all', flag: '🌐', nameAr: 'كل الدول', nameEn: 'All Countries' },
  { id: 'sa', flag: '🇸🇦', nameAr: 'السعودية', nameEn: 'Saudi Arabia' },
  { id: 'eg', flag: '🇪🇬', nameAr: 'مصر', nameEn: 'Egypt' },
  { id: 'ae', flag: '🇦🇪', nameAr: 'الإمارات', nameEn: 'UAE' },
  { id: 'kw', flag: '🇰🇼', nameAr: 'الكويت', nameEn: 'Kuwait' },
  { id: 'bh', flag: '🇧🇭', nameAr: 'البحرين', nameEn: 'Bahrain' },
  { id: 'qa', flag: '🇶🇦', nameAr: 'قطر', nameEn: 'Qatar' },
  { id: 'om', flag: '🇴🇲', nameAr: 'عمان', nameEn: 'Oman' }
];

const COUNTRIES_MAP: Record<string, { flag: string; nameAr: string; nameEn: string }> = {
  all: { flag: '🌐', nameAr: 'كل الدول', nameEn: 'All Countries' },
  sa: { flag: '🇸🇦', nameAr: 'السعودية', nameEn: 'Saudi Arabia' },
  eg: { flag: '🇪🇬', nameAr: 'مصر', nameEn: 'Egypt' },
  ae: { flag: '🇦🇪', nameAr: 'الإمارات', nameEn: 'UAE' },
  kw: { flag: '🇰🇼', nameAr: 'الكويت', nameEn: 'Kuwait' },
  bh: { flag: '🇧🇭', nameAr: 'البحرين', nameEn: 'Bahrain' },
  qa: { flag: '🇶🇦', nameAr: 'قطر', nameEn: 'Qatar' },
  om: { flag: '🇴🇲', nameAr: 'عمان', nameEn: 'Oman' }
};

const getIconHoverAnimation = (id: string) => {
  switch (id) {
    case 'all': return { rotate: [0, -10, 10, -10, 10, 0], scale: 1.15, transition: { duration: 0.5 } };
    case 'watches': return { rotate: [0, -15, 15, -10, 10, 0], transition: { duration: 0.6 } };
    case 'electronics': return { scale: [1, 1.2, 1, 1.2, 1], transition: { duration: 1, repeat: Infinity } };
    case 'furniture': return { y: [0, -4, 0], transition: { repeat: Infinity, duration: 1.6, ease: "easeInOut" } };
    case 'fashion': return { rotate: [0, -12, 12, -8, 8, 0], transition: { duration: 0.6 } };
    case 'appliances': return { y: [0, -2, 0], scale: [1, 1.1, 1], transition: { repeat: Infinity, duration: 1.2 } };
    case 'food': return { rotate: 360, scale: 1.15, transition: { type: "spring", stiffness: 120, damping: 10 } };
    case 'personal_care': return { rotate: 90, scale: 1.15, transition: { duration: 0.4 } };
    case 'medical': return { scale: [1, 1.25, 1, 1.25, 1], transition: { repeat: Infinity, duration: 1 } };
    case 'baby': return { y: [0, -8, 0], transition: { type: "spring", stiffness: 300, damping: 8 } };
    case 'jewelry': return { scale: 1.2, rotate: 15, transition: { duration: 0.3 } };
    case 'travel': return { x: [0, 8, -4, 0], y: [0, -6, 2, 0], transition: { duration: 1.2, ease: "easeInOut" } };
    case 'perfumes': return { x: [0, 6, -6, 0], transition: { repeat: Infinity, duration: 1.5 } };
    case 'sports': return { y: [0, -6, 0], scale: 1.15, transition: { duration: 0.3 } };
    case 'gifts': return { scale: 1.15, rotate: [0, -15, 15, -10, 10, 0], transition: { duration: 0.5 } };
    case 'makeup': return { rotate: [0, -25, 25, 0], transition: { duration: 0.5 } };
    case 'mobiles': return { rotate: [0, -10, 10, -10, 10, 0], transition: { repeat: Infinity, duration: 0.25 } };
    default: return { scale: 1.1 };
  }
};

const getExpiryStatus = (expiryDateStr: string | undefined | null): 'expiring_soon' | 'expired' | 'normal' | 'none' => {
  if (!expiryDateStr) return 'none';
  try {
    const expiryDate = new Date(expiryDateStr);
    if (isNaN(expiryDate.getTime())) return 'none';
    
    const now = new Date();
    // Normalize both to date-only at local midnight for accurate day-to-day difference
    const todayOnly = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const expiryOnly = new Date(expiryDate.getFullYear(), expiryDate.getMonth(), expiryDate.getDate());
    
    const diffTime = expiryOnly.getTime() - todayOnly.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 3600 * 24));
    
    if (diffDays < 0) {
      return 'expired';
    } else if (diffDays >= 0 && diffDays <= 3) {
      return 'expiring_soon';
    } else {
      return 'normal';
    }
  } catch (e) {
    return 'none';
  }
};

const isHotDeal = (discountStr: string | undefined | null): boolean => {
  if (!discountStr) return false;
  try {
    const matches = discountStr.match(/\d+/);
    if (matches) {
      const num = parseInt(matches[0], 10);
      return num >= 15;
    }
    const lower = discountStr.toLowerCase();
    return discountStr.includes('٪') || discountStr.includes('%') || lower.includes('خصم') || lower.includes('off') || lower.includes('توفير') || lower.includes('free');
  } catch (e) {
    return false;
  }
};

export default function App() {
  const [lang, setLang] = useState<'ar'|'en'>('ar');

  // Dynamic Content States backed by localStorage
  const [stores, setStores] = useState(() => {
    const saved = localStorage.getItem('custom_stores');
    const parsed = saved ? JSON.parse(saved) : INITIAL_STORES;
    const healed = parsed.map((store: any) => {
      if (!store.logo || store.logo === 'https://upload.wikimedia.org/wikipedia/commons/4/4b/Noon-logo.png' || store.logo.includes('Noon-logo.png')) {
        return { ...store, logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e3/Noon_Logo.svg/320px-Noon_Logo.svg.png' };
      }
      if (store.logo === 'https://upload.wikimedia.org/wikipedia/commons/5/52/Namshi_Logo.png' || store.logo.includes('Namshi_Logo.png')) {
        return { ...store, logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/cd/Namshi_Logo.svg/320px-Namshi_Logo.svg.png' };
      }
      return store;
    });
    return healed;
  });

  const [articles, setArticles] = useState(() => {
    const saved = localStorage.getItem('custom_articles');
    const parsed = saved ? JSON.parse(saved) : INITIAL_ARTICLES;
    const healed = parsed.map((art: any) => {
      if (art.customStoreLogo === 'https://upload.wikimedia.org/wikipedia/commons/4/4b/Noon-logo.png' || art.customStoreLogo?.includes('Noon-logo.png')) {
        return { ...art, customStoreLogo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e3/Noon_Logo.svg/320px-Noon_Logo.svg.png' };
      }
      return art;
    });
    return healed;
  });

  const [colors, setColors] = useState(() => {
    const saved = localStorage.getItem('custom_colors');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        // Self-heal/migrate: if they were using the old muddy green background, migrate them to the brand new elegant dark theme!
        if (parsed.darkBg === '#022c22') {
          parsed.darkPrimary = '#10b981';
          parsed.darkBg = '#0f172a';
          parsed.darkCard = '#1e293b';
          parsed.darkText = '#f8fafc';
          parsed.darkBorder = '#334155';
          parsed.darkHeaderBg = '#1e293b';
          parsed.darkFooterBg = '#090d16';
          parsed.darkHeroBgStart = '#111827';
          parsed.darkHeroBgEnd = '#065f46';
          parsed.darkSliderCardBg = '#1e293b';
          parsed.darkSliderCardText = '#f8fafc';
          localStorage.setItem('custom_colors', JSON.stringify(parsed));
        }
        return parsed;
      } catch (e) {
        return DEFAULT_COLORS;
      }
    }
    return DEFAULT_COLORS;
  });

  const [socialLinks, setSocialLinks] = useState<any[]>(() => {
    const saved = localStorage.getItem('custom_social_links_v3');
    if (saved) return JSON.parse(saved);
    
    // Check if custom_social_links_v2 has saved state
    const oldSaved = localStorage.getItem('custom_social_links_v2');
    if (oldSaved) {
      const parsed = JSON.parse(oldSaved);
      // Migrate and ensure TikTok is added
      if (Array.isArray(parsed) && !parsed.some((s: any) => s.platform === 'tiktok')) {
        parsed.push({ id: '5', nameAr: 'تيك توك', nameEn: 'TikTok', url: 'https://tiktok.com', platform: 'tiktok' });
      }
      return parsed;
    }

    // Fallback migration from old format or default
    const oldSavedLegacy = localStorage.getItem('custom_social_links');
    const source = oldSavedLegacy ? JSON.parse(oldSavedLegacy) : INITIAL_SOCIAL_LINKS;
    
    return [
      { id: '1', nameAr: 'تويتر (إكس)', nameEn: 'Twitter (X)', url: source?.twitter || 'https://twitter.com', platform: 'twitter' },
      { id: '2', nameAr: 'إنستغرام', nameEn: 'Instagram', url: source?.instagram || 'https://instagram.com', platform: 'instagram' },
      { id: '3', nameAr: 'فيسبوك', nameEn: 'Facebook', url: source?.facebook || 'https://facebook.com', platform: 'facebook' },
      { id: '4', nameAr: 'جروب واتساب', nameEn: 'WhatsApp Group', url: source?.whatsappGroup || 'https://chat.whatsapp.com/your-group-link', platform: 'whatsapp' },
      { id: '5', nameAr: 'تيك توك', nameEn: 'TikTok', url: 'https://tiktok.com', platform: 'tiktok' },
    ];
  });

  // Adsense Configurations
  const [adConfig, setAdConfig] = useState(() => {
    const saved = localStorage.getItem('custom_ad_config');
    const defaults = {
      showAds: true,
      adClientId: 'ca-pub-1234567890123456',
      adSlotId: '9876543210',
      adBannerUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=1200&auto=format&fit=crop',
      showSideAd: true,
      sideAdBannerUrl: 'https://images.unsplash.com/photo-1511556532299-8f662fc26c06?q=80&w=400&auto=format&fit=crop',
      sideAdLink: 'https://google.com',
      showBottomAd: true,
      bottomAdBannerUrl: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?q=80&w=1200&auto=format&fit=crop',
      bottomAdLink: 'https://google.com',
    };
    if (saved) {
      const parsed = JSON.parse(saved);
      return {
        ...defaults,
        ...parsed,
        showSideAd: parsed.showSideAd !== undefined ? parsed.showSideAd : true,
        showBottomAd: parsed.showBottomAd !== undefined ? parsed.showBottomAd : true,
      };
    }
    return defaults;
  });

  const [isStoresDropdownOpen, setIsStoresDropdownOpen] = useState(false);
  const [isCategoriesDropdownOpen, setIsCategoriesDropdownOpen] = useState(false);
  const [theme, setTheme] = useState<'light'|'dark'>('light');
  const [copiedId, setCopiedId] = useState<number|null>(null);
  const [failedImages, setFailedImages] = useState<Record<string, boolean>>({});
  
  // Search state
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<string>('');
  const [isSearching, setIsSearching] = useState(false);
  const [selectedStoreFilter, setSelectedStoreFilter] = useState<string | null>(null);
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string | null>(null);
  const [selectedCountryFilter, setSelectedCountryFilter] = useState<string | null>(() => {
    return localStorage.getItem('selected_country_filter') || 'all';
  });
  const [storeSortOption, setStoreSortOption] = useState<'newest' | 'discount' | 'alphabetical'>(() => {
    return (localStorage.getItem('store_sort_option') as any) || 'newest';
  });
  const [faqOpenIndex, setFaqOpenIndex] = useState<number | null>(null);

  // Hero section customizable slideshow slides state
  const [heroSlides, setHeroSlides] = useState<any[]>(() => {
    const saved = localStorage.getItem('custom_hero_slides');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    
    // Default slides
    return [
      {
        id: 'slide-1',
        titleAr: 'أكبر منصة لكوبونات الخصم العربية',
        titleEn: 'The Largest Arab Coupons Platform',
        subAr: 'وفر أموالك وتسوق بذكاء مع أحدث الكوبونات المحدثة يومياً',
        subEn: 'Save money and shop smarter with daily updated coupons',
        bgType: 'image',
        solidColor: '#4f46e5',
        bgImageUrl: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?q=80&w=1200&auto=format&fit=crop',
        panDirection: 'right', // 'right' | 'left'
      },
      {
        id: 'slide-2',
        titleAr: 'تخفيضات تصل إلى 70% على الماركات العالمية',
        titleEn: 'Discounts up to 70% on Global Brands',
        subAr: 'احصل على أكواد خصم حصرية لأشهر المتاجر الإلكترونية مثل نون ونمشي وأمازون',
        subEn: 'Get exclusive discount codes for popular e-stores like Noon, Namshi, and Amazon',
        bgType: 'image',
        solidColor: '#0ea5e9',
        bgImageUrl: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?q=80&w=1200&auto=format&fit=crop',
        panDirection: 'left',
      },
      {
        id: 'slide-3',
        titleAr: 'تسوّق بذكاء ووفر كاش مع كل عملية شراء',
        titleEn: 'Shop Smart & Save Cash on Every Purchase',
        subAr: 'ابحث عن متجرك المفضل واكتشف العروض الترويجية والخصومات الفورية الموثوقة',
        subEn: 'Search for your favorite store and discover trusted instant promos & discounts',
        bgType: 'image',
        solidColor: '#10b981',
        bgImageUrl: 'https://images.unsplash.com/photo-1472851294608-062f824d296e?q=80&w=1200&auto=format&fit=crop',
        panDirection: 'right',
      }
    ];
  });

  const [activeSlide, setActiveSlide] = useState(0);
  const [selectedSlideEditIndex, setSelectedSlideEditIndex] = useState(0);
  const [copiedStoreName, setCopiedStoreName] = useState<string | null>(null);

  const saveHeroSlides = (newSlides: any[]) => {
    setHeroSlides(newSlides);
    localStorage.setItem('custom_hero_slides', JSON.stringify(newSlides));
  };

  const heroConfig = heroSlides[selectedSlideEditIndex] || heroSlides[0];
  const saveHeroConfig = (newCfg: any) => {
    const updated = [...heroSlides];
    updated[selectedSlideEditIndex] = newCfg;
    saveHeroSlides(updated);
  };

  const handleAddHeroSlide = () => {
    const newSlideId = `slide-${Date.now()}`;
    const newSlide = {
      id: newSlideId,
      titleAr: 'عنوان الشريحة الجديدة 🏷️',
      titleEn: 'New Slide Title 🏷️',
      subAr: 'وصف فرعي للشريحة الجديدة هنا للترويج لأفضل العروض والمتاجر الحصرية والتخفيضات اليومية',
      subEn: 'New slide subtitle text here to promote top stores, exclusive offers, and daily deals',
      bgType: 'gradient',
      solidColor: '#4f46e5',
      bgImageUrl: '',
      panDirection: 'right',
    };
    const updated = [...heroSlides, newSlide];
    saveHeroSlides(updated);
    setSelectedSlideEditIndex(updated.length - 1);
    setActiveSlide(updated.length - 1);
    pushNotification(
      'deal',
      `تمت إضافة شريحة بانر جديدة للهيرو بنجاح!`,
      `New Hero slide banner added successfully!`
    );
  };

  const handleDeleteHeroSlide = (idxToDelete: number) => {
    if (heroSlides.length <= 1) return;
    const updated = heroSlides.filter((_, idx) => idx !== idxToDelete);
    saveHeroSlides(updated);
    const nextIdx = Math.max(0, idxToDelete - 1);
    setSelectedSlideEditIndex(nextIdx);
    setActiveSlide(nextIdx);
    pushNotification(
      'deal',
      `تم حذف شريحة البانر المحددة بنجاح.`,
      `Selected Hero slide banner deleted successfully.`
    );
  };

  // Contacts & Footer Customization
  const [contactPhone, setContactPhone] = useState(() => {
    return localStorage.getItem('contact_phone') || '+966 54 231 9876';
  });
  const [contactEmail, setContactEmail] = useState(() => {
    return localStorage.getItem('contact_email') || 'mnour.fm@gmail.com';
  });

  const [contactBannerUrl, setContactBannerUrl] = useState(() => {
    return localStorage.getItem('contact_banner_url') || 'https://images.unsplash.com/photo-1616077168712-fc6c788bc4ee?q=80&w=1200&auto=format&fit=crop';
  });
  const [contactLogoUrl, setContactLogoUrl] = useState(() => {
    return localStorage.getItem('contact_logo_url') || 'https://cdn.jsdelivr.net/gh/microsoft/fluentui-emoji@main/assets/Money%20bag/3D/money_bag_3d.png';
  });

  const saveContactBannerUrl = (val: string) => {
    setContactBannerUrl(val);
    localStorage.setItem('contact_banner_url', val);
  };

  const saveContactLogoUrl = (val: string) => {
    setContactLogoUrl(val);
    localStorage.setItem('contact_logo_url', val);
  };

  const saveContactPhone = (val: string) => {
    setContactPhone(val);
    localStorage.setItem('contact_phone', val);
  };

  const saveContactEmail = (val: string) => {
    setContactEmail(val);
    localStorage.setItem('contact_email', val);
  };

  // Fully Editable Footer States
  const [footerDescAr, setFooterDescAr] = useState(() => {
    return localStorage.getItem('footer_desc_ar') || 'منصتكم الأولى للحصول على أحدث كوبونات وأكواد الخصم الحصرية لأشهر المتاجر الإلكترونية العربية والعالمية. نوفر لك تصفحاً ذكياً وموثوقاً لتسوق موفر!';
  });
  const [footerDescEn, setFooterDescEn] = useState(() => {
    return localStorage.getItem('footer_desc_en') || 'Your premier platform for the latest and exclusive coupons & discount codes for famous Arab and international online stores. Shop smarter and save more with us.';
  });
  const [footerLinksTitleAr, setFooterLinksTitleAr] = useState(() => {
    return localStorage.getItem('footer_links_title_ar') || 'روابط واتصل بنا';
  });
  const [footerLinksTitleEn, setFooterLinksTitleEn] = useState(() => {
    return localStorage.getItem('footer_links_title_en') || 'Links & Contact Us';
  });
  const [footerLocationAr, setFooterLocationAr] = useState(() => {
    return localStorage.getItem('footer_location_ar') || 'الرياض، السعودية';
  });
  const [footerLocationEn, setFooterLocationEn] = useState(() => {
    return localStorage.getItem('footer_location_en') || 'Riyadh, KSA';
  });
  const [footerSocialTitleAr, setFooterSocialTitleAr] = useState(() => {
    return localStorage.getItem('footer_social_title_ar') || 'تابعنا على منصات التواصل';
  });
  const [footerSocialTitleEn, setFooterSocialTitleEn] = useState(() => {
    return localStorage.getItem('footer_social_title_en') || 'Follow us';
  });
  const [footerSocialDescAr, setFooterSocialDescAr] = useState(() => {
    return localStorage.getItem('footer_social_desc_ar') || 'تابع حساباتنا الرسمية لتصلك أقوى صفقات الخصم اليومية الحصرية.';
  });
  const [footerSocialDescEn, setFooterSocialDescEn] = useState(() => {
    return localStorage.getItem('footer_social_desc_en') || 'Follow our official accounts to get the top daily exclusive discounts.';
  });
  const [footerCopyrightTextAr, setFooterCopyrightTextAr] = useState(() => {
    return localStorage.getItem('footer_copyright_text_ar') || 'صنع بكل ❤️ لعشاق التسوق';
  });
  const [footerCopyrightTextEn, setFooterCopyrightTextEn] = useState(() => {
    return localStorage.getItem('footer_copyright_text_en') || 'Made with ❤️ for shopping lovers';
  });
  const [footerCopyrightCompany, setFooterCopyrightCompany] = useState(() => {
    return localStorage.getItem('footer_copyright_company') || 'Wafeer';
  });

  const saveFooterState = (key: string, value: string, setter: (val: string) => void) => {
    setter(value);
    localStorage.setItem(key, value);
  };

  // Interactive Benefit Tabs
  const [benefitTabs, setBenefitTabs] = useState<any[]>(() => {
    const saved = localStorage.getItem('custom_benefit_tabs_v2');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return [
      {
        id: 'tab-1',
        titleAr: '💡 دليل التوفير السريع',
        titleEn: '💡 Quick Saving Guide',
        descAr: 'خطوات بسيطة تضمن لك الحصول على أعلى خصم ممكن مع كل عملية شراء مجاناً.',
        descEn: 'Simple steps to ensure you get the maximum possible discount with every purchase.',
        step1Ar: 'ابحث عن متجرك المفضل في خانة البحث الذكي بأعلى الصفحة.',
        step1En: 'Search for your favorite store in the smart search above.',
        step2Ar: 'اختر الكود المناسب ثم اضغط "نسخ الكوبون" ليتم نسخه تلقائياً.',
        step2En: 'Choose the best code and click "Copy Coupon" to copy it instantly.',
        step3Ar: 'الصق الكود في خانة الرمز الترويجي عند الدفع واستمتع بالتوفير!',
        step3En: 'Paste the code in the promo code box at checkout and enjoy savings!',
      },
      {
        id: 'tab-2',
        titleAr: '🧮 حاسبة التوفير الفوري',
        titleEn: '🧮 Instant Savings Calculator',
        descAr: 'احسب قيمة توفيرك المتوقعة ونسبة الخصم مباشرة قبل إتمام عملية التسوق.',
        descEn: 'Calculate your expected savings and discount amount instantly before shopping.',
      },
      {
        id: 'tab-3',
        titleAr: '🛡️ نصائح تسوق ذكية',
        titleEn: '🛡️ Smart Shopping Tips',
        descAr: 'أسرار وحيل تساعدك على تجنب رسوم التوصيل والحصول على كاش باك حقيقي.',
        descEn: 'Secrets and tips to help you avoid shipping fees and get real cash back.',
        tip1Ar: 'تسوّق دائماً في مواسم التخفيضات الكبرى واستخدم الكوبونات التراكمية.',
        tip1En: 'Always shop during major sales seasons and use stackable coupons.',
        tip2Ar: 'تأكد من قراءة تفاصيل الكوبون لمعرفة المتاجر المشمولة والحد الأدنى للطلب.',
        tip2En: 'Make sure to read coupon details to find covered stores and minimum orders.',
        tip3Ar: 'فعّل الإشعارات وانضم لمجموعاتنا لتصلك أكواد الخصم السريعة والمحدودة.',
        tip3En: 'Enable notifications and join our groups to get fast, limited discount codes.',
      }
    ];
  });

  const saveBenefitTabs = (newTabs: any[]) => {
    setBenefitTabs(newTabs);
    localStorage.setItem('custom_benefit_tabs_v2', JSON.stringify(newTabs));
  };

  const [activeBenefitTabIdx, setActiveBenefitTabIdx] = useState(0);
  const [selectedBenefitTabEditIdx, setSelectedBenefitTabEditIdx] = useState(0);

  // WhatsApp floating widget open state
  const [isWhatsappWidgetOpen, setIsWhatsappWidgetOpen] = useState(false);

  // Scroll to Top state
  const [showScrollTop, setShowScrollTop] = useState(false);

  // Track scroll position to show/hide "Back to Top" button
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 400) {
        setShowScrollTop(true);
      } else {
        setShowScrollTop(false);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Auto-slide effect for hero slides
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveSlide((prev) => (prev + 1) % heroSlides.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [heroSlides.length]);

  // Admin Control Panel States
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [activeAdminTab, setActiveAdminTab] = useState<'colors' | 'stores' | 'articles' | 'social' | 'ads' | 'seo_checker' | 'ai_writer' | 'hero' | 'benefits' | 'messages' | 'seo_metadata' | 'footer_config'>('colors');

  // Visitor messages for "Contact Us" form submission
  const [visitorMessages, setVisitorMessages] = useState<any[]>(() => {
    const saved = localStorage.getItem('visitor_messages');
    return saved ? JSON.parse(saved) : [
      {
        id: 1,
        name: 'أحمد الحربي',
        email: 'ahmad@example.com',
        subject: 'استفسار عن كود خصم نون',
        message: 'السلام عليكم، كود الخصم الخاص بنون لا يعمل على جميع المنتجات، هل تتوفر أكواد جديدة تشمل كل السلع؟ وشكراً لكم على جهودكم الرائعة.',
        date: '2026-07-15 14:30'
      }
    ];
  });

  useEffect(() => {
    localStorage.setItem('visitor_messages', JSON.stringify(visitorMessages));
  }, [visitorMessages]);

  // SEO metadata states for custom indexing optimization
  const [seoTitleAr, setSeoTitleAr] = useState(() => localStorage.getItem('seo_title_ar') || 'وفير - أفضل كوبونات الخصم للمتاجر العربية');
  const [seoTitleEn, setSeoTitleEn] = useState(() => localStorage.getItem('seo_title_en') || 'Wafeer - Best Coupon Codes for Arab Stores');
  const [seoDescAr, setSeoDescAr] = useState(() => localStorage.getItem('seo_desc_ar') || 'احصل على أحدث الكوبونات وعروض الخصم الحصرية لأشهر المتاجر في السعودية والخليج.');
  const [seoDescEn, setSeoDescEn] = useState(() => localStorage.getItem('seo_desc_en') || 'Get the latest exclusive coupons and discount offers for the most famous stores in Saudi Arabia and the Gulf.');
  const [seoKeywordsAr, setSeoKeywordsAr] = useState(() => localStorage.getItem('seo_keywords_ar') || 'كوبون خصم، كود خصم، تخفيضات، وفير، عروض المتاجر، نون، نمشي، أمازون');
  const [seoKeywordsEn, setSeoKeywordsEn] = useState(() => localStorage.getItem('seo_keywords_en') || 'coupon codes, discount code, promo code, save money, wafeer, noon, namshi, amazon');

  const [googleVerificationCode, setGoogleVerificationCode] = useState(() => localStorage.getItem('google_verification_code') || '');
  const [bingVerificationCode, setBingVerificationCode] = useState(() => localStorage.getItem('bing_verification_code') || '');

  const [isPinging, setIsPinging] = useState(false);
  const [pingLogs, setPingLogs] = useState<string[]>([]);

  useEffect(() => { localStorage.setItem('seo_title_ar', seoTitleAr); }, [seoTitleAr]);
  useEffect(() => { localStorage.setItem('seo_title_en', seoTitleEn); }, [seoTitleEn]);
  useEffect(() => { localStorage.setItem('seo_desc_ar', seoDescAr); }, [seoDescAr]);
  useEffect(() => { localStorage.setItem('seo_desc_en', seoDescEn); }, [seoDescEn]);
  useEffect(() => { localStorage.setItem('seo_keywords_ar', seoKeywordsAr); }, [seoKeywordsAr]);
  useEffect(() => { localStorage.setItem('seo_keywords_en', seoKeywordsEn); }, [seoKeywordsEn]);
  useEffect(() => { localStorage.setItem('google_verification_code', googleVerificationCode); }, [googleVerificationCode]);
  useEffect(() => { localStorage.setItem('bing_verification_code', bingVerificationCode); }, [bingVerificationCode]);

  const isConfigLoadedRef = useRef(false);

  // Fetch the configuration from the backend server on startup to support true server-side persistence for visitors
  useEffect(() => {
    const fetchConfigFromServer = async () => {
      try {
        const res = await fetch('/api/get-seo-config');
        if (res.ok) {
          const data = await res.json();
          if (data.stores) setStores(data.stores);
          if (data.articles) setArticles(data.articles);
          if (data.seoTitleAr) setSeoTitleAr(data.seoTitleAr);
          if (data.seoTitleEn) setSeoTitleEn(data.seoTitleEn);
          if (data.seoDescAr) setSeoDescAr(data.seoDescAr);
          if (data.seoDescEn) setSeoDescEn(data.seoDescEn);
          if (data.seoKeywordsAr) setSeoKeywordsAr(data.seoKeywordsAr);
          if (data.seoKeywordsEn) setSeoKeywordsEn(data.seoKeywordsEn);
          if (data.colors) setColors(data.colors);
          if (data.heroSlides) setHeroSlides(data.heroSlides);
          if (data.contactPhone) setContactPhone(data.contactPhone);
          if (data.contactEmail) setContactEmail(data.contactEmail);
          if (data.contactBannerUrl) setContactBannerUrl(data.contactBannerUrl);
          if (data.contactLogoUrl) setContactLogoUrl(data.contactLogoUrl);
          if (data.footerDescAr) setFooterDescAr(data.footerDescAr);
          if (data.footerDescEn) setFooterDescEn(data.footerDescEn);
          if (data.footerLinksTitleAr) setFooterLinksTitleAr(data.footerLinksTitleAr);
          if (data.footerLinksTitleEn) setFooterLinksTitleEn(data.footerLinksTitleEn);
          if (data.footerLocationAr) setFooterLocationAr(data.footerLocationAr);
          if (data.footerLocationEn) setFooterLocationEn(data.footerLocationEn);
          if (data.footerSocialTitleAr) setFooterSocialTitleAr(data.footerSocialTitleAr);
          if (data.footerSocialTitleEn) setFooterSocialTitleEn(data.footerSocialTitleEn);
          if (data.footerSocialDescAr) setFooterSocialDescAr(data.footerSocialDescAr);
          if (data.footerSocialDescEn) setFooterSocialDescEn(data.footerSocialDescEn);
          if (data.footerCopyrightTextAr) setFooterCopyrightTextAr(data.footerCopyrightTextAr);
          if (data.footerCopyrightTextEn) setFooterCopyrightTextEn(data.footerCopyrightTextEn);
          if (data.footerCopyrightCompany) setFooterCopyrightCompany(data.footerCopyrightCompany);
          if (data.adConfig) setAdConfig(data.adConfig);
          if (data.socialLinks) setSocialLinks(data.socialLinks);
          if (data.googleVerificationCode) setGoogleVerificationCode(data.googleVerificationCode);
          if (data.bingVerificationCode) setBingVerificationCode(data.bingVerificationCode);
        }
      } catch (err) {
        console.warn("Could not fetch server-side configuration:", err);
      } finally {
        isConfigLoadedRef.current = true;
      }
    };
    fetchConfigFromServer();
  }, []);

  // Synchronize SEO & Sitemap metadata to backend server dynamically
  useEffect(() => {
    // Only sync if config has been loaded from server first, to avoid wiping server state with uninitialized defaults
    if (!isConfigLoadedRef.current) return;

    const syncSeoWithServer = async () => {
      try {
        await fetch('/api/save-seo-config', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            stores,
            articles,
            seoTitleAr,
            seoTitleEn,
            seoDescAr,
            seoDescEn,
            seoKeywordsAr,
            seoKeywordsEn,
            googleVerificationCode,
            bingVerificationCode,
            colors,
            heroSlides,
            contactPhone,
            contactEmail,
            contactBannerUrl,
            contactLogoUrl,
            footerDescAr,
            footerDescEn,
            footerLinksTitleAr,
            footerLinksTitleEn,
            footerLocationAr,
            footerLocationEn,
            footerSocialTitleAr,
            footerSocialTitleEn,
            footerSocialDescAr,
            footerSocialDescEn,
            footerCopyrightTextAr,
            footerCopyrightTextEn,
            footerCopyrightCompany,
            adConfig,
            socialLinks
          })
        });
      } catch (err) {
        console.warn("Could not sync configuration with backend server:", err);
      }
    };

    // Debounce slightly to avoid rapid requests during typing
    const timer = setTimeout(() => {
      syncSeoWithServer();
    }, 1500);

    return () => clearTimeout(timer);
  }, [
    stores, articles, seoTitleAr, seoTitleEn, seoDescAr, seoDescEn, seoKeywordsAr, seoKeywordsEn,
    colors, heroSlides, contactPhone, contactEmail, contactBannerUrl, contactLogoUrl,
    footerDescAr, footerDescEn, footerLinksTitleAr, footerLinksTitleEn, footerLocationAr, footerLocationEn,
    footerSocialTitleAr, footerSocialTitleEn, footerSocialDescAr, footerSocialDescEn,
    footerCopyrightTextAr, footerCopyrightTextEn, footerCopyrightCompany, adConfig, socialLinks
  ]);

  // View state for page routing
  const [currentView, setCurrentView] = useState<'home' | 'privacy' | 'about' | 'contact' | 'store'>('home');
  const [selectedStoreId, setSelectedStoreId] = useState<string | null>(null);

  useEffect(() => {
    const handleHash = () => {
      const hash = window.location.hash;
      if (hash === '#privacy') {
        setCurrentView('privacy');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } else if (hash === '#about') {
        setCurrentView('about');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } else if (hash === '#contact') {
        setCurrentView('contact');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } else if (hash.startsWith('#store-') || hash.startsWith('#store/')) {
        const storeId = hash.startsWith('#store-') ? hash.substring(7) : hash.substring(7);
        setSelectedStoreId(storeId);
        setCurrentView('store');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } else {
        setCurrentView('home');
        if (hash) {
          // Delay slightly to allow rendering
          setTimeout(() => {
            const element = document.getElementById(hash.substring(1));
            if (element) {
              element.scrollIntoView({ behavior: 'smooth' });
            }
          }, 100);
        }
      }
    };
    
    handleHash();
    window.addEventListener('hashchange', handleHash, { passive: true });
    return () => window.removeEventListener('hashchange', handleHash);
  }, []);

  // Admin Authentication States
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(() => {
    return localStorage.getItem('isAdminAuthenticated') === 'true';
  });
  const [adminPasswordVal, setAdminPasswordVal] = useState(() => {
    return localStorage.getItem('admin_password') || 'admin2026';
  });
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [inputPassword, setInputPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [newPasswordVal, setNewPasswordVal] = useState('');
  const [passwordChangeSuccess, setPasswordChangeSuccess] = useState(false);
  const [showAdminButton, setShowAdminButton] = useState(() => {
    return localStorage.getItem('showAdminTrigger') === 'true';
  });

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('admin') || urlParams.has('manage') || urlParams.has('control')) {
      localStorage.setItem('showAdminTrigger', 'true');
      setShowAdminButton(true);
      
      // Clean up URL parameter cleanly so visitors looking at their address bar don't see it
      const url = new URL(window.location.href);
      url.searchParams.delete('admin');
      url.searchParams.delete('manage');
      url.searchParams.delete('control');
      window.history.replaceState({}, '', url.pathname + url.search);
      
      // Show an animated pop toast
      const welcomeToast = {
        id: Date.now(),
        type: 'deal',
        titleAr: '🔓 تم تنشيط خيار لوحة التحكم في هذا المتصفح بنجاح!',
        titleEn: '🔓 Admin control panel successfully activated on this browser!',
        timeAr: 'الآن',
        timeEn: 'Just now',
        isRead: false
      };
      setActiveToast(welcomeToast);
      setTimeout(() => {
        setActiveToast(null);
      }, 6000);
    }
  }, []);

  // AdConfig moved to top of component to avoid Temporal Dead Zone (TDZ)

  // Notifications Queue state
  const [notifications, setNotifications] = useState<any[]>(() => {
    const saved = localStorage.getItem('custom_notifications');
    return saved ? JSON.parse(saved) : [
      {
        id: 1,
        type: 'coupon',
        titleAr: 'تمت إضافة كود خصم نون 15% الجديد (NOON99)',
        titleEn: 'New Noon 15% Coupon Code Added (NOON99)',
        timeAr: 'قبل دقيقة',
        timeEn: '1 min ago',
        isRead: false
      },
      {
        id: 2,
        type: 'article',
        titleAr: 'تم نشر مقال جديد: كيف توفر 500 ريال شهرياً عند التسوق؟',
        titleEn: 'New Article: How to save 500 SAR monthly while shopping?',
        timeAr: 'قبل ساعة',
        timeEn: '1 hour ago',
        isRead: false
      },
      {
        id: 3,
        type: 'deal',
        titleAr: 'عرض حصري: خصومات تصل إلى 70% في نمشي بمناسبة نهاية الأسبوع',
        titleEn: 'Exclusive Deal: Up to 70% Off at Namshi Weekend Sale',
        timeAr: 'قبل ساعتين',
        timeEn: '2 hours ago',
        isRead: true
      }
    ];
  });
  const [showNotifications, setShowNotifications] = useState(false);
  const [activeToast, setActiveToast] = useState<any | null>(null);
  const [copiedCouponInfo, setCopiedCouponInfo] = useState<{ code: string; storeName: string; storeLogo?: string; link: string } | null>(null);
  const [storesViewMode, setStoresViewMode] = useState<'slider' | 'grid'>(() => {
    const saved = localStorage.getItem('custom_stores_view_mode');
    return saved === 'slider' ? 'slider' : 'grid';
  });

  useEffect(() => {
    localStorage.setItem('custom_stores_view_mode', storesViewMode);
  }, [storesViewMode]);

  // Function to push a notification both into the center list & show an animated pop toast
  const pushNotification = (type: 'coupon' | 'deal' | 'article', titleAr: string, titleEn: string) => {
    const newNotif = {
      id: Date.now(),
      type,
      titleAr,
      titleEn,
      timeAr: 'الآن',
      timeEn: 'Just now',
      isRead: false
    };
    const updated = [newNotif, ...notifications];
    setNotifications(updated);
    localStorage.setItem('custom_notifications', JSON.stringify(updated));

    // Show floating toast
    setActiveToast(newNotif);
    setTimeout(() => {
      setActiveToast(null);
    }, 5000);
  };

  // Keyboard Shortcuts for Admin Tasks
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Check if Ctrl and Alt are pressed
      if (e.ctrlKey && e.altKey) {
        const key = e.key.toLowerCase();
        
        if (key === 's') {
          e.preventDefault();
          setShowAdminButton(true);
          localStorage.setItem('showAdminTrigger', 'true');
          
          if (isAdminAuthenticated) {
            setIsAdminOpen(true);
            setActiveAdminTab('stores');
            pushNotification(
              'deal',
              '📂 تم فتح تبويب إدارة المتاجر عبر اختصار لوحة المفاتيح',
              '📂 Store management tab opened via keyboard shortcut'
            );
          } else {
            setShowLoginModal(true);
            setLoginError('');
            setInputPassword('');
            localStorage.setItem('pending_admin_tab', 'stores');
            pushNotification(
              'deal',
              '🔒 يرجى تسجيل الدخول أولاً للوصول إلى لوحة المتاجر',
              '🔒 Please log in first to access stores management'
            );
          }
        } else if (key === 'n') {
          e.preventDefault();
          setShowAdminButton(true);
          localStorage.setItem('showAdminTrigger', 'true');
          
          if (isAdminAuthenticated) {
            setIsAdminOpen(true);
            setActiveAdminTab('articles');
            pushNotification(
              'deal',
              '✍️ تم فتح تبويب إدارة المقالات عبر اختصار لوحة المفاتيح',
              '✍️ SEO Articles tab opened via keyboard shortcut'
            );
          } else {
            setShowLoginModal(true);
            setLoginError('');
            setInputPassword('');
            localStorage.setItem('pending_admin_tab', 'articles');
            pushNotification(
              'deal',
              '🔒 يرجى تسجيل الدخول أولاً للوصول إلى لوحة المقالات',
              '🔒 Please log in first to access articles management'
            );
          }
        } else if (key === 'a') {
          e.preventDefault();
          setShowAdminButton(true);
          localStorage.setItem('showAdminTrigger', 'true');
          
          if (isAdminAuthenticated) {
            setIsAdminOpen(prev => !prev);
          } else {
            setShowLoginModal(true);
            setLoginError('');
            setInputPassword('');
          }
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isAdminAuthenticated]);

  // Editing Store state
  const [editingStoreId, setEditingStoreId] = useState<number | null>(null);

  // Stores and Articles states moved to top of component to avoid Temporal Dead Zone (TDZ)

  useEffect(() => {
    localStorage.setItem('custom_stores', JSON.stringify(stores));
  }, [stores]);

  useEffect(() => {
    localStorage.setItem('custom_articles', JSON.stringify(articles));
  }, [articles]);

  const isStoreInCategory = (store: any, catId: string): boolean => {
    if (catId === 'all') return true;
    if (store.category === 'all') return true;
    if (store.category === catId) return true;
    
    // Keyword dynamic fallback for smart auto-categorization
    const nameLower = (store.name || '').toLowerCase();
    const nameAr = (store.nameAr || '');
    const codeLower = (store.code || '').toLowerCase();
    const discountLower = (store.discount || '').toLowerCase();
    
    if (catId === 'fashion') {
      return nameLower.includes('namshi') || nameLower.includes('h&m') || nameLower.includes('hm') || nameAr.includes('نمشي') || nameAr.includes('اتش') || nameLower.includes('nike') || nameAr.includes('نايكي');
    }
    if (catId === 'sports') {
      return nameLower.includes('nike') || nameLower.includes('adidas') || nameAr.includes('نايكي') || nameAr.includes('اديداس') || codeLower.includes('nike') || discountLower.includes('رياض');
    }
    if (catId === 'electronics') {
      return nameLower.includes('noon') || nameLower.includes('amazon') || nameAr.includes('نون') || nameAr.includes('أمازون');
    }
    if (catId === 'mobiles') {
      return nameLower.includes('noon') || nameLower.includes('amazon') || nameAr.includes('نون') || nameAr.includes('أمازون') || nameLower.includes('apple') || nameLower.includes('samsung');
    }
    if (catId === 'appliances') {
      return nameLower.includes('amazon') || nameAr.includes('أمازون');
    }
    if (catId === 'watches') {
      return nameLower.includes('namshi') || nameAr.includes('نمشي');
    }
    return false;
  };

  const checkArticleKeywordsForCategory = (content: string, catId: string): boolean => {
    if (catId === 'all') return true;
    if (catId === 'fashion') return content.includes('ازياء') || content.includes('ملابس') || content.includes('fashion') || content.includes('clothing') || content.includes('نمشي') || content.includes('اتش') || content.includes('نايكي') || content.includes('nike');
    if (catId === 'sports') return content.includes('رياض') || content.includes('sports') || content.includes('nike') || content.includes('نايكي') || content.includes('جري');
    if (catId === 'electronics') return content.includes('إلكترونيات') || content.includes('noon') || content.includes('نون') || content.includes('amazon') || content.includes('أمازون') || content.includes('شاشة') || content.includes('كمبيوتر') || content.includes('لابتوب');
    if (catId === 'mobiles') return content.includes('جوال') || content.includes('هاتف') || content.includes('mobile') || content.includes('phone') || content.includes('ايفون') || content.includes('iphone') || content.includes('سامسونج');
    if (catId === 'appliances') return content.includes('أجهزة') || content.includes('منزل') || content.includes('appliances') || content.includes('مطبخ');
    if (catId === 'watches') return content.includes('ساعة') || content.includes('ساعات') || content.includes('watch') || content.includes('اكسسوار');
    return false;
  };

  const getStoreDisplayCategory = (store: any) => {
    if (store.category) {
      const cat = CATEGORIES.find((c) => c.id === store.category);
      if (cat) return cat;
    }
    // If no explicit category, check using the helper
    for (const cat of CATEGORIES) {
      if (isStoreInCategory(store, cat.id)) {
        return cat;
      }
    }
    return null;
  };

  // Filtered lists for real-time live search matching
  const filteredStoresRaw = stores.filter((store: any) => {
    // 1. Filter by category if set
    if (selectedCategoryFilter) {
      if (!isStoreInCategory(store, selectedCategoryFilter)) return false;
    }

    // 2. Filter by selected top logo if any
    if (selectedStoreFilter) {
      const isMatch = 
        String(store.id) === selectedStoreFilter ||
        (store.name || '').toLowerCase() === selectedStoreFilter.toLowerCase() ||
        (store.nameAr || '').toLowerCase() === selectedStoreFilter.toLowerCase();
      if (!isMatch) return false;
    }

    // 2.5 Filter by country if set and not "all"
    if (selectedCountryFilter && selectedCountryFilter !== 'all') {
      const storeCountry = (store.country || 'all').toLowerCase();
      if (storeCountry !== 'all' && storeCountry !== selectedCountryFilter.toLowerCase()) {
        return false;
      }
    }

    // 3. Filter by search query if any
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    return (
      (store.name || '').toLowerCase().includes(q) ||
      (store.nameAr || '').toLowerCase().includes(q) ||
      (store.code || '').toLowerCase().includes(q) ||
      (store.discount || '').toLowerCase().includes(q)
    );
  });

  // Sort matched stores based on selected sorting option (newest, discount, alphabetical)
  const filteredStores = [...filteredStoresRaw].sort((a: any, b: any) => {
    if (storeSortOption === 'newest') {
      // Sort by store ID descending (newly added has larger ID e.g. Date.now())
      return b.id - a.id;
    }
    
    if (storeSortOption === 'discount') {
      const getDiscountNumericValue = (discountStr: string | undefined | null): number => {
        if (!discountStr) return 0;
        try {
          const matches = discountStr.match(/\d+/g);
          if (matches && matches.length > 0) {
            const nums = matches.map(m => parseInt(m, 10));
            return Math.max(...nums);
          }
          const lower = discountStr.toLowerCase();
          if (lower.includes('free') || lower.includes('مجاني') || lower.includes('مجانًا')) {
            return 15; // Give premium/free shipping synthetic value
          }
          return 0;
        } catch (e) {
          return 0;
        }
      };
      
      const valA = getDiscountNumericValue(a.discount);
      const valB = getDiscountNumericValue(b.discount);
      if (valB !== valA) {
        return valB - valA; // Descending order of discount
      }
    }

    // Default or alphabetical option uses the existing custom group-sorted alphabetical brand logic
    const getStoreSortKey = (store: any) => {
      // English normalization
      let en = (store.name || '').toLowerCase().trim();
      const enWordsToRemove = [
        'saudi', 'arabia', 'egypt', 'uae', 'kuwait', 'bahrain', 'qatar', 'oman', 'iraq', 'jordan', 
        'dubai', 'riyadh', 'jeddah', 'cairo', 'com', 'net', 'market', 'store', 'shop', 'online', 'app',
        'ksa', 'egy', 'co', 'ltd', 'inc', 'shopping', 'coupons', 'coupon', 'deals', 'deal', 'discount'
      ];
      enWordsToRemove.forEach(word => {
        const regex = new RegExp(`\\b${word}\\b`, 'g');
        en = en.replace(regex, '');
      });
      en = en.replace(/[^a-z0-9]/g, '').trim();

      // Arabic normalization
      let ar = (store.nameAr || '').trim();
      ar = ar.replace(/[أإآ]/g, 'ا')
             .replace(/ة/g, 'ه')
             .replace(/ى/g, 'ي');
      
      const arWordsToRemove = [
        'السعودية', 'السعوديه', 'مصر', 'الامارات', 'الكويت', 'البحرين', 'قطر', 'عمان', 'العراق', 'الاردن', 
        'دبي', 'الرياض', 'جده', 'القاهره', 'كوم', 'دوت', 'ماركت', 'متجر', 'موقع', 'تطبيق', 'اونلاين', 'اون لاين',
        'ستور', 'شوب', 'كود', 'خصم', 'كوبون', 'كوبونات', 'اكواد', 'عروض', 'تخفيضات', 'تخفيض'
      ];
      arWordsToRemove.forEach(word => {
        const regex = new RegExp(word, 'g');
        ar = ar.replace(regex, '');
      });
      ar = ar.replace(/[^\u0621-\u064A0-9]/g, '').trim();

      return `${ar}_${en}`.trim().replace(/^_+|_+$/g, '');
    };

    const keyA = getStoreSortKey(a);
    const keyB = getStoreSortKey(b);
    
    if (keyA < keyB) return -1;
    if (keyA > keyB) return 1;
    
    // Fallback: keep alphabetical order by full name
    const nameA = (a.nameAr || a.name || '').toLowerCase();
    const nameB = (b.nameAr || b.name || '').toLowerCase();
    return nameA.localeCompare(nameB, lang === 'ar' ? 'ar' : 'en');
  });

  const filteredArticles = articles.filter((art: any) => {
    // 1. Filter by category if set
    if (selectedCategoryFilter) {
      // Find the associated store
      const associatedStore = stores.find((s: any) => String(s.id) === String(art.storeId) || s.name.toLowerCase() === (art.customStoreName || '').toLowerCase());
      if (associatedStore) {
        if (!isStoreInCategory(associatedStore, selectedCategoryFilter)) return false;
      } else {
        const content = `${art.title} ${art.titleEn} ${art.text} ${art.discountText}`.toLowerCase();
        const matchesKeywords = checkArticleKeywordsForCategory(content, selectedCategoryFilter);
        if (!matchesKeywords) return false;
      }
    }

    // 2. Filter by search query if any
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    return (
      (art.title || '').toLowerCase().includes(q) ||
      (art.titleEn || '').toLowerCase().includes(q) ||
      (art.text || '').toLowerCase().includes(q) ||
      (art.couponCode || '').toLowerCase().includes(q)
    );
  });

  // Colors and SocialLinks states moved to top of component to avoid Temporal Dead Zone (TDZ)

  useEffect(() => {
    localStorage.setItem('custom_social_links_v3', JSON.stringify(socialLinks));
  }, [socialLinks]);

  const [newSocialLink, setNewSocialLink] = useState({
    nameAr: '',
    nameEn: '',
    url: '',
    platform: 'custom'
  });

  const handleAddSocialLink = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSocialLink.url) return;
    
    const newLink = {
      id: String(Date.now()),
      nameAr: newSocialLink.nameAr.trim() || newSocialLink.nameEn.trim() || 'قناة جديدة',
      nameEn: newSocialLink.nameEn.trim() || newSocialLink.nameAr.trim() || 'New Link',
      url: newSocialLink.url.trim(),
      platform: newSocialLink.platform
    };
    
    setSocialLinks([...socialLinks, newLink]);
    setNewSocialLink({ nameAr: '', nameEn: '', url: '', platform: 'custom' });
    pushNotification('article', `تمت إضافة وسيلة تواصل جديدة: ${newLink.nameAr}`, `New social link added: ${newLink.nameEn}`);
  };

  const handleDeleteSocialLink = (id: string) => {
    const found = socialLinks.find(s => s.id === id);
    const updated = socialLinks.filter(s => s.id !== id);
    setSocialLinks(updated);
    if (found) {
      pushNotification('article', `تم حذف وسيلة التواصل: ${found.nameAr}`, `Social link removed: ${found.nameEn}`);
    }
  };

  const handleUpdateSocialLink = (id: string, field: string, value: string) => {
    const updated = socialLinks.map(s => {
      if (s.id === id) {
        return { ...s, [field]: value };
      }
      return s;
    });
    setSocialLinks(updated);
  };

  const getSocialIcon = (platform?: string, name?: string) => {
    const p = (platform || '').toLowerCase();
    const n = (name || '').toLowerCase();
    if (p === 'twitter' || n.includes('twitter') || n.includes('تويتر') || n.includes('إكس') || n.includes(' x')) {
      return <Twitter size={20} />;
    }
    if (p === 'instagram' || n.includes('instagram') || n.includes('انستغرام') || n.includes('إنستغرام') || n.includes('انستقرام')) {
      return <Instagram size={20} />;
    }
    if (p === 'facebook' || n.includes('facebook') || n.includes('فيسبوك') || n.includes('فيس بوك')) {
      return <Facebook size={20} />;
    }
    if (p === 'whatsapp' || n.includes('whatsapp') || n.includes('واتساب') || n.includes('واتس')) {
      return <MessageCircle size={20} />;
    }
    if (p === 'youtube' || n.includes('youtube') || n.includes('يوتيوب')) {
      return <Youtube size={20} />;
    }
    if (p === 'telegram' || p === 'tele' || n.includes('telegram') || n.includes('تلغرام') || n.includes('تيليجرام') || n.includes('تليجرام')) {
      return <Send size={20} />;
    }
    if (p === 'tiktok' || n.includes('tiktok') || n.includes('تيك توك') || n.includes('تيكتوك')) {
      return (
        <svg stroke="currentColor" fill="currentColor" strokeWidth="0" viewBox="0 0 448 512" height="20" width="20" xmlns="http://www.w3.org/2000/svg">
          <path d="M448,209.91a210.06,210.06,0,0,1-122.77-39.25V349.38A162.55,162.55,0,1,1,185,188.31V278.2a74.62,74.62,0,1,0,52.23,71.18V0l88,0a121.18,121.18,0,0,0,1.86,22.17h0A122.18,122.18,0,0,0,381,102.39a121.43,121.43,0,0,0,67,20.14Z"></path>
        </svg>
      );
    }
    return <Share2 size={20} />;
  };

  const whatsappLinkObj = socialLinks.find((s: any) => s.platform === 'whatsapp' || s.nameAr?.includes('واتساب') || s.nameEn?.toLowerCase().includes('whatsapp'));
  const whatsappLink = whatsappLinkObj ? whatsappLinkObj.url : 'https://chat.whatsapp.com/your-group-link';

  // SEO Checker and AI Writer States
  const [seoAuditLoading, setSeoAuditLoading] = useState(false);
  const [seoAuditResult, setSeoAuditResult] = useState<any>(null);
  const [rewriteDraft, setRewriteDraft] = useState('');
  const [rewriteKeywords, setRewriteKeywords] = useState('');
  const [rewriteOutput, setRewriteOutput] = useState('');
  const [rewriteLoading, setRewriteLoading] = useState(false);
  const [rewriteTitle, setRewriteTitle] = useState('');
  const [rewriteCategory, setRewriteCategory] = useState('');
  const [rewriteExcerpt, setRewriteExcerpt] = useState('');
  const [rewriteCountry, setRewriteCountry] = useState('sa');
  const [rewriteImage, setRewriteImage] = useState('https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=600&auto=format&fit=crop');

  const handleRunSeoAudit = async () => {
    setSeoAuditLoading(true);
    setSeoAuditResult(null);
    try {
      const res = await fetch('/api/seo-audit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          siteTitle: t[lang].title,
          siteDescription: t[lang].description,
          storesCount: stores.length,
          articlesCount: articles.length,
          hasSocialLinks: socialLinks.length > 0,
          hasWhatsapp: socialLinks.some((s: any) => s.platform === 'whatsapp' || s.nameAr?.includes('واتساب') || s.nameEn?.toLowerCase().includes('whatsapp')),
          articlesList: articles.map((a: any) => ({ title: a.title, length: (a.content || '').length }))
        })
      });
      const data = await res.json();
      if (data && !data.error) {
        setSeoAuditResult(data);
      } else {
        setSeoAuditResult({
          score: 78,
          status: 'Needs Improvement',
          checks: [
            { name: 'فحص عنوان الصفحة (SEO Title)', status: 'success', message: 'العنوان يحتوي على كلمات دلالية ممتازة وطول مثالي' },
            { name: 'فحص الوصف (Meta Description)', status: 'success', message: 'الوصف يعزز نسبة النقر مقابل الظهور CTR بشكل جيد' },
            { name: 'روابط التواصل الاجتماعي ومجتمع واتساب', status: 'success', message: 'موجودة وتساعد في تحسين مؤشرات الثقة E-E-A-T لدى جوجل' },
            { name: 'تغطية المتاجر العربية', status: 'warning', message: 'عدد المتاجر الحالي جيد ولكن يحتاج للزيادة المستمرة لضمان فترة بقاء أطول' }
          ],
          recommendations: [
            'أضف 5 مقالات حصرية متوافقة مع شروط السيو وطول لا يقل عن 400 كلمة للرتبة الأعلى.',
            'أضف شعارات رسمية واضحة للمتاجر وعلم الدولة المصاحب لزيادة ثقة محركات البحث ومعدل التحويل.',
            'انشر رابط مجتمع الواتساب في صفحات التواصل لزيادة الزوار المتكررين وعودة العناكب لأرشفة المحتوى الجديد.'
          ],
          densityAnalysis: 'ركز على استهداف الكلمات: كود خصم، كوبون تخفيض، عروض السعودية 2026، كوبونات المتاجر العربية.'
        });
      }
    } catch (err) {
      console.error(err);
      setSeoAuditResult({
        score: 75,
        status: 'Needs Improvement',
        checks: [
          { name: 'حالة الاتصال', status: 'warning', message: 'فشل الاتصال بالخادم لإجراء الفحص الذكي الفوري' }
        ],
        recommendations: ['تأكد من سلامة اتصال الخادم والمحاولة مجدداً للتحليل الكامل.'],
        densityAnalysis: 'تحليل الكلمات الدلالية الافتراضي للبلدان العربية.'
      });
    } finally {
      setSeoAuditLoading(false);
    }
  };

  const handleRunRewrite = async () => {
    if (!rewriteDraft.trim()) return;
    setRewriteLoading(true);
    setRewriteOutput('');
    setRewriteTitle('');
    setRewriteCategory('');
    setRewriteExcerpt('');
    try {
      const res = await fetch('/api/rewrite', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: rewriteDraft,
          focusKeywords: rewriteKeywords
        })
      });
      const data = await res.json();
      if (data && data.rewrittenText) {
        setRewriteOutput(data.rewrittenText);
        setRewriteTitle(data.suggestedTitle || (lang === 'ar' ? 'مقال توفير مميز' : 'Featured Savings Article'));
        setRewriteCategory(data.suggestedCategory || (lang === 'ar' ? 'توفير المال' : 'Smart Saving'));
        setRewriteExcerpt(data.suggestedExcerpt || (data.rewrittenText.substring(0, 120) + '...'));
        setRewriteCountry(data.suggestedCountry || 'sa');
      } else {
        setRewriteOutput(lang === 'ar' ? 'حدث خطأ أثناء تحسين المقال بالذكاء الاصطناعي.' : 'Failed to rewrite article with AI.');
      }
    } catch (err) {
      console.error(err);
      setRewriteOutput(lang === 'ar' ? 'فشل الاتصال بخدمة تحسين النصوص بالذكاء الاصطناعي.' : 'AI Rewrite service is temporarily unavailable.');
    } finally {
      setRewriteLoading(false);
    }
  };

  // Embla Slider Show Setup
  const [emblaRef, emblaApi] = useEmblaCarousel({ 
    loop: true, 
    direction: lang === 'ar' ? 'rtl' : 'ltr' 
  });

  // Scroll functions for the slideshow
  const scrollPrev = () => emblaApi && emblaApi.scrollPrev();
  const scrollNext = () => emblaApi && emblaApi.scrollNext();

  // Autoplay and responsive language support for the slideshow
  useEffect(() => {
    if (!emblaApi) return;
    emblaApi.reInit({
      loop: true,
      direction: lang === 'ar' ? 'rtl' : 'ltr'
    });
    
    const intervalId = setInterval(() => {
      emblaApi.scrollNext();
    }, 4000); // auto-scroll every 4 seconds
    
    return () => clearInterval(intervalId);
  }, [emblaApi, lang, stores]);

  // Save states to local storage
  useEffect(() => {
    localStorage.setItem('custom_stores', JSON.stringify(stores));
  }, [stores]);

  useEffect(() => {
    localStorage.setItem('custom_articles', JSON.stringify(articles));
  }, [articles]);

  useEffect(() => {
    localStorage.setItem('custom_colors', JSON.stringify(colors));
  }, [colors]);

  useEffect(() => {
    localStorage.setItem('custom_social_links', JSON.stringify(socialLinks));
  }, [socialLinks]);

  useEffect(() => {
    localStorage.setItem('custom_ad_config', JSON.stringify(adConfig));
  }, [adConfig]);

  // Apply colors dynamically to document styles
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
      root.style.setProperty('--primary', colors.darkPrimary || DEFAULT_COLORS.darkPrimary);
      root.style.setProperty('--primary-hover', (colors.darkPrimary || DEFAULT_COLORS.darkPrimary) + 'cc');
      root.style.setProperty('--bg-color', colors.darkBg || DEFAULT_COLORS.darkBg);
      root.style.setProperty('--card-bg', colors.darkCard || DEFAULT_COLORS.darkCard);
      root.style.setProperty('--text-color', colors.darkText || DEFAULT_COLORS.darkText);
      root.style.setProperty('--border-color', colors.darkBorder || DEFAULT_COLORS.darkBorder);
      
      root.style.setProperty('--header-bg', colors.darkHeaderBg || DEFAULT_COLORS.darkHeaderBg);
      root.style.setProperty('--footer-bg', colors.darkFooterBg || DEFAULT_COLORS.darkFooterBg);
      root.style.setProperty('--hero-bg-start', colors.darkHeroBgStart || DEFAULT_COLORS.darkHeroBgStart);
      root.style.setProperty('--hero-bg-end', colors.darkHeroBgEnd || DEFAULT_COLORS.darkHeroBgEnd);
      root.style.setProperty('--slider-card-bg', colors.darkSliderCardBg || DEFAULT_COLORS.darkSliderCardBg);
      root.style.setProperty('--slider-card-text', colors.darkSliderCardText || DEFAULT_COLORS.darkSliderCardText);
    } else {
      root.classList.remove('dark');
      root.style.setProperty('--primary', colors.primary || DEFAULT_COLORS.primary);
      root.style.setProperty('--primary-hover', (colors.primary || DEFAULT_COLORS.primary) + 'cc');
      root.style.setProperty('--bg-color', colors.bg || DEFAULT_COLORS.bg);
      root.style.setProperty('--card-bg', colors.card || DEFAULT_COLORS.card);
      root.style.setProperty('--text-color', colors.text || DEFAULT_COLORS.text);
      root.style.setProperty('--border-color', colors.border || DEFAULT_COLORS.border);
      
      root.style.setProperty('--header-bg', colors.headerBg || DEFAULT_COLORS.headerBg);
      root.style.setProperty('--footer-bg', colors.footerBg || DEFAULT_COLORS.footerBg);
      root.style.setProperty('--hero-bg-start', colors.heroBgStart || DEFAULT_COLORS.heroBgStart);
      root.style.setProperty('--hero-bg-end', colors.heroBgEnd || DEFAULT_COLORS.heroBgEnd);
      root.style.setProperty('--slider-card-bg', colors.sliderCardBg || DEFAULT_COLORS.sliderCardBg);
      root.style.setProperty('--slider-card-text', colors.sliderCardText || DEFAULT_COLORS.sliderCardText);
    }
    document.body.className = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [theme, lang, colors]);

  const toggleTheme = () => setTheme(t => t === 'light' ? 'dark' : 'light');

  const handleCopy = (code: string, id: number, link: string) => {
    navigator.clipboard.writeText(code);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
    
    const store = stores.find((s: any) => s.id === id);
    setCopiedCouponInfo({
      code: code,
      storeName: store ? (lang === 'ar' ? (store.nameAr || store.name) : store.name) : 'Store',
      storeLogo: store ? store.logo : undefined,
      link: link
    });
  };

  const handleSmartSearch = async () => {
    if (!searchQuery) return;
    setIsSearching(true);
    try {
      const res = await fetch('/api/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: `Find latest coupon deals and information about: ${searchQuery}` })
      });
      const data = await res.json();
      setSearchResults(data.text);
    } catch (e) {
      console.error(e);
      setSearchResults(lang === 'ar' ? 'عذراً، حدث خطأ أثناء الاتصال بالخادم.' : 'Sorry, an error occurred while connecting to the server.');
    }
    setIsSearching(false);
  };

  const playTTS = async (text: string) => {
    try {
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text })
      });
      const data = await res.json();
      if (data.audio) {
        const binary = atob(data.audio);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) {
          bytes[i] = binary.charCodeAt(i);
        }
        
        const ctx = new window.AudioContext({ sampleRate: 24000 });
        const float32Data = new Float32Array(bytes.length / 2);
        for (let i = 0; i < bytes.length; i += 2) {
          const int16 = (bytes[i + 1] << 8) | bytes[i];
          const signed = int16 >= 0x8000 ? int16 - 0x10000 : int16;
          float32Data[i / 2] = signed / 0x8000;
        }
        const buffer = ctx.createBuffer(1, float32Data.length, 24000);
        buffer.getChannelData(0).set(float32Data);
        const source = ctx.createBufferSource();
        source.buffer = buffer;
        source.connect(ctx.destination);
        source.start();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Add / Delete Store Handlers
  const [newStore, setNewStore] = useState({
    name: '',
    nameAr: '',
    discount: '',
    code: '',
    link: 'https://',
    logo: '',
    customBg: '',
    customText: '',
    bgType: 'color' as 'color' | 'image' | 'logoBlur',
    bgImageUrl: '',
    category: 'fashion',
    expiryDate: '',
    country: 'all'
  });

  const handleAddStore = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStore.name || !newStore.code) return;

    if (editingStoreId !== null) {
      // Edit existing store
      setStores(stores.map((s: any) => s.id === editingStoreId ? { ...s, ...newStore } : s));
      pushNotification(
        'coupon', 
        `تمت تحديث بيانات متجر ${newStore.nameAr || newStore.name} بنجاح!`, 
        `Store ${newStore.name} updated successfully!`
      );
      setEditingStoreId(null);
    } else {
      // Add new store
      const storeToAdd = {
        ...newStore,
        id: Date.now()
      };
      setStores([...stores, storeToAdd]);
      pushNotification(
        'coupon', 
        `تمت إضافة كوبون جديد لمتجر ${newStore.nameAr || newStore.name} (${newStore.code})`, 
        `New coupon added for ${newStore.name} (${newStore.code})`
      );
    }

    setNewStore({ 
      name: '', 
      nameAr: '', 
      discount: '', 
      code: '', 
      link: 'https://', 
      logo: '', 
      customBg: '', 
      customText: '',
      bgType: 'color',
      bgImageUrl: '',
      category: 'fashion',
      expiryDate: ''
    });
    setCopiedStoreName(null);
  };

  const handleDeleteStore = (id: number) => {
    if (confirm(currLang.deleteConfirm)) {
      setStores(stores.filter((store: any) => store.id !== id));
    }
  };

  // Add / Delete Article Handlers
  const [newArticle, setNewArticle] = useState({
    title: '',
    titleEn: '',
    text: '',
    hasCoupon: false,
    storeId: 'custom',
    customStoreName: '',
    customStoreLogo: '',
    countryFlag: '🇸🇦',
    couponCode: '',
    referralLink: 'https://',
    discountText: '',
    image: '',
    innerLink: '',
    innerLinkText: ''
  });

  const handleAddArticle = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newArticle.title || !newArticle.text) return;
    const articleToAdd = {
      ...newArticle,
      id: Date.now()
    };
    setArticles([...articles, articleToAdd]);
    pushNotification(
      'article', 
      `تم نشر مقال سيو جديد: ${newArticle.title}`, 
      `New article published: ${newArticle.titleEn || newArticle.title}`
    );
    setNewArticle({ 
      title: '', 
      titleEn: '', 
      text: '',
      hasCoupon: false,
      storeId: 'custom',
      customStoreName: '',
      customStoreLogo: '',
      countryFlag: '🇸🇦',
      couponCode: '',
      referralLink: 'https://',
      discountText: '',
      image: '',
      innerLink: '',
      innerLinkText: ''
    });
  };

  const handleDeleteArticle = (id: number) => {
    if (confirm(currLang.deleteConfirm)) {
      setArticles(articles.filter((article: any) => article.id !== id));
    }
  };

  // Reset Colors
  const handleResetColors = () => {
    setColors(DEFAULT_COLORS);
  };

  const [selectedArticle, setSelectedArticle] = useState<any | null>(null);
  const [copiedArticleId, setCopiedArticleId] = useState<number | null>(null);

  const currLang = t[lang];

  // Dynamic SEO Page Meta Calculation
  const activeSEO = useMemo(() => {
    let title = lang === 'ar' ? seoTitleAr : seoTitleEn;
    let description = lang === 'ar' ? seoDescAr : seoDescEn;
    let keywords = lang === 'ar' ? seoKeywordsAr : seoKeywordsEn;
    let canonical = window.location.href;
    let schema: any = null;

    if (currentView === 'store' && selectedStoreId) {
      const activeStore = stores.find((s: any) => String(s.id) === String(selectedStoreId));
      if (activeStore) {
        const storeName = lang === 'ar' ? (activeStore.nameAr || activeStore.name) : activeStore.name;
        const discountStr = activeStore.discount || '';
        
        title = lang === 'ar' 
          ? `كود خصم ${storeName} 2026 فعال ومجرب بقيمة ${discountStr} | وفير`
          : `${storeName} Coupon Code 2026 - Save ${discountStr} (Verified) | Wafeer`;
        
        description = lang === 'ar'
          ? `احصل على أحدث كود خصم ${storeName} الحصري والفعال اليوم بقيمة ${discountStr}. انسخ الكود ووفر نقودك فوراً على جميع المشتريات والطلبيات.`
          : `Get the latest verified ${storeName} promo codes and discount deals 2026. Copy our active coupon code to save ${discountStr} on your order today!`;
        
        keywords = lang === 'ar'
          ? `كود خصم ${storeName}، كوبون ${storeName}، كود تخفيض ${storeName}، رمز ترويجي ${storeName}`
          : `${storeName} coupon code, ${storeName} promo code, discount code ${storeName}, active ${storeName} codes`;

        // Product & Coupon Schema
        schema = {
          "@context": "https://schema.org",
          "@type": "Product",
          "name": `${storeName} Coupon Code 2026`,
          "image": activeStore.logo || "https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da",
          "description": description,
          "offers": {
            "@type": "AggregateOffer",
            "lowPrice": "0",
            "highPrice": "0",
            "priceCurrency": "USD",
            "offerCount": "1",
            "offers": [
              {
                "@type": "Offer",
                "name": `Active Coupon Code: ${activeStore.code || 'WAFFER'}`,
                "price": "0",
                "priceCurrency": "USD",
                "eligibleTransactionVolume": {
                  "@type": "PriceSpecification",
                  "price": "1",
                  "priceCurrency": "USD"
                }
              }
            ]
          }
        };
      }
    } else if (selectedArticle) {
      const artTitle = lang === 'ar' ? selectedArticle.title : (selectedArticle.titleEn || selectedArticle.title);
      title = lang === 'ar'
        ? `${artTitle} | مدونة وفير للتسوق الذكي`
        : `${artTitle} | Wafeer Saving Blog`;
      
      description = selectedArticle.text ? selectedArticle.text.substring(0, 160) : description;
      
      schema = {
        "@context": "https://schema.org",
        "@type": "BlogPosting",
        "headline": artTitle,
        "description": description,
        "author": {
          "@type": "Organization",
          "name": "Wafeer"
        },
        "publisher": {
          "@type": "Organization",
          "name": "Wafeer",
          "logo": {
            "@type": "ImageObject",
            "url": "https://cdn.jsdelivr.net/gh/microsoft/fluentui-emoji@main/assets/Money%20bag/3D/money_bag_3d.png"
          }
        },
        "datePublished": "2026-07-18"
      };
    }

    if (!schema) {
      // Default website schema
      schema = {
        "@context": "https://schema.org",
        "@type": "WebSite",
        "name": lang === 'ar' ? seoTitleAr : seoTitleEn,
        "url": window.location.origin || "https://wafeer.ai.studio",
        "description": lang === 'ar' ? seoDescAr : seoDescEn,
        "potentialAction": {
          "@type": "SearchAction",
          "target": `${window.location.origin || "https://wafeer.ai.studio"}/?q={search_term_string}`,
          "query-input": "required name=search_term_string"
        }
      };
    }

    return { title, description, keywords, canonical, schema };
  }, [lang, currentView, selectedStoreId, selectedArticle, stores, seoTitleAr, seoTitleEn, seoDescAr, seoDescEn, seoKeywordsAr, seoKeywordsEn]);

  return (
    <HelmetProvider>
      <Helmet>
        <title>{activeSEO.title}</title>
        <meta name="description" content={activeSEO.description} />
        <meta name="keywords" content={activeSEO.keywords} />
        <link rel="canonical" href={activeSEO.canonical} />

        {/* Search Engine Webmaster Verification Tags */}
        {googleVerificationCode && <meta name="google-site-verification" content={googleVerificationCode} />}
        {bingVerificationCode && <meta name="msvalidate.01" content={bingVerificationCode} />}

        {/* OpenGraph & Social Cards */}
        <meta property="og:title" content={activeSEO.title} />
        <meta property="og:description" content={activeSEO.description} />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={activeSEO.canonical} />
        <meta property="og:site_name" content="Wafeer" />
        <meta property="og:image" content="https://cdn.jsdelivr.net/gh/microsoft/fluentui-emoji@main/assets/Money%20bag/3D/money_bag_3d.png" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={activeSEO.title} />
        <meta name="twitter:description" content={activeSEO.description} />

        {/* Dynamic Schema JSON-LD for rich snippets (Search Engine Archiving) */}
        <script type="application/ld+json">
          {JSON.stringify(activeSEO.schema)}
        </script>
        {adConfig.showAds && adConfig.adClientId && (
          <script 
            async 
            src={`https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${adConfig.adClientId}`} 
            crossOrigin="anonymous" 
          />
        )}
      </Helmet>
      
      <div className="min-h-screen flex flex-col bg-bg text-text-main transition-colors duration-300">
        {/* Header Section */}
        <header className="flex items-center justify-between px-4 md:px-8 py-4 bg-card border-b border-border-main shadow-sm transition-colors duration-300 z-40 sticky top-0">
          <div className="flex items-center gap-8">
            <motion.div 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => {
                setCurrentView('home');
                setSelectedStoreId(null);
                window.location.hash = '';
              }}
              className="text-xl sm:text-2xl font-black text-primary italic flex items-center gap-2 cursor-pointer"
            >
              <motion.span 
                animate={{ rotate: [0, 10, -10, 10, 0], y: [0, -2, 0] }}
                transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
                whileHover={{ scale: 1.2, rotate: 360, transition: { duration: 0.5, type: 'spring' } }}
                className="text-2xl sm:text-3xl not-italic inline-block"
              >
                💰
              </motion.span>
              <motion.span 
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                className="bg-gradient-to-r from-primary to-primary bg-clip-text text-transparent font-extrabold not-italic tracking-tight"
              >
                {lang === 'ar' ? 'وفير' : 'Wafeer'}
              </motion.span>
            </motion.div>
            <nav className="flex gap-4 md:gap-6 text-xs md:text-sm font-semibold text-text-main opacity-90 py-1 relative">
              <a 
                href="#" 
                onClick={(e) => {
                  e.preventDefault();
                  setCurrentView('home');
                  setSelectedStoreId(null);
                  window.location.hash = '';
                }}
                className={`hover:text-primary transition-all flex items-center ${currentView === 'home' ? 'text-primary font-bold' : ''}`}
              >
                {lang === 'ar' ? 'الرئيسية' : 'Home'}
              </a>

              {/* Stores Dropdown */}
              <div 
                className="relative"
                onMouseEnter={() => setIsStoresDropdownOpen(true)}
                onMouseLeave={() => setIsStoresDropdownOpen(false)}
              >
                <button 
                  onClick={() => setIsStoresDropdownOpen(!isStoresDropdownOpen)}
                  className={`hover:text-primary transition-all flex items-center gap-1 cursor-pointer font-semibold ${currentView === 'store' ? 'text-primary font-bold' : ''}`}
                >
                  <span>{lang === 'ar' ? 'المتاجر' : 'Stores'}</span>
                  <ChevronDown size={14} className={`transition-transform duration-200 ${isStoresDropdownOpen ? 'rotate-180 text-primary' : ''}`} />
                </button>
                
                <AnimatePresence>
                  {isStoresDropdownOpen && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      className="absolute right-0 top-full mt-2 bg-card border border-border-main rounded-2xl shadow-xl p-3 w-64 sm:w-72 z-50 flex flex-col gap-1.5"
                    >
                      <div className="grid grid-cols-2 gap-1.5">
                        {stores.slice(0, 8).map((st: any) => (
                          <a
                            key={st.id}
                            href={`#store-${st.id}`}
                            onClick={() => {
                              setSelectedStoreId(st.id);
                              setCurrentView('store');
                              setIsStoresDropdownOpen(false);
                            }}
                            className="flex items-center gap-2 p-1.5 rounded-xl hover:bg-bg/50 border border-transparent hover:border-border-main/50 transition text-right"
                          >
                            <div className="w-8 h-6 bg-slate-50 dark:bg-slate-900 rounded flex items-center justify-center p-0.5 border border-slate-100/60 dark:border-slate-800/60 shrink-0">
                              <StoreLogo logo={st.logo} name={st.name} nameAr={st.nameAr} className="max-w-full max-h-full object-contain" />
                            </div>
                            <span className="text-[10px] sm:text-xs font-bold text-text-main truncate">
                              {lang === 'ar' ? (st.nameAr || st.name) : st.name}
                            </span>
                          </a>
                        ))}
                      </div>
                      <div className="border-t border-border-main/50 mt-1.5 pt-1.5 text-center">
                        <a 
                          href="#stores" 
                          onClick={(e) => {
                            e.preventDefault();
                            setIsStoresDropdownOpen(false);
                            setCurrentView('home');
                            setSelectedStoreId(null);
                            setTimeout(() => {
                              document.getElementById('stores')?.scrollIntoView({ behavior: 'smooth' });
                            }, 100);
                          }}
                          className="text-[11px] text-primary font-black hover:underline"
                        >
                          {lang === 'ar' ? 'عرض جميع المتاجر 🌟' : 'View All Stores 🌟'}
                        </a>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Categories Dropdown */}
              <div 
                className="relative"
                onMouseEnter={() => setIsCategoriesDropdownOpen(true)}
                onMouseLeave={() => setIsCategoriesDropdownOpen(false)}
              >
                <button 
                  onClick={() => setIsCategoriesDropdownOpen(!isCategoriesDropdownOpen)}
                  className="hover:text-primary transition-all flex items-center gap-1 cursor-pointer font-semibold"
                >
                  <span>{lang === 'ar' ? 'الفئات' : 'Categories'}</span>
                  <ChevronDown size={14} className={`transition-transform duration-200 ${isCategoriesDropdownOpen ? 'rotate-180 text-primary' : ''}`} />
                </button>
                
                <AnimatePresence>
                  {isCategoriesDropdownOpen && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      className="absolute right-[-40px] sm:right-0 top-full mt-2 bg-card border border-border-main rounded-2xl shadow-xl p-3 w-64 sm:w-[320px] z-50 flex flex-col gap-1.5"
                    >
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 max-h-[260px] overflow-y-auto scrollbar-thin pr-1">
                        {CATEGORIES.map((cat: any) => {
                          return (
                            <button
                              key={cat.id}
                              onClick={() => {
                                setSelectedCategoryFilter(cat.id);
                                setSelectedStoreFilter(null);
                                setCurrentView('home');
                                setIsCategoriesDropdownOpen(false);
                                setTimeout(() => {
                                  const el = document.getElementById('offers') || document.getElementById('stores');
                                  el?.scrollIntoView({ behavior: 'smooth' });
                                }, 150);
                              }}
                              className="flex items-center gap-2 p-1.5 rounded-xl hover:bg-bg/50 border border-transparent hover:border-border-main/50 transition text-right cursor-pointer"
                            >
                              <div className="w-6 h-6 rounded-lg bg-primary/5 text-primary flex items-center justify-center shrink-0">
                                <cat.icon size={13} />
                              </div>
                              <span className="text-[10px] sm:text-xs font-bold text-text-main truncate">
                                {lang === 'ar' ? cat.nameAr : cat.nameEn}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                      <div className="border-t border-border-main/50 mt-1.5 pt-1.5 text-center">
                        <button 
                          onClick={() => {
                            setSelectedCategoryFilter(null);
                            setIsCategoriesDropdownOpen(false);
                            setCurrentView('home');
                            setTimeout(() => {
                              document.getElementById('stores')?.scrollIntoView({ behavior: 'smooth' });
                            }, 100);
                          }}
                          className="text-[11px] text-primary font-black hover:underline cursor-pointer"
                        >
                          {lang === 'ar' ? 'عرض جميع الفئات ✨' : 'View All Categories ✨'}
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <a 
                href="#blog" 
                onClick={(e) => {
                  e.preventDefault();
                  setCurrentView('home');
                  setSelectedStoreId(null);
                  setTimeout(() => {
                    document.getElementById('blog')?.scrollIntoView({ behavior: 'smooth' });
                  }, 100);
                }}
                className="hover:text-primary transition-all flex items-center"
              >
                {lang === 'ar' ? 'المدونة' : 'Blog'}
              </a>
            </nav>
          </div>
          <div className="flex items-center gap-3">
            {/* Control Panel Toggle Button */}
            {showAdminButton && (
              <button 
                onClick={() => {
                  if (isAdminAuthenticated) {
                    setIsAdminOpen(true);
                  } else {
                    setShowLoginModal(true);
                    setLoginError('');
                    setInputPassword('');
                  }
                }}
                className="p-2 bg-primary/10 text-primary hover:bg-primary/20 rounded-lg transition-colors duration-200 flex items-center gap-1.5 text-xs font-bold cursor-pointer"
                title={currLang.adminPanel}
              >
                <Settings size={18} className="animate-spin-slow" />
                <span className="hidden sm:inline">{currLang.adminPanel}</span>
              </button>
            )}

            <div className="flex bg-border-main/50 rounded-full p-1 transition-colors duration-300">
              <button onClick={() => setLang('ar')} className={`px-4 py-1 text-xs font-bold rounded-full shadow-sm transition ${lang === 'ar' ? 'bg-card text-text-main' : 'text-text-main opacity-60'}`}>AR</button>
              <button onClick={() => setLang('en')} className={`px-4 py-1 text-xs font-bold rounded-full shadow-sm transition ${lang === 'en' ? 'bg-card text-text-main' : 'text-text-main opacity-60'}`}>EN</button>
            </div>
            <button onClick={toggleTheme} className="p-2 bg-border-main/50 rounded-lg transition-colors duration-300" aria-label="Toggle Theme">
              <div className="w-5 h-5 flex items-center justify-center text-text-main">
                {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
              </div>
            </button>
          </div>
        </header>

        {/* Floating Customizer Drawer */}
        <AnimatePresence>
          {isAdminOpen && (
            <>
              {/* Overlay Backdrop */}
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.5 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsAdminOpen(false)}
                className="fixed inset-0 bg-black z-50"
              />
              {/* Drawer Container */}
              <motion.div 
                initial={{ x: lang === 'ar' ? '-100%' : '100%' }}
                animate={{ x: 0 }}
                exit={{ x: lang === 'ar' ? '-100%' : '100%' }}
                transition={{ type: 'tween', duration: 0.3 }}
                className={`fixed top-0 bottom-0 ${lang === 'ar' ? 'left-0' : 'right-0'} w-full max-w-md bg-card border-${lang === 'ar' ? 'r' : 'l'} border-border-main shadow-2xl z-50 flex flex-col`}
              >
                {/* Header */}
                <div className="p-4 border-b border-border-main flex items-center justify-between bg-bg">
                  <div className="flex items-center gap-2">
                    <Sliders size={20} className="text-primary" />
                    <h3 className="font-bold text-lg">{currLang.adminPanel}</h3>
                  </div>
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={() => {
                        setIsAdminAuthenticated(false);
                        localStorage.setItem('isAdminAuthenticated', 'false');
                        setEditMode(false);
                        setIsAdminOpen(false);
                      }}
                      className="p-1.5 hover:bg-red-500/10 text-red-500 rounded-lg flex items-center gap-1 text-xs font-bold cursor-pointer transition-colors"
                      title={lang === 'ar' ? 'تسجيل الخروج' : 'Logout'}
                    >
                      <LogOut size={16} />
                      <span>{lang === 'ar' ? 'خروج' : 'Logout'}</span>
                    </button>
                    <button 
                      onClick={() => setIsAdminOpen(false)}
                      className="p-1 hover:bg-border-main/50 rounded-lg text-text-main opacity-70 cursor-pointer"
                    >
                      <X size={20} />
                    </button>
                  </div>
                </div>

                {/* Main Control Panel Tabs */}
                <div className="flex flex-col border-b border-border-main text-[10px] font-bold text-text-main bg-bg">
                  <div className="flex border-b border-border-main/50">
                    <button 
                      onClick={() => setActiveAdminTab('colors')}
                      className={`flex-1 py-3 text-center border-r border-border-main/30 border-b-2 transition ${activeAdminTab === 'colors' ? 'border-b-primary text-primary bg-card/40' : 'border-b-transparent opacity-60'}`}
                    >
                      🎨 الألوان / Colors
                    </button>
                    <button 
                      onClick={() => setActiveAdminTab('hero')}
                      className={`flex-1 py-3 text-center border-r border-border-main/30 border-b-2 transition ${activeAdminTab === 'hero' ? 'border-b-primary text-primary bg-card/40' : 'border-b-transparent opacity-60'}`}
                    >
                      👑 البانر / Hero
                    </button>
                    <button 
                      onClick={() => setActiveAdminTab('stores')}
                      className={`flex-1 py-3 text-center border-b-2 transition ${activeAdminTab === 'stores' ? 'border-b-primary text-primary bg-card/40' : 'border-b-transparent opacity-60'}`}
                    >
                      🛒 المتاجر / Stores
                    </button>
                  </div>
                  <div className="flex border-b border-border-main/50">
                    <button 
                      onClick={() => setActiveAdminTab('articles')}
                      className={`flex-1 py-3 text-center border-r border-border-main/30 border-b-2 transition ${activeAdminTab === 'articles' ? 'border-b-primary text-primary bg-card/40' : 'border-b-transparent opacity-60'}`}
                    >
                      📝 المقالات / Articles
                    </button>
                    <button 
                      onClick={() => setActiveAdminTab('social')}
                      className={`flex-1 py-3 text-center border-r border-border-main/30 border-b-2 transition ${activeAdminTab === 'social' ? 'border-b-primary text-primary bg-card/40' : 'border-b-transparent opacity-60'}`}
                    >
                      💬 التواصل / Social
                    </button>
                    <button 
                      onClick={() => setActiveAdminTab('ads')}
                      className={`flex-1 py-3 text-center border-b-2 transition ${activeAdminTab === 'ads' ? 'border-b-primary text-primary bg-card/40' : 'border-b-transparent opacity-60'}`}
                    >
                      📢 أدسنس / Ads
                    </button>
                  </div>
                  <div className="flex border-b border-border-main/50">
                    <button 
                      type="button"
                      onClick={() => setActiveAdminTab('seo_checker')}
                      className={`flex-1 py-3 text-center border-r border-border-main/30 border-b-2 transition ${activeAdminTab === 'seo_checker' ? 'border-b-primary text-primary bg-card/40' : 'border-b-transparent opacity-60'} flex items-center justify-center gap-1`}
                    >
                      <Gauge size={12} className="text-emerald-500" />
                      <span>فحص السيو / SEO Checker</span>
                    </button>
                    <button 
                      type="button"
                      onClick={() => setActiveAdminTab('ai_writer')}
                      className={`flex-1 py-3 text-center border-r border-border-main/30 border-b-2 transition ${activeAdminTab === 'ai_writer' ? 'border-b-primary text-primary bg-card/40' : 'border-b-transparent opacity-60'} flex items-center justify-center gap-1`}
                    >
                      <Wand2 size={12} className="text-violet-500" />
                      <span>الكاتب / AI Writer</span>
                    </button>
                    <button 
                      type="button"
                      onClick={() => setActiveAdminTab('benefits')}
                      className={`flex-1 py-3 text-center border-b-2 transition ${activeAdminTab === 'benefits' ? 'border-b-primary text-primary bg-card/40' : 'border-b-transparent opacity-60'} flex items-center justify-center gap-1`}
                    >
                      💡 {lang === 'ar' ? 'التبويبات / Tabs' : 'Benefit Tabs'}
                    </button>
                  </div>
                  <div className="flex">
                    <button 
                      type="button"
                      onClick={() => setActiveAdminTab('messages')}
                      className={`flex-1 py-3 text-center border-r border-border-main/30 border-b-2 transition ${activeAdminTab === 'messages' ? 'border-b-primary text-primary bg-card/40' : 'border-b-transparent opacity-60'} flex items-center justify-center gap-1`}
                    >
                      📬 رسائل اتصل بنا / Contacts
                    </button>
                    <button 
                      type="button"
                      onClick={() => setActiveAdminTab('seo_metadata')}
                      className={`flex-1 py-3 text-center border-r border-border-main/30 border-b-2 transition ${activeAdminTab === 'seo_metadata' ? 'border-b-primary text-primary bg-card/40' : 'border-b-transparent opacity-60'} flex items-center justify-center gap-1`}
                    >
                      🌐 أدوات الأرشفة والظهور / SEO Tools
                    </button>
                    <button 
                      type="button"
                      onClick={() => setActiveAdminTab('footer_config')}
                      className={`flex-1 py-3 text-center border-b-2 transition ${activeAdminTab === 'footer_config' ? 'border-b-primary text-primary bg-card/40' : 'border-b-transparent opacity-60'} flex items-center justify-center gap-1`}
                    >
                      👣 الفوتر / Footer
                    </button>
                  </div>
                </div>

                {/* Tab Contents (Scrollable) */}
                <div className="flex-1 overflow-y-auto p-5 space-y-6">
                  {/* Visual Edit Mode Switcher */}
                  <div className="p-3 bg-primary/5 border border-primary/20 rounded-xl flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Edit3 size={16} className="text-primary" />
                      <span className="text-xs font-bold">{currLang.editMode}</span>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={editMode} 
                        onChange={(e) => setEditMode(e.target.checked)} 
                        className="sr-only peer" 
                      />
                      <div className="w-11 h-6 bg-border-main rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                    </label>
                  </div>

                  {/* Keyboard Shortcuts Helper Box */}
                  <div className="p-3 bg-card border border-border-main/80 rounded-xl space-y-2 text-xs">
                    <div className="flex items-center gap-1.5 font-bold text-text-main">
                      <Keyboard size={14} className="text-primary animate-pulse" />
                      <span>{lang === 'ar' ? 'اختصارات لوحة المفاتيح السريعة' : 'Quick Keyboard Shortcuts'}</span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[10px]">
                      <div className="flex items-center justify-between p-2 bg-bg border border-border-main/50 rounded-lg">
                        <span className="opacity-70">{lang === 'ar' ? 'إدارة المتاجر' : 'Manage Stores'}</span>
                        <div className="flex gap-0.5">
                          <kbd className="px-1 py-0.5 bg-card border border-border-main rounded text-[8px] font-mono shadow-xs">Ctrl</kbd>
                          <kbd className="px-1 py-0.5 bg-card border border-border-main rounded text-[8px] font-mono shadow-xs">Alt</kbd>
                          <kbd className="px-1 py-0.5 bg-card border border-border-main rounded text-[8px] font-mono shadow-xs">S</kbd>
                        </div>
                      </div>
                      <div className="flex items-center justify-between p-2 bg-bg border border-border-main/50 rounded-lg">
                        <span className="opacity-70">{lang === 'ar' ? 'إدارة المقالات' : 'Manage Articles'}</span>
                        <div className="flex gap-0.5">
                          <kbd className="px-1 py-0.5 bg-card border border-border-main rounded text-[8px] font-mono shadow-xs">Ctrl</kbd>
                          <kbd className="px-1 py-0.5 bg-card border border-border-main rounded text-[8px] font-mono shadow-xs">Alt</kbd>
                          <kbd className="px-1 py-0.5 bg-card border border-border-main rounded text-[8px] font-mono shadow-xs">N</kbd>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Change Admin Password */}
                  <div className="p-3 bg-card border border-border-main rounded-xl space-y-3">
                    <div className="flex items-center gap-2 text-text-main">
                      <Key size={16} className="text-primary" />
                      <span className="text-xs font-bold">{lang === 'ar' ? 'تغيير كلمة مرور لوحة التحكم' : 'Change Admin Password'}</span>
                    </div>
                    <div className="flex gap-2">
                      <input
                        type="password"
                        placeholder={lang === 'ar' ? 'كلمة المرور الجديدة' : 'New Password'}
                        value={newPasswordVal}
                        onChange={(e) => {
                          setNewPasswordVal(e.target.value);
                          setPasswordChangeSuccess(false);
                        }}
                        className="flex-1 bg-bg border border-border-main rounded-lg px-3 py-1.5 text-xs text-text-main focus:outline-none focus:border-primary"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          if (newPasswordVal.trim()) {
                            localStorage.setItem('admin_password', newPasswordVal.trim());
                            setAdminPasswordVal(newPasswordVal.trim());
                            setNewPasswordVal('');
                            setPasswordChangeSuccess(true);
                            setTimeout(() => setPasswordChangeSuccess(false), 3000);
                          }
                        }}
                        className="px-3 py-1.5 bg-primary text-white font-bold rounded-lg text-xs hover:bg-primary-hover transition cursor-pointer"
                      >
                        {lang === 'ar' ? 'حفظ' : 'Save'}
                      </button>
                    </div>
                    {passwordChangeSuccess && (
                      <p className="text-[10px] text-emerald-500 font-bold">
                        {lang === 'ar' ? '✓ تم تغيير كلمة المرور بنجاح!' : '✓ Password changed successfully!'}
                      </p>
                    )}
                    <p className="text-[10px] opacity-60">
                      {lang === 'ar' ? 'كلمة المرور الافتراضية هي admin2026' : 'Default password is admin2026'}
                    </p>
                  </div>

                  {/* Hide settings gear from browser */}
                  <div className="p-3 bg-red-500/5 border border-red-500/20 rounded-xl space-y-2">
                    <div className="flex items-center justify-between gap-4">
                      <div className="flex flex-col">
                        <span className="text-xs font-bold text-red-500">
                          {lang === 'ar' ? 'إخفاء زر الإدارة من المتصفح' : 'Hide Admin Button from Browser'}
                        </span>
                        <span className="text-[10px] opacity-60 leading-relaxed">
                          {lang === 'ar' 
                            ? 'سيتم إخفاء زر الإدارة تماماً عن زوار الموقع. للوصول إليه مجدداً وتحديث الموقع، قم بزيارة رابط الموقع مع إضافة ?admin=true في النهاية.' 
                            : 'This will completely hide the Settings gear from public visitors. To access it again later, visit the URL ending with ?admin=true.'}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          localStorage.removeItem('showAdminTrigger');
                          setShowAdminButton(false);
                          setIsAdminAuthenticated(false);
                          localStorage.setItem('isAdminAuthenticated', 'false');
                          setEditMode(false);
                          setIsAdminOpen(false);
                        }}
                        className="px-2.5 py-1.5 bg-red-500 text-white font-bold rounded-lg text-xs hover:bg-red-600 transition cursor-pointer shrink-0"
                      >
                        {lang === 'ar' ? 'إخفاء الآن' : 'Hide Now'}
                      </button>
                    </div>
                  </div>

                  {/* Stores View Mode Switcher inside Admin Panel (ONLY visible to Admin) */}
                  <div className="p-3 bg-card border border-border-main rounded-xl flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <LayoutGrid size={16} className="text-primary" />
                      <span className="text-xs font-bold">{lang === 'ar' ? 'طريقة عرض المتاجر والخصومات' : 'Coupons Layout View'}</span>
                    </div>
                    <div className="bg-bg border border-border-main p-0.5 rounded-lg flex items-center gap-0.5">
                      <button
                        type="button"
                        onClick={() => setStoresViewMode('grid')}
                        className={`px-2.5 py-1 rounded-md text-[11px] font-bold transition-all flex items-center gap-1 cursor-pointer ${storesViewMode === 'grid' ? 'bg-primary text-white shadow-xs scale-[1.01]' : 'text-text-main/70 hover:text-text-main'}`}
                        title={lang === 'ar' ? 'عرض شبكة (Grid)' : 'Grid View'}
                      >
                        <LayoutGrid size={12} />
                        <span>{lang === 'ar' ? 'شبكة' : 'Grid'}</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setStoresViewMode('slider')}
                        className={`px-2.5 py-1 rounded-md text-[11px] font-bold transition-all flex items-center gap-1 cursor-pointer ${storesViewMode === 'slider' ? 'bg-primary text-white shadow-xs scale-[1.01]' : 'text-text-main/70 hover:text-text-main'}`}
                        title={lang === 'ar' ? 'عرض منزلق (Slider)' : 'Slider View'}
                      >
                        <Sliders size={12} />
                        <span>{lang === 'ar' ? 'منزلق' : 'Slider'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Tab 1: Color Customizer */}
                  {activeAdminTab === 'colors' && (
                    <div className="space-y-6">
                      {/* Predefined Palettes Block */}
                      <div className="p-4 bg-primary/5 border border-primary/20 rounded-2xl space-y-3">
                        <div className="flex items-center gap-1.5 text-xs font-black text-primary">
                          <span>🎨</span>
                          <span>باليت ألوان متكامل للاختيار منه / Choose Theme Palette</span>
                        </div>
                        <p className="text-[10px] text-text-main/70 leading-relaxed">
                          اختر أي مظهر جاهز لتعديل كافة ألوان ترويسة أول الصفحة، الأزرار، الكروت، والخلفية بضغطة زر فورية!
                        </p>
                        <div className="grid grid-cols-1 gap-2">
                          {PALETTES.map((p, idx) => (
                            <button
                              key={idx}
                              type="button"
                              onClick={() => {
                                setColors(p.colors);
                              }}
                              className="w-full text-right bg-card border border-border-main hover:border-primary p-2.5 rounded-xl transition flex items-center justify-between cursor-pointer group shadow-xs"
                            >
                              <span className="text-xs font-bold text-text-main group-hover:text-primary transition-colors">
                                {lang === 'ar' ? p.nameAr : p.nameEn}
                              </span>
                              <div className="flex gap-1 items-center">
                                <span className="w-4 h-4 rounded-full border border-white shadow-xs" style={{ backgroundColor: p.colors.primary }} title="Brand Primary" />
                                <span className="w-4 h-4 rounded-full border border-white shadow-xs" style={{ backgroundColor: p.colors.heroBgStart }} title="Hero Header" />
                                <span className="w-4 h-4 rounded-full border border-white shadow-xs" style={{ backgroundColor: p.colors.bg }} title="Page BG" />
                                <span className="w-4 h-4 rounded-full border border-white shadow-xs" style={{ backgroundColor: p.colors.card }} title="Card BG" />
                              </div>
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold opacity-60">تحرير درجات الألوان الحية</span>
                        <button 
                          onClick={handleResetColors}
                          className="text-[11px] font-bold text-red-500 hover:underline flex items-center gap-1"
                        >
                          <RotateCcw size={12} />
                          {currLang.resetColors}
                        </button>
                      </div>

                      {/* Light Theme Config */}
                      <div className="space-y-3 p-4 bg-bg rounded-2xl border border-border-main">
                        <h4 className="text-xs font-black text-primary border-b border-border-main pb-2">{currLang.colorsLight}</h4>
                        
                        <div className="flex items-center justify-between text-xs font-semibold">
                          <span>{currLang.primaryColor}</span>
                          <input 
                            type="color" 
                            value={colors.primary || DEFAULT_COLORS.primary} 
                            onChange={(e) => setColors({ ...colors, primary: e.target.value })}
                            className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                          />
                        </div>
                        <div className="flex items-center justify-between text-xs font-semibold">
                          <span>{currLang.bgColor}</span>
                          <input 
                            type="color" 
                            value={colors.bg || DEFAULT_COLORS.bg} 
                            onChange={(e) => setColors({ ...colors, bg: e.target.value })}
                            className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                          />
                        </div>
                        <div className="flex items-center justify-between text-xs font-semibold">
                          <span>{currLang.cardColor}</span>
                          <input 
                            type="color" 
                            value={colors.card || DEFAULT_COLORS.card} 
                            onChange={(e) => setColors({ ...colors, card: e.target.value })}
                            className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                          />
                        </div>
                        <div className="flex items-center justify-between text-xs font-semibold">
                          <span>{currLang.textColor}</span>
                          <input 
                            type="color" 
                            value={colors.text || DEFAULT_COLORS.text} 
                            onChange={(e) => setColors({ ...colors, text: e.target.value })}
                            className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                          />
                        </div>
                        <div className="flex items-center justify-between text-xs font-semibold">
                          <span>{currLang.borderColor}</span>
                          <input 
                            type="color" 
                            value={colors.border || DEFAULT_COLORS.border} 
                            onChange={(e) => setColors({ ...colors, border: e.target.value })}
                            className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                          />
                        </div>
                        
                        {/* More options */}
                        <div className="flex items-center justify-between text-xs font-semibold border-t border-border-main/50 pt-2">
                          <span>خلفية الهيدر / Header Bg</span>
                          <input 
                            type="color" 
                            value={colors.headerBg || DEFAULT_COLORS.headerBg} 
                            onChange={(e) => setColors({ ...colors, headerBg: e.target.value })}
                            className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                          />
                        </div>
                        <div className="flex items-center justify-between text-xs font-semibold">
                          <span>خلفية الفوتر / Footer Bg</span>
                          <input 
                            type="color" 
                            value={colors.footerBg || DEFAULT_COLORS.footerBg} 
                            onChange={(e) => setColors({ ...colors, footerBg: e.target.value })}
                            className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                          />
                        </div>
                        <div className="flex items-center justify-between text-xs font-semibold">
                          <span>بداية تدرج الهيرو / Hero Bg Start</span>
                          <input 
                            type="color" 
                            value={colors.heroBgStart || DEFAULT_COLORS.heroBgStart} 
                            onChange={(e) => setColors({ ...colors, heroBgStart: e.target.value })}
                            className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                          />
                        </div>
                        <div className="flex items-center justify-between text-xs font-semibold">
                          <span>نهاية تدرج الهيرو / Hero Bg End</span>
                          <input 
                            type="color" 
                            value={colors.heroBgEnd || DEFAULT_COLORS.heroBgEnd} 
                            onChange={(e) => setColors({ ...colors, heroBgEnd: e.target.value })}
                            className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                          />
                        </div>
                        <div className="flex items-center justify-between text-xs font-semibold">
                          <span>خلفية كروت السلايدر / Slider Card Bg</span>
                          <input 
                            type="color" 
                            value={colors.sliderCardBg || DEFAULT_COLORS.sliderCardBg} 
                            onChange={(e) => setColors({ ...colors, sliderCardBg: e.target.value })}
                            className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                          />
                        </div>
                        <div className="flex items-center justify-between text-xs font-semibold">
                          <span>لون نص السلايدر / Slider Card Text</span>
                          <input 
                            type="color" 
                            value={colors.sliderCardText || DEFAULT_COLORS.sliderCardText} 
                            onChange={(e) => setColors({ ...colors, sliderCardText: e.target.value })}
                            className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                          />
                        </div>
                      </div>

                      {/* Dark Theme Config */}
                      <div className="space-y-3 p-4 bg-bg rounded-2xl border border-border-main">
                        <h4 className="text-xs font-black text-primary border-b border-border-main pb-2">{currLang.colorsDark}</h4>
                        
                        <div className="flex items-center justify-between text-xs font-semibold">
                          <span>{currLang.primaryColor}</span>
                          <input 
                            type="color" 
                            value={colors.darkPrimary || DEFAULT_COLORS.darkPrimary} 
                            onChange={(e) => setColors({ ...colors, darkPrimary: e.target.value })}
                            className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                          />
                        </div>
                        <div className="flex items-center justify-between text-xs font-semibold">
                          <span>{currLang.bgColor}</span>
                          <input 
                            type="color" 
                            value={colors.darkBg || DEFAULT_COLORS.darkBg} 
                            onChange={(e) => setColors({ ...colors, darkBg: e.target.value })}
                            className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                          />
                        </div>
                        <div className="flex items-center justify-between text-xs font-semibold">
                          <span>{currLang.cardColor}</span>
                          <input 
                            type="color" 
                            value={colors.darkCard || DEFAULT_COLORS.darkCard} 
                            onChange={(e) => setColors({ ...colors, darkCard: e.target.value })}
                            className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                          />
                        </div>
                        <div className="flex items-center justify-between text-xs font-semibold">
                          <span>{currLang.textColor}</span>
                          <input 
                            type="color" 
                            value={colors.darkText || DEFAULT_COLORS.darkText} 
                            onChange={(e) => setColors({ ...colors, darkText: e.target.value })}
                            className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                          />
                        </div>
                        <div className="flex items-center justify-between text-xs font-semibold">
                          <span>{currLang.borderColor}</span>
                          <input 
                            type="color" 
                            value={colors.darkBorder || DEFAULT_COLORS.darkBorder} 
                            onChange={(e) => setColors({ ...colors, darkBorder: e.target.value })}
                            className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                          />
                        </div>

                        {/* More options dark */}
                        <div className="flex items-center justify-between text-xs font-semibold border-t border-border-main/50 pt-2">
                          <span>خلفية الهيدر / Header Bg (Dark)</span>
                          <input 
                            type="color" 
                            value={colors.darkHeaderBg || DEFAULT_COLORS.darkHeaderBg} 
                            onChange={(e) => setColors({ ...colors, darkHeaderBg: e.target.value })}
                            className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                          />
                        </div>
                        <div className="flex items-center justify-between text-xs font-semibold">
                          <span>خلفية الفوتر / Footer Bg (Dark)</span>
                          <input 
                            type="color" 
                            value={colors.darkFooterBg || DEFAULT_COLORS.darkFooterBg} 
                            onChange={(e) => setColors({ ...colors, darkFooterBg: e.target.value })}
                            className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                          />
                        </div>
                        <div className="flex items-center justify-between text-xs font-semibold">
                          <span>بداية تدرج الهيرو / Hero Bg Start (Dark)</span>
                          <input 
                            type="color" 
                            value={colors.darkHeroBgStart || DEFAULT_COLORS.darkHeroBgStart} 
                            onChange={(e) => setColors({ ...colors, darkHeroBgStart: e.target.value })}
                            className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                          />
                        </div>
                        <div className="flex items-center justify-between text-xs font-semibold">
                          <span>نهاية تدرج الهيرو / Hero Bg End (Dark)</span>
                          <input 
                            type="color" 
                            value={colors.darkHeroBgEnd || DEFAULT_COLORS.darkHeroBgEnd} 
                            onChange={(e) => setColors({ ...colors, darkHeroBgEnd: e.target.value })}
                            className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                          />
                        </div>
                        <div className="flex items-center justify-between text-xs font-semibold">
                          <span>خلفية كروت السلايدر / Slider Card Bg (Dark)</span>
                          <input 
                            type="color" 
                            value={colors.darkSliderCardBg || DEFAULT_COLORS.darkSliderCardBg} 
                            onChange={(e) => setColors({ ...colors, darkSliderCardBg: e.target.value })}
                            className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                          />
                        </div>
                        <div className="flex items-center justify-between text-xs font-semibold">
                          <span>لون نص السلايدر / Slider Card Text (Dark)</span>
                          <input 
                            type="color" 
                            value={colors.darkSliderCardText || DEFAULT_COLORS.darkSliderCardText} 
                            onChange={(e) => setColors({ ...colors, darkSliderCardText: e.target.value })}
                            className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Tab: Manage Hero Banner */}
                  {activeAdminTab === 'hero' && (
                    <div className="space-y-6">
                      <div className="p-4 bg-primary/5 border border-primary/20 rounded-2xl space-y-4">
                        <div className="flex items-center gap-2 pb-2 border-b border-border-main/50 text-xs font-black text-primary">
                          <span>👑</span>
                          <span>تعديل شرائح سلايدر الهيرو / Edit Hero Slides</span>
                        </div>
                        <p className="text-[10px] text-text-main opacity-70 leading-relaxed">
                          موقعك الآن مجهز بسلايدر شو ديناميكي ومتحرك تلقائياً بجاذبية عالية. يمكنك اختيار الشريحة المطلوبة وتعديل نصوصها وخلفيتها واتجاه حركتها بشكل منفصل!
                        </p>

                        {/* Slide Selector */}
                        <div className="space-y-1 bg-primary/10 p-3 rounded-xl border border-primary/20">
                          <label className="text-[10px] font-black text-primary block mb-1">
                            {lang === 'ar' ? 'اختر شريحة البانر لتعديلها' : 'Select Slide to Edit'}
                          </label>
                          <div className="grid grid-cols-3 gap-2">
                            {heroSlides.map((slide, idx) => (
                              <button
                                key={slide.id}
                                type="button"
                                onClick={() => setSelectedSlideEditIndex(idx)}
                                className={`py-2 px-1 rounded-lg text-[10px] font-bold border transition-all cursor-pointer ${selectedSlideEditIndex === idx ? 'bg-primary text-white border-primary shadow-sm' : 'bg-card border-border-main text-text-main opacity-70 hover:opacity-100'}`}
                              >
                                {lang === 'ar' ? `الشريحة ${idx + 1}` : `Slide ${idx + 1}`}
                              </button>
                            ))}
                          </div>
                          
                          <div className="grid grid-cols-2 gap-2 pt-2 border-t border-primary/20 mt-2">
                            <button
                              type="button"
                              onClick={handleAddHeroSlide}
                              className="py-2 px-1.5 rounded-lg text-[10px] font-black bg-emerald-500 hover:bg-emerald-600 text-white flex items-center justify-center gap-1 shadow transition-all cursor-pointer"
                            >
                              <span>➕</span>
                              <span>{lang === 'ar' ? 'إضافة شريحة جديدة' : 'Add New Slide'}</span>
                            </button>
                            <button
                              type="button"
                              disabled={heroSlides.length <= 1}
                              onClick={() => {
                                if (confirm(lang === 'ar' ? 'هل أنت متأكد من حذف هذه الشريحة؟' : 'Are you sure you want to delete this slide?')) {
                                  handleDeleteHeroSlide(selectedSlideEditIndex);
                                }
                              }}
                              className={`py-2 px-1.5 rounded-lg text-[10px] font-black flex items-center justify-center gap-1 shadow transition-all cursor-pointer ${heroSlides.length <= 1 ? 'bg-slate-300 dark:bg-slate-800 text-text-main/40 cursor-not-allowed opacity-50' : 'bg-red-500 hover:bg-red-600 text-white'}`}
                            >
                              <span>🗑️</span>
                              <span>{lang === 'ar' ? 'حذف الشريحة الحالية' : 'Delete Current Slide'}</span>
                            </button>
                          </div>

                          <span className="text-[8px] text-text-main opacity-60 mt-1 block">
                            {lang === 'ar' ? '* التعديلات أدناه تنطبق فوراً على الشريحة المحددة.' : '* The changes below apply instantly to the selected slide.'}
                          </span>
                        </div>

                        {/* Title AR */}
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-primary">العنوان بالعربية (Title - AR)</label>
                          <input 
                            type="text"
                            value={heroConfig.titleAr}
                            onChange={(e) => saveHeroConfig({ ...heroConfig, titleAr: e.target.value })}
                            className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main font-bold"
                          />
                        </div>

                        {/* Title EN */}
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-primary">العنوان بالإنجليزية (Title - EN)</label>
                          <input 
                            type="text"
                            value={heroConfig.titleEn}
                            onChange={(e) => saveHeroConfig({ ...heroConfig, titleEn: e.target.value })}
                            className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main font-bold"
                          />
                        </div>

                        {/* Subtitle AR */}
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-primary">الوصف الفرعي بالعربية (Subtitle - AR)</label>
                          <textarea 
                            value={heroConfig.subAr}
                            rows={2}
                            onChange={(e) => saveHeroConfig({ ...heroConfig, subAr: e.target.value })}
                            className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                          />
                        </div>

                        {/* Subtitle EN */}
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-primary">الوصف الفرعي بالإنجليزية (Subtitle - EN)</label>
                          <textarea 
                            value={heroConfig.subEn}
                            rows={2}
                            onChange={(e) => saveHeroConfig({ ...heroConfig, subEn: e.target.value })}
                            className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                          />
                        </div>

                        {/* Pan Direction Selector */}
                        <div className="space-y-1.5 border-t border-border-main/50 pt-3">
                          <label className="text-[10px] font-black text-primary block">اتجاه حركة البان زووم / Pan Zoom Direction</label>
                          <div className="grid grid-cols-2 gap-2">
                            <button
                              type="button"
                              onClick={() => saveHeroConfig({ ...heroConfig, panDirection: 'right' })}
                              className={`py-2 px-1.5 rounded-xl text-[10px] font-black border transition-all cursor-pointer ${heroConfig.panDirection === 'right' ? 'bg-primary text-white border-primary shadow-sm' : 'bg-card border-border-main text-text-main opacity-70 hover:opacity-100'}`}
                            >
                              ➡️ {lang === 'ar' ? 'تحرك لليمين (Pan Right)' : 'Pan Right'}
                            </button>
                            <button
                              type="button"
                              onClick={() => saveHeroConfig({ ...heroConfig, panDirection: 'left' })}
                              className={`py-2 px-1.5 rounded-xl text-[10px] font-black border transition-all cursor-pointer ${heroConfig.panDirection === 'left' ? 'bg-primary text-white border-primary shadow-sm' : 'bg-card border-border-main text-text-main opacity-70 hover:opacity-100'}`}
                            >
                              ⬅️ {lang === 'ar' ? 'تحرك لليسار (Pan Left)' : 'Pan Left'}
                            </button>
                          </div>
                        </div>

                        {/* Background Style Selectors */}
                        <div className="space-y-2 border-t border-border-main/50 pt-3">
                          <label className="text-[10px] font-black text-primary block">نمط خلفية الشريحة / Slide Background Style</label>
                          <div className="grid grid-cols-3 gap-2">
                            <button
                              type="button"
                              onClick={() => saveHeroConfig({ ...heroConfig, bgType: 'gradient' })}
                              className={`py-2 px-1.5 rounded-xl text-[10px] font-black border transition-all cursor-pointer ${heroConfig.bgType === 'gradient' ? 'bg-primary text-white border-primary shadow-sm' : 'bg-card border-border-main text-text-main opacity-70 hover:opacity-100'}`}
                            >
                              🌈 {lang === 'ar' ? 'تدرج لوني' : 'Gradient'}
                            </button>
                            <button
                              type="button"
                              onClick={() => saveHeroConfig({ ...heroConfig, bgType: 'color' })}
                              className={`py-2 px-1.5 rounded-xl text-[10px] font-black border transition-all cursor-pointer ${heroConfig.bgType === 'color' ? 'bg-primary text-white border-primary shadow-sm' : 'bg-card border-border-main text-text-main opacity-70 hover:opacity-100'}`}
                            >
                              🎨 {lang === 'ar' ? 'لون مصمت' : 'Solid Color'}
                            </button>
                            <button
                              type="button"
                              onClick={() => saveHeroConfig({ ...heroConfig, bgType: 'image' })}
                              className={`py-2 px-1.5 rounded-xl text-[10px] font-black border transition-all cursor-pointer ${heroConfig.bgType === 'image' ? 'bg-primary text-white border-primary shadow-sm' : 'bg-card border-border-main text-text-main opacity-70 hover:opacity-100'}`}
                            >
                              🖼️ {lang === 'ar' ? 'صورة مخصصة' : 'Custom Image'}
                            </button>
                          </div>
                        </div>

                        {/* Solid color picker */}
                        {heroConfig.bgType === 'color' && (
                          <div className="flex items-center justify-between text-xs font-semibold p-2 bg-bg rounded-lg border border-border-main/50 animate-fadeIn">
                            <span className="text-[10px] font-bold">اختر لون الخلفية / Select Solid Color</span>
                            <input 
                              type="color" 
                              value={heroConfig.solidColor || '#4f46e5'} 
                              onChange={(e) => saveHeroConfig({ ...heroConfig, solidColor: e.target.value })}
                              className="w-10 h-10 rounded-xl cursor-pointer border-0 bg-transparent"
                            />
                          </div>
                        )}

                        {/* Image URL input */}
                        {heroConfig.bgType === 'image' && (
                          <div className="space-y-2 p-2.5 bg-bg rounded-lg border border-border-main/50 animate-fadeIn">
                            <label className="text-[10px] font-bold block">رابط صورة الخلفية / Background Image URL</label>
                            <input 
                              type="text" 
                              placeholder="https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?q=80..." 
                              value={heroConfig.bgImageUrl || ''}
                              onChange={(e) => saveHeroConfig({ ...heroConfig, bgImageUrl: e.target.value })}
                              className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                            />
                            
                            {/* Computer Upload */}
                            <div className="space-y-1 mt-2">
                              <label className="text-[10px] font-black text-primary block">أو رفع صورة من جهاز الكمبيوتر / Or Upload from Computer</label>
                              <input 
                                type="file" 
                                accept="image/*"
                                onChange={(e) => {
                                  const file = e.target.files?.[0];
                                  if (file) {
                                    const reader = new FileReader();
                                    reader.onloadend = () => {
                                      saveHeroConfig({ ...heroConfig, bgImageUrl: reader.result as string });
                                    };
                                    reader.readAsDataURL(file);
                                  }
                                }}
                                className="w-full text-xs p-1.5 rounded-lg border border-border-main bg-card text-text-main file:mr-2 file:py-1 file:px-2.5 file:rounded-md file:border-0 file:text-[9px] file:font-bold file:bg-primary file:text-white hover:file:opacity-90 cursor-pointer"
                              />
                            </div>

                            <span className="text-[9px] text-text-main opacity-50 block leading-tight pt-1">
                              * يفضل استخدام روابط صور عالية الدقة أو رفع ملفات صور مباشرة من جهازك للحصول على مظهر ممتاز.
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Tab 2: Manage Stores */}
                  {activeAdminTab === 'stores' && (
                    <div className="space-y-6">
                      <form onSubmit={handleAddStore} className="space-y-4 p-4 bg-bg rounded-2xl border border-border-main">
                        <h4 className="text-xs font-black text-primary flex items-center gap-1.5 pb-2 border-b border-border-main">
                          <Plus size={14} />
                          {editingStoreId !== null 
                            ? (lang === 'ar' ? 'تعديل بيانات المتجر / Edit Store' : 'Edit Store Details') 
                            : currLang.addStore}
                        </h4>

                        {copiedStoreName && (
                          <div className="p-2.5 bg-primary/10 border border-primary/20 text-primary rounded-xl text-[10px] flex items-center justify-between gap-2 animate-fadeIn">
                            <span className="font-bold">
                              {lang === 'ar' 
                                ? `✨ تم نسخ مظهر وإعدادات متجر: (${copiedStoreName}) بنجاح! يمكنك تعديل الرمز والرابط الآن لحفظه كمتجر جديد.` 
                                : `✨ Copied settings from store: (${copiedStoreName}) successfully! You can modify the code and link to save as a new store.`}
                            </span>
                            <button
                              type="button"
                              onClick={() => {
                                setCopiedStoreName(null);
                                setNewStore({ name: '', nameAr: '', discount: '', code: '', link: 'https://', logo: '', customBg: '', customText: '', bgType: 'color', bgImageUrl: '', category: 'fashion', expiryDate: '' });
                              }}
                              className="text-red-500 hover:underline font-black shrink-0 cursor-pointer text-[10px]"
                            >
                              {lang === 'ar' ? 'إعادة تعيين / Reset' : 'Reset'}
                            </button>
                          </div>
                        )}
                        
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold opacity-70">{currLang.storeNameAr}</label>
                          <input 
                            type="text" 
                            placeholder="أمازون، نون..." 
                            value={newStore.nameAr}
                            onChange={(e) => setNewStore({ ...newStore, nameAr: e.target.value })}
                            className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-bold opacity-70">{currLang.storeNameEn}</label>
                          <input 
                            type="text" 
                            placeholder="Amazon, Noon..." 
                            value={newStore.name}
                            onChange={(e) => setNewStore({ ...newStore, name: e.target.value })}
                            className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                            required
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-bold opacity-70">{currLang.discountPercent}</label>
                          <input 
                            type="text" 
                            placeholder="خصم 10%، Up to 50%..." 
                            value={newStore.discount}
                            onChange={(e) => setNewStore({ ...newStore, discount: e.target.value })}
                            className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-bold opacity-70">{currLang.couponCode}</label>
                          <input 
                            type="text" 
                            placeholder="NOON50, AMAZON10..." 
                            value={newStore.code}
                            onChange={(e) => setNewStore({ ...newStore, code: e.target.value })}
                            className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                            required
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-bold opacity-70">{currLang.storeLink}</label>
                          <input 
                            type="text" 
                            value={newStore.link}
                            onChange={(e) => setNewStore({ ...newStore, link: e.target.value })}
                            className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                          />
                        </div>

                        {/* Store Category Selector */}
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-primary block">فئة المتجر / Store Category</label>
                          <select
                            value={newStore.category || 'fashion'}
                            onChange={(e) => setNewStore({ ...newStore, category: e.target.value })}
                            className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                          >
                            {CATEGORIES.map((cat) => (
                              <option key={cat.id} value={cat.id}>
                                {lang === 'ar' ? cat.nameAr : cat.nameEn}
                              </option>
                            ))}
                          </select>
                        </div>

                        {/* Target Country Selector for Regional affiliate links */}
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-primary block">الدولة المستهدفة / Target Country</label>
                          <select
                            value={newStore.country || 'all'}
                            onChange={(e) => setNewStore({ ...newStore, country: e.target.value })}
                            className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                          >
                            {COUNTRIES.map((country) => (
                              <option key={country.id} value={country.id}>
                                {country.flag} {lang === 'ar' ? country.nameAr : country.nameEn}
                              </option>
                            ))}
                          </select>
                          <span className="text-[9px] text-text-main/50 leading-tight block">
                            {lang === 'ar' 
                              ? 'قم بتحديد الدولة لهذا الرابط. إذا كان لديك روابط متعددة لنفس المتجر (مثلاً نون السعودية ونون مصر)، قم بعمل متجر منفصل لكل رابط مع اختيار دولته (الخيار الأول).' 
                              : 'Select the target country for this link. If you have separate links for regional stores (e.g., Noon SA and Noon EG), create a separate store for each with its respective country selected (Option 1).'}
                          </span>
                        </div>

                        {/* Expiry Date Input */}
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-primary block">{currLang.expiryDate}</label>
                          <input 
                            type="date" 
                            value={newStore.expiryDate || ''}
                            onChange={(e) => setNewStore({ ...newStore, expiryDate: e.target.value })}
                            className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-bold opacity-70">{currLang.logoUrl}</label>
                          <input 
                            type="text" 
                            placeholder="https://..." 
                            value={newStore.logo}
                            onChange={(e) => setNewStore({ ...newStore, logo: e.target.value })}
                            className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                          />
                          {/* Logo file upload */}
                          <div className="space-y-1 mt-1">
                            <label className="text-[9px] font-black text-primary block">أو رفع شعار من جهازك / Or Upload Logo from Computer</label>
                            <input 
                              type="file" 
                              accept="image/*"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  const reader = new FileReader();
                                  reader.onloadend = () => {
                                    setNewStore({ ...newStore, logo: reader.result as string });
                                  };
                                  reader.readAsDataURL(file);
                                }
                              }}
                              className="w-full text-xs p-1.5 rounded-lg border border-border-main bg-card text-text-main file:mr-2 file:py-1 file:px-2 file:rounded-md file:border-0 file:text-[9px] file:font-bold file:bg-primary file:text-white hover:file:opacity-90 cursor-pointer"
                            />
                          </div>
                        </div>

                        {/* Custom background style selectors */}
                        <div className="space-y-2 border-t border-border-main/50 pt-2">
                          <label className="text-[10px] font-black text-primary block">خلفية كرت المتجر في السلايدر شو / Slide Background Style</label>
                          <div className="grid grid-cols-3 gap-1">
                            <button
                              type="button"
                              onClick={() => setNewStore({ ...newStore, bgType: 'color' })}
                              className={`py-1.5 px-1 rounded-lg text-[10px] font-bold border transition ${newStore.bgType === 'color' ? 'bg-primary text-white border-primary' : 'bg-card border-border-main text-text-main opacity-70 hover:opacity-100'}`}
                            >
                              {lang === 'ar' ? 'لون مخصص' : 'Custom Color'}
                            </button>
                            <button
                              type="button"
                              onClick={() => setNewStore({ ...newStore, bgType: 'image' })}
                              className={`py-1.5 px-1 rounded-lg text-[10px] font-bold border transition ${newStore.bgType === 'image' ? 'bg-primary text-white border-primary' : 'bg-card border-border-main text-text-main opacity-70 hover:opacity-100'}`}
                            >
                              {lang === 'ar' ? 'صورة مخصصة' : 'Custom Image'}
                            </button>
                            <button
                              type="button"
                              onClick={() => setNewStore({ ...newStore, bgType: 'logoBlur' })}
                              className={`py-1.5 px-1 rounded-lg text-[10px] font-bold border transition ${newStore.bgType === 'logoBlur' ? 'bg-primary text-white border-primary' : 'bg-card border-border-main text-text-main opacity-70 hover:opacity-100'}`}
                            >
                              {lang === 'ar' ? 'لوجو مموه' : 'Blurred Logo'}
                            </button>
                          </div>
                        </div>

                        {newStore.bgType === 'image' && (
                          <div className="space-y-1 animate-fadeIn">
                            <label className="text-[10px] font-bold opacity-70">رابط صورة الخلفية / Background Image URL</label>
                            <input 
                              type="text" 
                              placeholder="https://images.unsplash.com/photo-..." 
                              value={newStore.bgImageUrl || ''}
                              onChange={(e) => setNewStore({ ...newStore, bgImageUrl: e.target.value })}
                              className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                            />
                            {/* Background image file upload */}
                            <div className="space-y-1 mt-1">
                              <label className="text-[9px] font-black text-primary block">أو رفع صورة خلفية من جهازك / Or Upload Background from Computer</label>
                              <input 
                                type="file" 
                                accept="image/*"
                                onChange={(e) => {
                                  const file = e.target.files?.[0];
                                  if (file) {
                                    const reader = new FileReader();
                                    reader.onloadend = () => {
                                      setNewStore({ ...newStore, bgImageUrl: reader.result as string });
                                    };
                                    reader.readAsDataURL(file);
                                  }
                                }}
                                className="w-full text-xs p-1.5 rounded-lg border border-border-main bg-card text-text-main file:mr-2 file:py-1 file:px-2 file:rounded-md file:border-0 file:text-[9px] file:font-bold file:bg-primary file:text-white hover:file:opacity-90 cursor-pointer"
                              />
                            </div>
                          </div>
                        )}

                        {newStore.bgType === 'color' && (
                          <div className="grid grid-cols-2 gap-2 border-t border-border-main/50 pt-2">
                            <div className="space-y-1">
                              <label className="text-[9px] font-bold opacity-70">خلفية مخصصة للبطاقة / Custom Bg</label>
                              <div className="flex gap-1.5 items-center">
                                <input 
                                  type="color" 
                                  value={newStore.customBg || '#ffffff'} 
                                  onChange={(e) => setNewStore({ ...newStore, customBg: e.target.value })}
                                  className="w-7 h-7 rounded cursor-pointer border bg-transparent"
                                />
                                <button 
                                  type="button"
                                  onClick={() => setNewStore({ ...newStore, customBg: '' })}
                                  className="text-[10px] text-red-500 hover:underline"
                                >
                                  {lang === 'ar' ? 'افتراضي' : 'Default'}
                                </button>
                              </div>
                            </div>
                            <div className="space-y-1">
                              <label className="text-[9px] font-bold opacity-70">لون نص مخصص للبطاقة / Custom Text</label>
                              <div className="flex gap-1.5 items-center">
                                <input 
                                  type="color" 
                                  value={newStore.customText || '#000000'} 
                                  onChange={(e) => setNewStore({ ...newStore, customText: e.target.value })}
                                  className="w-7 h-7 rounded cursor-pointer border bg-transparent"
                                />
                                <button 
                                  type="button"
                                  onClick={() => setNewStore({ ...newStore, customText: '' })}
                                  className="text-[10px] text-red-500 hover:underline"
                                >
                                  {lang === 'ar' ? 'افتراضي' : 'Default'}
                                </button>
                              </div>
                            </div>
                          </div>
                        )}

                        <div className="flex gap-2">
                          {editingStoreId !== null && (
                            <button 
                              type="button" 
                              onClick={() => {
                                setEditingStoreId(null);
                                setNewStore({ name: '', nameAr: '', discount: '', code: '', link: 'https://', logo: '', customBg: '', customText: '', bgType: 'color', bgImageUrl: '', category: 'fashion', expiryDate: '', country: 'all' });
                              }}
                              className="w-1/3 bg-slate-500 text-white font-bold py-2.5 rounded-lg text-xs hover:opacity-90 transition-opacity cursor-pointer"
                            >
                              {lang === 'ar' ? 'إلغاء' : 'Cancel'}
                            </button>
                          )}
                          <button 
                            type="submit" 
                            className={`font-bold py-2.5 rounded-lg text-xs hover:opacity-90 transition-opacity flex-1 text-white bg-primary cursor-pointer`}
                          >
                            {editingStoreId !== null 
                              ? (lang === 'ar' ? 'حفظ التعديلات / Save' : 'Save Changes') 
                              : currLang.submitAdd}
                          </button>
                        </div>
                      </form>

                      {/* Existing Stores List */}
                      <div className="space-y-2">
                        <span className="text-xs font-bold opacity-60">المتاجر المضافة حالياً ({stores.length})</span>
                        <div className="space-y-1.5 max-h-48 overflow-y-auto">
                          {stores.map((store: any) => (
                            <div key={store.id} className="p-3 bg-bg border border-border-main rounded-xl flex items-center justify-between text-xs">
                              <div className="flex items-center gap-2">
                                <div className="w-8 h-5 flex items-center justify-center bg-white dark:bg-slate-900 rounded border border-neutral-200 dark:border-neutral-800 p-0.5 overflow-hidden shrink-0">
                                  <StoreLogo logo={store.logo} name={store.name} nameAr={store.nameAr} className="max-w-full max-h-full object-contain" />
                                </div>
                                <div className="flex flex-col text-right">
                                  <span className="font-bold text-slate-900 dark:text-white">{lang === 'ar' ? (store.nameAr || store.name) : store.name}</span>
                                  <span className="opacity-50 text-[10px] font-mono">({store.code})</span>
                                  <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                                    <span className="text-[9px] text-primary font-bold">
                                      📁 {CATEGORIES.find((c) => c.id === store.category)?.nameAr || store.category || 'عام / General'}
                                    </span>
                                    {store.country && store.country !== 'all' && COUNTRIES_MAP[store.country] && (
                                      <span className="text-[9px] bg-primary/10 text-primary px-1 py-0.5 rounded font-black flex items-center gap-0.5">
                                        {COUNTRIES_MAP[store.country].flag} {lang === 'ar' ? COUNTRIES_MAP[store.country].nameAr : COUNTRIES_MAP[store.country].nameEn}
                                      </span>
                                    )}
                                  </div>
                                </div>
                              </div>
                              <div className="flex items-center gap-1.5">
                                <button 
                                  type="button"
                                  onClick={() => {
                                    setEditingStoreId(null);
                                    setCopiedStoreName(store.nameAr || store.name);
                                    setNewStore({
                                      name: (store.name || '') + ' Copy',
                                      nameAr: (store.nameAr || '') + ' - نسخة',
                                      discount: store.discount || '',
                                      code: (store.code || '') + '_NEW',
                                      link: store.link || 'https://',
                                      logo: store.logo || '',
                                      customBg: store.customBg || '',
                                      customText: store.customText || '',
                                      bgType: store.bgType || 'color',
                                      bgImageUrl: store.bgImageUrl || '',
                                      category: store.category || 'fashion',
                                      expiryDate: store.expiryDate || '',
                                      country: store.country || 'all'
                                    });
                                    // Scroll to form smoothly
                                    const formEl = document.querySelector('form');
                                    if (formEl) formEl.scrollIntoView({ behavior: 'smooth' });
                                    pushNotification(
                                      'coupon',
                                      `تم نسخ إعدادات متجر ${store.nameAr || store.name} إلى النموذج!`,
                                      `Copied settings of ${store.name} to form!`
                                    );
                                  }}
                                  className="p-1.5 bg-indigo-500/10 text-indigo-500 hover:bg-indigo-500/20 rounded-lg text-[10px] font-bold flex items-center gap-0.5 cursor-pointer"
                                  title={lang === 'ar' ? 'نسخ إعدادات هذا المتجر لعمل متجر آخر بنفس الإعدادات' : 'Copy settings to create another store'}
                                >
                                  <Copy size={12} />
                                  <span>{lang === 'ar' ? 'نسخ' : 'Copy'}</span>
                                </button>
                                <button 
                                  type="button"
                                  onClick={() => {
                                    setEditingStoreId(store.id);
                                    setCopiedStoreName(null);
                                    setNewStore({
                                      name: store.name || '',
                                      nameAr: store.nameAr || '',
                                      discount: store.discount || '',
                                      code: store.code || '',
                                      link: store.link || 'https://',
                                      logo: store.logo || '',
                                      customBg: store.customBg || '',
                                      customText: store.customText || '',
                                      bgType: store.bgType || 'color',
                                      bgImageUrl: store.bgImageUrl || '',
                                      category: store.category || 'fashion',
                                      expiryDate: store.expiryDate || '',
                                      country: store.country || 'all'
                                    });
                                  }}
                                  className="p-1.5 bg-primary/10 text-primary hover:bg-primary/20 rounded-lg text-[10px] font-bold flex items-center gap-0.5 cursor-pointer"
                                  title={lang === 'ar' ? 'تعديل بيانات المتجر' : 'Edit store details'}
                                >
                                  <Edit3 size={12} />
                                  <span>{lang === 'ar' ? 'تعديل' : 'Edit'}</span>
                                </button>
                                <button 
                                  onClick={() => handleDeleteStore(store.id)}
                                  className="p-1.5 hover:bg-red-500/10 text-red-500 rounded cursor-pointer"
                                >
                                  <Trash2 size={14} />
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Tab 3: Manage Articles */}
                  {activeAdminTab === 'articles' && (
                    <div className="space-y-6">
                      <form onSubmit={handleAddArticle} className="space-y-4 p-4 bg-bg rounded-2xl border border-border-main">
                        <h4 className="text-xs font-black text-primary flex items-center gap-1.5 pb-2 border-b border-border-main">
                          <Plus size={14} />
                          {currLang.addArticle}
                        </h4>
                        
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold opacity-70">{currLang.articleTitleAr}</label>
                          <input 
                            type="text" 
                            placeholder="أسرار التوفير..." 
                            value={newArticle.title}
                            onChange={(e) => setNewArticle({ ...newArticle, title: e.target.value })}
                            className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                            required
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-bold opacity-70">{currLang.articleTitleEn}</label>
                          <input 
                            type="text" 
                            placeholder="Saving secrets..." 
                            value={newArticle.titleEn}
                            onChange={(e) => setNewArticle({ ...newArticle, titleEn: e.target.value })}
                            className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-bold opacity-70">{currLang.articleContent}</label>
                          <textarea 
                            rows={3}
                            placeholder="محتوى المقال..." 
                            value={newArticle.text}
                            onChange={(e) => setNewArticle({ ...newArticle, text: e.target.value })}
                            className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                            required
                          />
                        </div>

                        {/* Interactive Coupon/Link options inside the article */}
                        <div className="bg-card/40 rounded-2xl border border-primary/20 p-4 space-y-4 shadow-sm">
                          <div className="flex items-center justify-between pb-2 border-b border-border-main/50">
                            <div className="flex items-center gap-2">
                              <span className="text-xl">🎫</span>
                              <div>
                                <h5 className="text-xs font-black text-primary">{lang === 'ar' ? 'صندوق الكوبون الترويجي ورابط الإحالة المخصص' : 'Promo Coupon & Referral Link Slot'}</h5>
                                <p className="text-[9px] text-text-main opacity-60">{lang === 'ar' ? 'سيتم إنشاء كارت تفاعلي جذاب وتلقائي في نهاية المقال لزيادة الأرباح' : 'Creates an interactive CTA card at the bottom of the article to boost conversions'}</p>
                              </div>
                            </div>
                            <div className="flex items-center gap-1.5">
                              <input 
                                type="checkbox" 
                                id="hasCoupon" 
                                checked={newArticle.hasCoupon} 
                                onChange={(e) => setNewArticle({ ...newArticle, hasCoupon: e.target.checked })}
                                className="w-4 h-4 rounded text-primary focus:ring-primary cursor-pointer"
                              />
                              <label htmlFor="hasCoupon" className="text-[11px] font-black opacity-80 cursor-pointer">
                                {lang === 'ar' ? 'تفعيل الكارت' : 'Enable Card'}
                              </label>
                            </div>
                          </div>

                          {newArticle.hasCoupon && (
                            <div className="space-y-4 animate-fadeIn">
                              {/* Store Selector & Custom Store Name/Logo */}
                              <div className="space-y-3 p-3 bg-bg/50 rounded-xl border border-border-main/60">
                                <div className="space-y-1">
                                  <label className="text-[10px] font-bold text-primary block">
                                    {lang === 'ar' ? '🛒 اختر المتجر المستهدف' : '🛒 Select Targeted Store'}
                                  </label>
                                  <select 
                                    value={newArticle.storeId}
                                    onChange={(e) => {
                                      const val = e.target.value;
                                      let name = '';
                                      let logo = '';
                                      if (val !== 'custom') {
                                        const found = stores.find((s: any) => String(s.id) === val);
                                        if (found) {
                                          name = found.name;
                                          logo = found.logo;
                                        }
                                      }
                                      setNewArticle({ 
                                        ...newArticle, 
                                        storeId: val,
                                        customStoreName: name,
                                        customStoreLogo: logo
                                      });
                                    }}
                                    className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                                  >
                                    <option value="custom">{lang === 'ar' ? '✍️ متجر مخصص أو غير مدرج (كتابة يدوية)' : '✍️ Custom Store / Manual Entry'}</option>
                                    {stores.map((s: any) => (
                                      <option key={s.id} value={String(s.id)}>
                                        {lang === 'ar' ? s.nameAr || s.name : s.name}
                                      </option>
                                    ))}
                                  </select>
                                </div>

                                {/* Custom store logo & name */}
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                  <div className="space-y-1">
                                    <label className="text-[10px] font-bold opacity-70">{lang === 'ar' ? '✍️ اسم المتجر (مثال: نون)' : 'Store Name'}</label>
                                    <input 
                                      type="text" 
                                      placeholder="Noon, Amazon..." 
                                      value={newArticle.customStoreName}
                                      onChange={(e) => setNewArticle({ ...newArticle, customStoreName: e.target.value })}
                                      className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                                    />
                                  </div>
                                  <div className="space-y-1">
                                    <label className="text-[10px] font-bold opacity-70">{lang === 'ar' ? '🔗 رابط لوجو المتجر (اختياري)' : 'Store Logo URL'}</label>
                                    <input 
                                      type="text" 
                                      placeholder="https://..." 
                                      value={newArticle.customStoreLogo}
                                      onChange={(e) => setNewArticle({ ...newArticle, customStoreLogo: e.target.value })}
                                      className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                                    />
                                    {/* Logo file upload from computer */}
                                    <div className="space-y-1 mt-1">
                                      <label className="text-[9px] font-black text-primary block">{lang === 'ar' ? 'أو رفع لوجو من الكمبيوتر' : 'Or Upload Logo from Computer'}</label>
                                      <input 
                                        type="file" 
                                        accept="image/*"
                                        onChange={(e) => {
                                          const file = e.target.files?.[0];
                                          if (file) {
                                            const reader = new FileReader();
                                            reader.onloadend = () => {
                                              setNewArticle({ ...newArticle, customStoreLogo: reader.result as string });
                                            };
                                            reader.readAsDataURL(file);
                                          }
                                        }}
                                        className="w-full text-xs p-1.5 rounded-lg border border-border-main bg-card text-text-main file:mr-2 file:py-1 file:px-2 file:rounded-md file:border-0 file:text-[9px] file:font-bold file:bg-primary file:text-white hover:file:opacity-90 cursor-pointer"
                                      />
                                    </div>
                                  </div>
                                </div>
                              </div>

                              {/* Flag Selection & Discount Info */}
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                <div className="space-y-1">
                                  <label className="text-[10px] font-bold opacity-70">{lang === 'ar' ? '🇸🇦 علم الدولة المستهدفة بالكوبون' : 'Target Country Flag'}</label>
                                  <select 
                                    value={newArticle.countryFlag}
                                    onChange={(e) => setNewArticle({ ...newArticle, countryFlag: e.target.value })}
                                    className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                                  >
                                    <option value="🇸🇦">🇸🇦 السعودية (Saudi)</option>
                                    <option value="🇦🇪">🇦🇪 الإمارات (UAE)</option>
                                    <option value="🇰🇼">🇰🇼 الكويت (Kuwait)</option>
                                    <option value="🇪🇬">🇪🇬 مصر (Egypt)</option>
                                    <option value="🇶🇦">🇶🇦 قطر (Qatar)</option>
                                    <option value="🇧🇭">🇧🇭 البحرين (Bahrain)</option>
                                    <option value="🇴🇲">🇴🇲 عمان (Oman)</option>
                                    <option value="🌎">🌎 عالمي (Global)</option>
                                  </select>
                                </div>
                                <div className="space-y-1">
                                  <label className="text-[10px] font-bold opacity-70">{lang === 'ar' ? '🔥 نسبة الخصم (مثال: خصم 20% إضافي)' : 'Discount Text (e.g. 20% OFF)'}</label>
                                  <input 
                                    type="text" 
                                    placeholder={lang === 'ar' ? 'مثال: خصم 15% إضافي' : 'e.g. 15% Extra discount'} 
                                    value={newArticle.discountText}
                                    onChange={(e) => setNewArticle({ ...newArticle, discountText: e.target.value })}
                                    className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                                  />
                                </div>
                              </div>

                              {/* Coupon Code & Referral Link */}
                              <div className="space-y-3 p-3 bg-primary/5 rounded-xl border border-primary/20">
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                  <div className="space-y-1">
                                    <label className="text-[10px] font-black text-primary block">
                                      {lang === 'ar' ? '🔑 كود الكوبون التسويقي (النسخ)' : '🔑 Coupon Code (for copying)'}
                                    </label>
                                    <input 
                                      type="text" 
                                      placeholder="NOON50, SAUDI10..." 
                                      value={newArticle.couponCode}
                                      onChange={(e) => setNewArticle({ ...newArticle, couponCode: e.target.value })}
                                      className="w-full text-xs p-2.5 rounded-lg border border-primary/30 bg-card focus:outline-none focus:border-primary text-text-main font-mono uppercase tracking-wider"
                                    />
                                  </div>
                                  <div className="space-y-1">
                                    <label className="text-[10px] font-black text-primary block">
                                      {lang === 'ar' ? '🔗 رابط الإحالة المباشر (التحويل)' : '🔗 Direct Referral Link (for routing)'}
                                    </label>
                                    <input 
                                      type="text" 
                                      placeholder="https://noon.com/..." 
                                      value={newArticle.referralLink}
                                      onChange={(e) => setNewArticle({ ...newArticle, referralLink: e.target.value })}
                                      className="w-full text-xs p-2.5 rounded-lg border border-primary/30 bg-card focus:outline-none focus:border-primary text-text-main"
                                    />
                                  </div>
                                </div>
                                <span className="text-[9px] text-text-main opacity-50 block leading-tight">
                                  {lang === 'ar' 
                                    ? '* عند ضغط الزائر على الكوبون، سيتم نسخ الكود تلقائياً وفتح رابط الإحالة الخاص بك في علامة تبويب جديدة.' 
                                    : '* When the visitor clicks, the coupon is copied, and your referral link opens in a new tab.'}
                                </span>
                              </div>
                            </div>
                          )}
                        </div>

                        <button 
                          type="submit" 
                          className="w-full bg-primary text-white font-bold py-2.5 rounded-lg text-xs hover:opacity-90 transition-opacity cursor-pointer"
                        >
                          {currLang.submitAdd}
                        </button>
                      </form>

                      {/* Existing Articles List */}
                      <div className="space-y-2">
                        <span className="text-xs font-bold opacity-60">المقالات الحالية ({articles.length})</span>
                        <div className="space-y-1.5 max-h-48 overflow-y-auto">
                          {articles.map((article: any) => (
                            <div key={article.id} className="p-3 bg-bg border border-border-main rounded-xl flex items-center justify-between text-xs">
                              <span className="font-bold truncate max-w-[200px]">{lang === 'ar' ? article.title : (article.titleEn || article.title)}</span>
                              <button 
                                onClick={() => handleDeleteArticle(article.id)}
                                className="p-1 hover:bg-red-500/10 text-red-500 rounded"
                              >
                                <Trash2 size={14} />
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Tab 4: Social Links */}
                  {activeAdminTab === 'social' && (
                    <div className="space-y-6">
                      <div className="pb-2 border-b border-border-main flex items-center justify-between">
                        <h4 className="text-xs font-black text-primary">
                          {lang === 'ar' ? 'إدارة وسائل التواصل والاتصال / Contact Channels' : 'Manage Contact & Social Channels'}
                        </h4>
                      </div>

                      {/* Footer Contact Info Editor */}
                      <div className="p-4 bg-card border border-border-main rounded-2xl space-y-3.5 shadow-sm">
                        <div className="text-xs font-black text-primary flex items-center gap-1.5">
                          <Settings size={14} />
                          <span>{lang === 'ar' ? 'بيانات التواصل في الفوتر' : 'Footer Contact Info'}</span>
                        </div>
                        <p className="text-[10px] text-text-main opacity-60 leading-relaxed">
                          {lang === 'ar' ? 'أدخل رقم الهاتف والبريد الإلكتروني اللذين سيظهران لزوار الموقع في الفوتر السفلي بشكل دائم.' : 'Specify the phone number and email address to display permanently in the bottom footer.'}
                        </p>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold opacity-70">{lang === 'ar' ? 'رقم الهاتف للتواصل' : 'Contact Phone'}</label>
                            <input 
                              type="text" 
                              value={contactPhone}
                              onChange={(e) => saveContactPhone(e.target.value)}
                              placeholder="+966 54 231 9876"
                              className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main font-semibold"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold opacity-70">{lang === 'ar' ? 'البريد الإلكتروني' : 'Contact Email'}</label>
                            <input 
                              type="email" 
                              value={contactEmail}
                              onChange={(e) => saveContactEmail(e.target.value)}
                              placeholder="mnour.fm@gmail.com"
                              className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main font-semibold"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Contact Page Design (البانر واللوجو لصفحة التواصل) */}
                      <div className="p-4 bg-card border border-border-main rounded-2xl space-y-3.5 shadow-sm">
                        <div className="text-xs font-black text-primary flex items-center gap-1.5">
                          <Brush size={14} />
                          <span>{lang === 'ar' ? 'تصميم هوية صفحة التواصل (البانر واللوجو)' : 'Contact Page Branding (Banner & Logo)'}</span>
                        </div>
                        <p className="text-[10px] text-text-main opacity-60 leading-relaxed">
                          {lang === 'ar' ? 'قم بتخصيص البانر واللوجو اللذين يظهران تلقائياً في صفحة "اتصل بنا" لتعزيز هوية موقعك.' : 'Customize the banner image and logo that appear automatically on your "Contact Us" page.'}
                        </p>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold opacity-70">{lang === 'ar' ? 'رابط صورة البانر (Contact Banner URL)' : 'Contact Banner Image URL'}</label>
                            <input 
                              type="text" 
                              value={contactBannerUrl}
                              onChange={(e) => saveContactBannerUrl(e.target.value)}
                              placeholder="https://images.unsplash.com/..."
                              className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                            />
                            {/* Preset Banner Selector */}
                            <div className="flex gap-1 mt-1">
                              <button
                                type="button"
                                onClick={() => saveContactBannerUrl('https://images.unsplash.com/photo-1616077168712-fc6c788bc4ee?q=80&w=1200&auto=format&fit=crop')}
                                className="text-[9px] bg-bg hover:bg-slate-200 dark:hover:bg-slate-800 px-2 py-0.5 rounded border border-border-main font-semibold cursor-pointer"
                              >
                                🔴 {lang === 'ar' ? 'أحمر ملوّن' : 'Neon Red'}
                              </button>
                              <button
                                type="button"
                                onClick={() => saveContactBannerUrl('https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=1200&auto=format&fit=crop')}
                                className="text-[9px] bg-bg hover:bg-slate-200 dark:hover:bg-slate-800 px-2 py-0.5 rounded border border-border-main font-semibold cursor-pointer"
                              >
                                🟣 {lang === 'ar' ? 'تجريدي بنفسجي' : 'Abstract Purple'}
                              </button>
                              <button
                                type="button"
                                onClick={() => saveContactBannerUrl('https://images.unsplash.com/photo-1557683316-973673baf926?q=80&w=1200&auto=format&fit=crop')}
                                className="text-[9px] bg-bg hover:bg-slate-200 dark:hover:bg-slate-800 px-2 py-0.5 rounded border border-border-main font-semibold cursor-pointer"
                              >
                                🔵 {lang === 'ar' ? 'تدرج كلاسيكي' : 'Classic Gradient'}
                              </button>
                            </div>
                          </div>
                          
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold opacity-70">{lang === 'ar' ? 'رابط صورة اللوجو (Contact Logo URL)' : 'Contact Logo Image URL'}</label>
                            <input 
                              type="text" 
                              value={contactLogoUrl}
                              onChange={(e) => saveContactLogoUrl(e.target.value)}
                              placeholder="https://..."
                              className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                            />
                            {/* Preset Logo Selector */}
                            <div className="flex gap-1 mt-1">
                              <button
                                type="button"
                                onClick={() => saveContactLogoUrl('https://cdn.jsdelivr.net/gh/microsoft/fluentui-emoji@main/assets/Money%20bag/3D/money_bag_3d.png')}
                                className="text-[9px] bg-bg hover:bg-slate-200 dark:hover:bg-slate-800 px-2 py-0.5 rounded border border-border-main font-semibold cursor-pointer"
                              >
                                💰 {lang === 'ar' ? 'حقيبة نقود' : 'Money Bag'}
                              </button>
                              <button
                                type="button"
                                onClick={() => saveContactLogoUrl('https://cdn.jsdelivr.net/gh/microsoft/fluentui-emoji@main/assets/Coin/3D/coin_3d.png')}
                                className="text-[9px] bg-bg hover:bg-slate-200 dark:hover:bg-slate-800 px-2 py-0.5 rounded border border-border-main font-semibold cursor-pointer"
                              >
                                🪙 {lang === 'ar' ? 'عملة ذهبية' : 'Gold Coin'}
                              </button>
                              <button
                                type="button"
                                onClick={() => saveContactLogoUrl('https://cdn.jsdelivr.net/gh/microsoft/fluentui-emoji@main/assets/Nerd%20face/3D/nerd_face_3d.png')}
                                className="text-[9px] bg-bg hover:bg-slate-200 dark:hover:bg-slate-800 px-2 py-0.5 rounded border border-border-main font-semibold cursor-pointer"
                              >
                                🤓 {lang === 'ar' ? 'ذكي' : 'Nerd'}
                              </button>
                            </div>
                          </div>
                        </div>

                        {/* File upload helpers for Contact Banner & Logo */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                          {/* Banner File upload */}
                          <div className="p-3 bg-slate-50 dark:bg-slate-900/60 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center text-center relative hover:bg-slate-100 dark:hover:bg-slate-900 transition-colors">
                            <input 
                              type="file" 
                              accept="image/*"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  const reader = new FileReader();
                                  reader.onloadend = () => {
                                    saveContactBannerUrl(reader.result as string);
                                  };
                                  reader.readAsDataURL(file);
                                }
                              }}
                              className="absolute inset-0 opacity-0 cursor-pointer w-full h-full z-10"
                            />
                            <span className="text-[10px] font-bold text-primary">🖼️ {lang === 'ar' ? 'رفع صورة بانر جديدة' : 'Upload custom banner'}</span>
                          </div>

                          {/* Logo File upload */}
                          <div className="p-3 bg-slate-50 dark:bg-slate-900/60 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center text-center relative hover:bg-slate-100 dark:hover:bg-slate-900 transition-colors">
                            <input 
                              type="file" 
                              accept="image/*"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  const reader = new FileReader();
                                  reader.onloadend = () => {
                                    saveContactLogoUrl(reader.result as string);
                                  };
                                  reader.readAsDataURL(file);
                                }
                              }}
                              className="absolute inset-0 opacity-0 cursor-pointer w-full h-full z-10"
                            />
                            <span className="text-[10px] font-bold text-primary">🎯 {lang === 'ar' ? 'رفع صورة لوجو جديدة' : 'Upload custom logo'}</span>
                          </div>
                        </div>

                        {/* Live Design Preview */}
                        <div className="mt-3 p-3 bg-slate-50 dark:bg-slate-900/30 rounded-2xl border border-border-main/50">
                          <span className="text-[10px] font-black text-slate-500 uppercase block mb-2">{lang === 'ar' ? 'معاينة هوية صفحة التواصل الفورية' : 'Contact Card Branding Live Preview'}</span>
                          <div className="relative h-28 w-full rounded-xl overflow-hidden bg-slate-800 border border-slate-700/30 shadow-inner">
                            <img 
                              src={contactBannerUrl} 
                              alt="Banner Preview" 
                              className="w-full h-full object-cover opacity-70"
                              referrerPolicy="no-referrer"
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                            <div className="absolute bottom-2 left-3 right-3 flex items-center gap-2">
                              <div className="w-10 h-10 rounded-lg bg-card p-1 border border-border-main shadow flex items-center justify-center overflow-hidden">
                                <img 
                                  src={contactLogoUrl} 
                                  alt="Logo Preview" 
                                  className="max-w-full max-h-full object-contain"
                                  referrerPolicy="no-referrer"
                                />
                              </div>
                              <div className="text-white text-left leading-tight">
                                <h6 className="text-[11px] font-black">{lang === 'ar' ? 'اتصل بنا / وفير' : 'Contact Us / Wafeer'}</h6>
                                <p className="text-[8px] text-slate-200">{lang === 'ar' ? 'البانر واللوجو معرّفان تلقائياً' : 'Banner & Logo automatically active'}</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Add New Link Form */}
                      <form onSubmit={handleAddSocialLink} className="p-4 bg-primary/5 border border-primary/20 rounded-2xl space-y-4">
                        <div className="text-xs font-black text-primary flex items-center gap-1">
                          <Plus size={14} />
                          <span>{lang === 'ar' ? 'إضافة وسيلة تواصل جديدة' : 'Add New Contact Channel'}</span>
                        </div>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold opacity-70">{lang === 'ar' ? 'الاسم بالعربية' : 'Arabic Name'}</label>
                            <input 
                              type="text" 
                              required
                              placeholder="مثال: قناتنا على تليجرام"
                              value={newSocialLink.nameAr}
                              onChange={(e) => setNewSocialLink({ ...newSocialLink, nameAr: e.target.value })}
                              className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold opacity-70">{lang === 'ar' ? 'الاسم بالإنجليزية' : 'English Name'}</label>
                            <input 
                              type="text" 
                              required
                              placeholder="e.g. Our Telegram Channel"
                              value={newSocialLink.nameEn}
                              onChange={(e) => setNewSocialLink({ ...newSocialLink, nameEn: e.target.value })}
                              className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold opacity-70">{lang === 'ar' ? 'المنصة' : 'Platform'}</label>
                            <select 
                              value={newSocialLink.platform}
                              onChange={(e) => setNewSocialLink({ ...newSocialLink, platform: e.target.value })}
                              className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                            >
                              <option value="twitter">X / Twitter</option>
                              <option value="instagram">Instagram</option>
                              <option value="facebook">Facebook</option>
                              <option value="whatsapp">WhatsApp</option>
                              <option value="telegram">Telegram</option>
                              <option value="youtube">YouTube</option>
                              <option value="tiktok">TikTok / تيك توك</option>
                              <option value="custom">{lang === 'ar' ? 'أخرى (شعار عالمي)' : 'Other (Generic icon)'}</option>
                            </select>
                          </div>
                          <div className="space-y-1">
                            <label className="text-[10px] font-black text-primary block">{lang === 'ar' ? 'رابط URL المباشر' : 'Direct URL'}</label>
                            <input 
                              type="url" 
                              required
                              placeholder="https://..."
                              value={newSocialLink.url}
                              onChange={(e) => setNewSocialLink({ ...newSocialLink, url: e.target.value })}
                              className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                            />
                          </div>
                        </div>

                        <button 
                          type="submit" 
                          className="w-full bg-primary text-white font-bold py-2 rounded-lg text-xs hover:opacity-90 transition-opacity cursor-pointer flex items-center justify-center gap-1"
                        >
                          <Plus size={14} />
                          <span>{lang === 'ar' ? 'تأكيد الإضافة' : 'Add Channel'}</span>
                        </button>
                      </form>

                      {/* Existing Links Manager */}
                      <div className="space-y-3">
                        <span className="text-xs font-bold opacity-60">
                          {lang === 'ar' ? `وسائل التواصل الحالية (${socialLinks.length})` : `Active Channels (${socialLinks.length})`}
                        </span>
                        
                        <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
                          {socialLinks.map((link: any) => (
                            <div 
                              key={link.id} 
                              className="p-4 bg-bg border border-border-main rounded-2xl space-y-3 relative group"
                            >
                              {/* Header of Item */}
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                  <div className="p-1.5 bg-primary/10 text-primary rounded-lg">
                                    {getSocialIcon(link.platform, link.nameEn || link.nameAr)}
                                  </div>
                                  <span className="text-xs font-black text-text-main uppercase">
                                    {link.platform}
                                  </span>
                                </div>
                                <button 
                                  type="button"
                                  onClick={() => handleDeleteSocialLink(link.id)}
                                  className="text-red-500 hover:text-red-600 p-1.5 hover:bg-red-500/10 rounded-lg transition"
                                  title={lang === 'ar' ? 'حذف القناة' : 'Delete Channel'}
                                >
                                  <Trash2 size={14} />
                                </button>
                              </div>

                              {/* Form to Edit inline */}
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                <div className="space-y-0.5">
                                  <label className="text-[9px] font-bold opacity-50">{lang === 'ar' ? 'الاسم بالعربية' : 'Arabic Name'}</label>
                                  <input 
                                    type="text"
                                    value={link.nameAr || ''}
                                    onChange={(e) => handleUpdateSocialLink(link.id, 'nameAr', e.target.value)}
                                    className="w-full text-[11px] px-2 py-1.5 rounded bg-card border border-border-main focus:outline-none focus:border-primary text-text-main font-semibold"
                                  />
                                </div>
                                <div className="space-y-0.5">
                                  <label className="text-[9px] font-bold opacity-50">{lang === 'ar' ? 'الاسم بالإنجليزية' : 'English Name'}</label>
                                  <input 
                                    type="text"
                                    value={link.nameEn || ''}
                                    onChange={(e) => handleUpdateSocialLink(link.id, 'nameEn', e.target.value)}
                                    className="w-full text-[11px] px-2 py-1.5 rounded bg-card border border-border-main focus:outline-none focus:border-primary text-text-main font-semibold"
                                  />
                                </div>
                              </div>

                              <div className="space-y-0.5">
                                <label className="text-[9px] font-bold opacity-50">{lang === 'ar' ? 'رابط URL' : 'Link URL'}</label>
                                <input 
                                  type="text"
                                  value={link.url || ''}
                                  onChange={(e) => handleUpdateSocialLink(link.id, 'url', e.target.value)}
                                  className="w-full text-[11px] px-2 py-1.5 rounded bg-card border border-border-main focus:outline-none focus:border-primary text-text-main font-mono"
                                />
                              </div>
                            </div>
                          ))}

                          {socialLinks.length === 0 && (
                            <div className="text-center py-6 text-xs text-text-main opacity-50">
                              {lang === 'ar' ? 'لا توجد وسائل تواصل حالية. أضف واحدة أعلاه!' : 'No active social channels. Add one above!'}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Tab 5: Google AdSense Config */}
                  {activeAdminTab === 'ads' && (
                    <div className="space-y-4">
                      <div className="flex items-center gap-2 pb-2 border-b border-border-main">
                        <span className="text-lg">📢</span>
                        <h4 className="text-xs font-black text-primary">
                          مساحات إعلانات جوجل أدسنس / Google AdSense Slots
                        </h4>
                      </div>
                      
                      <p className="text-xs text-text-main/70 leading-relaxed bg-bg p-3 rounded-xl border border-border-main">
                        يمكنك هنا تفعيل أو إيقاف عرض الإعلانات بالكامل في الصفحة الرئيسية والمقالات، وتكوين الرقم التعريفي للناشر وكرت الإعلان.
                      </p>

                      <div className="space-y-3">
                        <div className="p-3 bg-card border border-border-main rounded-xl flex items-center justify-between">
                          <div className="flex flex-col gap-0.5">
                            <span className="text-xs font-bold text-text-main">تفعيل الإعلانات بالموقع / Enable Adsense Banner</span>
                            <span className="text-[10px] opacity-60">عرض أو إخفاء مساحة الإعلان في الصفحة الرئيسية والمودال</span>
                          </div>
                          <label className="relative inline-flex items-center cursor-pointer">
                            <input 
                              type="checkbox" 
                              checked={adConfig.showAds} 
                              onChange={(e) => setAdConfig({ ...adConfig, showAds: e.target.checked })} 
                              className="sr-only peer" 
                            />
                            <div className="w-11 h-6 bg-border-main rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                          </label>
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-bold opacity-70">معرّف الناشر في أدسنس (Publisher Client ID)</label>
                          <input 
                            type="text" 
                            value={adConfig.adClientId} 
                            placeholder="ca-pub-XXXXXXXXXXXXXXXX"
                            onChange={(e) => setAdConfig({ ...adConfig, adClientId: e.target.value })}
                            className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main font-mono"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-bold opacity-70">معرّف مساحة الإعلان (Ad Slot ID)</label>
                          <input 
                            type="text" 
                            value={adConfig.adSlotId} 
                            placeholder="XXXXXXXXXX"
                            onChange={(e) => setAdConfig({ ...adConfig, adSlotId: e.target.value })}
                            className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main font-mono"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-bold opacity-70">رابط بنر إعلاني توضيحي (اختياري / Banner Placeholder Image)</label>
                          <input 
                            type="text" 
                            value={adConfig.adBannerUrl} 
                            placeholder="https://..."
                            onChange={(e) => setAdConfig({ ...adConfig, adBannerUrl: e.target.value })}
                            className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                          />
                        </div>

                        {/* Side Ad Configuration */}
                        <div className="border-t border-border-main/50 pt-4 mt-2 space-y-3">
                          <div className="p-3 bg-card border border-border-main rounded-xl flex items-center justify-between">
                            <div className="flex flex-col gap-0.5">
                              <span className="text-xs font-bold text-text-main">تفعيل الإعلان الجانبي / Enable Sidebar Ad</span>
                              <span className="text-[10px] opacity-60">عرض أو إخفاء مساحة الإعلان في الشريط الجانبي الرئيسي</span>
                            </div>
                            <label className="relative inline-flex items-center cursor-pointer">
                              <input 
                                type="checkbox" 
                                checked={adConfig.showSideAd} 
                                onChange={(e) => setAdConfig({ ...adConfig, showSideAd: e.target.checked })} 
                                className="sr-only peer" 
                              />
                              <div className="w-11 h-6 bg-border-main rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                            </label>
                          </div>

                          {adConfig.showSideAd && (
                            <div className="space-y-2.5 bg-bg/50 p-3 rounded-2xl border border-border-main/50 animate-fadeIn">
                              <div className="space-y-1">
                                <label className="text-[10px] font-bold opacity-70">رابط الإعلان الجانبي (Side Ad Affiliate Link)</label>
                                <input 
                                  type="text" 
                                  value={adConfig.sideAdLink} 
                                  placeholder="https://..."
                                  onChange={(e) => setAdConfig({ ...adConfig, sideAdLink: e.target.value })}
                                  className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main font-mono"
                                />
                              </div>

                              <div className="space-y-1">
                                <label className="text-[10px] font-bold opacity-70">رابط صورة بنر الإعلان الجانبي (Side Ad Banner URL)</label>
                                <div className="flex gap-2">
                                  <input 
                                    type="text" 
                                    value={adConfig.sideAdBannerUrl} 
                                    placeholder="https://..."
                                    onChange={(e) => setAdConfig({ ...adConfig, sideAdBannerUrl: e.target.value })}
                                    className="flex-1 text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                                  />
                                  <label className="bg-primary text-white text-[10px] font-black px-3 rounded-lg flex items-center gap-1 cursor-pointer hover:opacity-90 active:scale-95 transition-all shadow-sm">
                                    <Camera size={12} />
                                    <span>{lang === 'ar' ? 'رفع' : 'Upload'}</span>
                                    <input 
                                      type="file" 
                                      accept="image/*"
                                      onChange={(e) => {
                                        const file = e.target.files?.[0];
                                        if (file) {
                                          const reader = new FileReader();
                                          reader.onloadend = () => {
                                            setAdConfig({ ...adConfig, sideAdBannerUrl: reader.result as string });
                                          };
                                          reader.readAsDataURL(file);
                                        }
                                      }}
                                      className="hidden"
                                    />
                                  </label>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>

                        {/* Bottom Ad Configuration */}
                        <div className="border-t border-border-main/50 pt-4 mt-2 space-y-3">
                          <div className="p-3 bg-card border border-border-main rounded-xl flex items-center justify-between">
                            <div className="flex flex-col gap-0.5">
                              <span className="text-xs font-bold text-text-main">تفعيل الإعلان السفلي / Enable Bottom Ad</span>
                              <span className="text-[10px] opacity-60">عرض أو إخفاء مساحة الإعلان في أسفل الصفحة الرئيسية</span>
                            </div>
                            <label className="relative inline-flex items-center cursor-pointer">
                              <input 
                                type="checkbox" 
                                checked={adConfig.showBottomAd} 
                                onChange={(e) => setAdConfig({ ...adConfig, showBottomAd: e.target.checked })} 
                                className="sr-only peer" 
                              />
                              <div className="w-11 h-6 bg-border-main rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                            </label>
                          </div>

                          {adConfig.showBottomAd && (
                            <div className="space-y-2.5 bg-bg/50 p-3 rounded-2xl border border-border-main/50 animate-fadeIn">
                              <div className="space-y-1">
                                <label className="text-[10px] font-bold opacity-70">رابط الإعلان السفلي (Bottom Ad Affiliate Link)</label>
                                <input 
                                  type="text" 
                                  value={adConfig.bottomAdLink} 
                                  placeholder="https://..."
                                  onChange={(e) => setAdConfig({ ...adConfig, bottomAdLink: e.target.value })}
                                  className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main font-mono"
                                />
                              </div>

                              <div className="space-y-1">
                                <label className="text-[10px] font-bold opacity-70">رابط صورة بنر الإعلان السفلي (Bottom Ad Banner URL)</label>
                                <div className="flex gap-2">
                                  <input 
                                    type="text" 
                                    value={adConfig.bottomAdBannerUrl} 
                                    placeholder="https://..."
                                    onChange={(e) => setAdConfig({ ...adConfig, bottomAdBannerUrl: e.target.value })}
                                    className="flex-1 text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                                  />
                                  <label className="bg-primary text-white text-[10px] font-black px-3 rounded-lg flex items-center gap-1 cursor-pointer hover:opacity-90 active:scale-95 transition-all shadow-sm">
                                    <Camera size={12} />
                                    <span>{lang === 'ar' ? 'رفع' : 'Upload'}</span>
                                    <input 
                                      type="file" 
                                      accept="image/*"
                                      onChange={(e) => {
                                        const file = e.target.files?.[0];
                                        if (file) {
                                          const reader = new FileReader();
                                          reader.onloadend = () => {
                                            setAdConfig({ ...adConfig, bottomAdBannerUrl: reader.result as string });
                                          };
                                          reader.readAsDataURL(file);
                                        }
                                      }}
                                      className="hidden"
                                    />
                                  </label>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Tab 5: SEO Checker */}
                  {activeAdminTab === 'seo_checker' && (
                    <div className="space-y-4">
                      <div className="flex items-center gap-2 pb-2 border-b border-border-main">
                        <Gauge size={16} className="text-emerald-500" />
                        <h4 className="text-xs font-black text-emerald-500">
                          أداة فحص سيو الموقع الفورية / SEO Audit Tool
                        </h4>
                      </div>

                      {!seoAuditResult && !seoAuditLoading && (
                        <div className="space-y-4">
                          <p className="text-xs text-text-main/70 leading-relaxed bg-bg p-3.5 rounded-xl border border-border-main">
                            يقوم الفاحص الذكي بتحليل كامل لهيكلية الكود، العناوين، الأوصاف، المتاجر المدرجة، المقالات، ومدى توافق المحتوى مع الكلمات البحثية في الخليج والعالم العربي لتقديم تقرير شامل فوراً.
                          </p>
                          <button
                            onClick={handleRunSeoAudit}
                            className="w-full bg-emerald-500 text-white font-bold py-3 px-4 rounded-xl text-xs hover:bg-emerald-600 transition flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                          >
                            <Sparkles size={14} className="animate-pulse" />
                            <span>بدء تحليل سيو الموقع الفوري / Run Audit</span>
                          </button>
                        </div>
                      )}

                      {seoAuditLoading && (
                        <div className="py-12 flex flex-col items-center justify-center space-y-3 bg-bg/50 rounded-2xl border border-dashed border-border-main/50">
                          <div className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
                          <p className="text-xs font-bold text-emerald-500 animate-pulse">جاري فحص وتدقيق بنية السيو والمقالات...</p>
                        </div>
                      )}

                      {seoAuditResult && !seoAuditLoading && (
                        <div className="space-y-5">
                          {/* Score Card */}
                          <div className="p-4 bg-bg rounded-2xl border border-border-main flex items-center justify-between gap-3">
                            <div>
                              <div className="text-[10px] uppercase tracking-wider font-bold opacity-60">مؤشر توافق السيو للموقع</div>
                              <div className="text-lg font-black mt-1 text-text-main">
                                {seoAuditResult.status === 'Good' ? 'ممتاز ومتوافق جداً' : 'جيد ويحتاج لبعض التحسينات'}
                              </div>
                            </div>
                            <div className="relative flex items-center justify-center w-16 h-16 rounded-full border-4 border-emerald-500/20 bg-emerald-500/10">
                              <span className="text-lg font-black text-emerald-500">{seoAuditResult.score}</span>
                            </div>
                          </div>

                          {/* Density Analyzer */}
                          <div className="p-3 bg-blue-500/5 border border-blue-500/20 rounded-xl text-xs">
                            <div className="flex items-center gap-1.5 font-bold text-blue-500 mb-1">
                              <Info size={14} />
                              <span>تحليل الكلمات الفرص</span>
                            </div>
                            <p className="text-text-main/80 leading-relaxed text-[11px]">{seoAuditResult.densityAnalysis}</p>
                          </div>

                          {/* Specific Checks */}
                          <div className="space-y-2">
                            <span className="text-[10px] font-black opacity-60 uppercase">نتائج فحوصات السيو الفنية:</span>
                            <div className="space-y-2">
                              {seoAuditResult.checks?.map((check: any, idx: number) => (
                                <div key={idx} className="p-3 bg-card rounded-xl border border-border-main text-xs space-y-1">
                                  <div className="flex items-center justify-between font-bold">
                                    <span className="text-text-main">{check.name}</span>
                                    <span className={`text-[10px] px-2 py-0.5 rounded-full ${
                                      check.status === 'success' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-amber-500/10 text-amber-500'
                                    }`}>
                                      {check.status === 'success' ? 'سليم' : 'تنبيه'}
                                    </span>
                                  </div>
                                  <p className="text-[11px] text-text-main/70 leading-relaxed">{check.message}</p>
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* Recommendations */}
                          <div className="p-4 bg-amber-500/5 border border-amber-500/20 rounded-2xl space-y-2.5">
                            <div className="flex items-center gap-1.5 font-black text-amber-500 text-xs">
                              <AlertTriangle size={15} />
                              <span>توصيات عاجلة لتصدر نتائج البحث الأولى</span>
                            </div>
                            <ul className="space-y-1.5 text-[11px] text-text-main/80 list-disc pr-4">
                              {seoAuditResult.recommendations?.map((rec: string, idx: number) => (
                                <li key={idx} className="leading-relaxed">{rec}</li>
                              ))}
                            </ul>
                          </div>

                          <button
                            onClick={handleRunSeoAudit}
                            className="w-full bg-border-main/50 hover:bg-border-main text-text-main font-bold py-2 px-4 rounded-xl text-xs transition flex items-center justify-center gap-2 cursor-pointer"
                          >
                            <RotateCcw size={14} />
                            <span>إعادة الفحص والتحليل الفوري</span>
                          </button>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Tab 6: AI Content Writer */}
                  {activeAdminTab === 'ai_writer' && (
                    <div className="space-y-4">
                      <div className="flex items-center gap-2 pb-2 border-b border-border-main">
                        <Wand2 size={16} className="text-violet-500" />
                        <h4 className="text-xs font-black text-violet-500">
                          أنسنة وتحويل المقالات بالذكاء الاصطناعي / Humanizer
                        </h4>
                      </div>

                      <div className="space-y-3">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold opacity-70">مسودة المقال (أو النص الذكي المراد أنسنته)</label>
                          <textarea
                            value={rewriteDraft}
                            onChange={(e) => setRewriteDraft(e.target.value)}
                            placeholder="اكتب أو الصق مسودة المقال هنا. المساعد سيقوم بتحويله لأسلوب بشري طبيعي وجذاب يتخطى الفلاتر ويتصدر محركات البحث..."
                            rows={5}
                            className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-violet-500 text-text-main"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-bold opacity-70">الكلمات المفتاحية المستهدفة (مفصولة بفاصلة)</label>
                          <input
                            type="text"
                            value={rewriteKeywords}
                            onChange={(e) => setRewriteKeywords(e.target.value)}
                            placeholder="مثال: كود خصم نون، كوبونات السعودية، توفير المال"
                            className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-violet-500 text-text-main"
                          />
                        </div>

                        <button
                          onClick={handleRunRewrite}
                          disabled={rewriteLoading || !rewriteDraft.trim()}
                          className="w-full bg-violet-500 hover:bg-violet-600 disabled:opacity-50 text-white font-bold py-3 rounded-xl text-xs transition flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                        >
                          {rewriteLoading ? (
                            <>
                              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                              <span>جاري إضفاء الصبغة البشرية وتحسين السيو...</span>
                            </>
                          ) : (
                            <>
                              <Wand2 size={14} className="animate-pulse" />
                              <span>أنسنة وتحسين المقال فوراً</span>
                            </>
                          )}
                        </button>
                      </div>

                      {rewriteOutput && (
                        <div className="space-y-4 mt-4 border-t border-border-main/50 pt-4 text-xs">
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-violet-500 flex items-center gap-1">
                              <Sparkles size={14} className="animate-spin" style={{ animationDuration: '3s' }} />
                              <span>مراجعة وتخصيص المقال المؤنسن قبل النشر</span>
                            </span>
                            <button
                              onClick={() => {
                                navigator.clipboard.writeText(rewriteOutput);
                                alert(lang === 'ar' ? 'تم نسخ النص المؤنسن بنجاح!' : 'Optimized text copied!');
                              }}
                              className="text-[10px] text-violet-500 hover:underline flex items-center gap-1 cursor-pointer"
                            >
                              <Copy size={12} />
                              <span>نسخ النص الكامل</span>
                            </button>
                          </div>

                          {/* Editable title */}
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold opacity-70">العنوان المقترح (SEO)</label>
                            <input
                              type="text"
                              value={rewriteTitle}
                              onChange={(e) => setRewriteTitle(e.target.value)}
                              className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-violet-500 text-text-main font-semibold"
                            />
                          </div>

                          {/* Editable Category & Country */}
                          <div className="grid grid-cols-2 gap-2">
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold opacity-70">الفئة</label>
                              <input
                                type="text"
                                value={rewriteCategory}
                                onChange={(e) => setRewriteCategory(e.target.value)}
                                className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-violet-500 text-text-main"
                              />
                            </div>
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold opacity-70">الدولة الموجه إليها (رمز/علم)</label>
                              <input
                                type="text"
                                value={rewriteCountry}
                                onChange={(e) => setRewriteCountry(e.target.value)}
                                placeholder="sa, eg, ae, all..."
                                className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-violet-500 text-text-main text-center"
                              />
                            </div>
                          </div>

                          {/* Editable Excerpt Meta Description */}
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold opacity-70">مقتطف تعريفي (Meta Excerpt)</label>
                            <textarea
                              value={rewriteExcerpt}
                              onChange={(e) => setRewriteExcerpt(e.target.value)}
                              rows={2}
                              className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-violet-500 text-text-main leading-relaxed"
                            />
                          </div>

                          {/* Image Link */}
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold opacity-70">رابط صورة المقال المميزة</label>
                            <input
                              type="text"
                              value={rewriteImage}
                              onChange={(e) => setRewriteImage(e.target.value)}
                              className="w-full text-[11px] p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-violet-500 text-text-main font-mono"
                            />
                          </div>

                          {/* Content editor */}
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold opacity-70">محتوى المقال الكامل (معدل بالذكاء الاصطناعي)</label>
                            <textarea
                              value={rewriteOutput}
                              onChange={(e) => setRewriteOutput(e.target.value)}
                              rows={8}
                              className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-violet-500 text-text-main leading-relaxed font-sans"
                            />
                          </div>

                          <div className="p-3 bg-violet-500/5 border border-violet-500/20 rounded-xl space-y-2">
                            <p className="text-[11px] text-text-main/80 font-bold">جاهز لنشر هذا المقال المحسّن؟ سيتم عرضه في مدونة السيو مباشرة بالأسفل وبشكل دائم.</p>
                            <button
                              onClick={() => {
                                const newArtObj = {
                                  id: Date.now(),
                                  title: rewriteTitle || (lang === 'ar' ? 'مقال توفير مميز' : 'Featured Savings Article'),
                                  titleEn: lang === 'en' ? rewriteTitle : 'AI SEO Optimized Article',
                                  readTime: 'قراءة 3 دقائق',
                                  readTimeEn: '3 min read',
                                  category: rewriteCategory || (lang === 'ar' ? 'توفير المال' : 'Smart Saving'),
                                  categoryEn: lang === 'en' ? rewriteCategory : 'Smart Saving',
                                  excerpt: rewriteExcerpt || (rewriteOutput.substring(0, 120) + '...'),
                                  excerptEn: lang === 'en' ? rewriteExcerpt : 'Smart buying tips & exclusive discount codes.',
                                  content: rewriteOutput,
                                  image: rewriteImage || 'https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=600&auto=format&fit=crop',
                                  country: rewriteCountry || 'sa',
                                  couponCode: rewriteKeywords.split(/[,،]/)[0]?.trim() || 'SAVINGS',
                                  referralLink: 'https://www.google.com'
                                };
                                setArticles([newArtObj, ...articles]);
                                setRewriteDraft('');
                                setRewriteOutput('');
                                setRewriteKeywords('');
                                setRewriteTitle('');
                                setRewriteCategory('');
                                setRewriteExcerpt('');
                                alert(lang === 'ar' ? 'تم إضافة ونشر المقال المؤنسن بنجاح! ستجده في مدونة الموقع بالأسفل.' : 'Optimized article published successfully!');
                              }}
                              className="w-full bg-violet-600 text-white text-[11px] py-2.5 px-3 rounded-lg font-bold hover:bg-violet-700 transition cursor-pointer flex items-center justify-center gap-1.5 shadow-md"
                            >
                              <Plus size={14} />
                              <span>نشر وتثبيت المقال في المدونة الآن</span>
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Tab 8: Benefit Tabs */}
                  {activeAdminTab === 'benefits' && (
                    <div className="space-y-4 animate-fadeIn">
                      <div className="flex items-center gap-2 pb-2 border-b border-border-main">
                        <Sparkles size={16} className="text-yellow-500" />
                        <h4 className="text-xs font-black text-yellow-500">
                          {lang === 'ar' ? 'تعديل تبويبات التوفير الذكية' : 'Edit Smart Benefit Tabs'}
                        </h4>
                      </div>

                      <p className="text-[10px] text-text-main opacity-70 leading-relaxed">
                        {lang === 'ar' 
                          ? 'يمكنك هنا تخصيص عناوين ونصوص التبويبات الثلاثة التفاعلية التي تظهر أسفل الهيرو بانر مباشرة لزوار الموقع.' 
                          : 'Customize the titles and texts of the 3 interactive benefit tabs displayed under the hero banner.'}
                      </p>

                      {/* Select Tab to Edit */}
                      <div className="space-y-1.5 bg-primary/10 p-3 rounded-xl border border-primary/20">
                        <label className="text-[10px] font-black text-primary block">
                          {lang === 'ar' ? 'اختر التبويب لتعديله' : 'Select Tab to Edit'}
                        </label>
                        <div className="grid grid-cols-3 gap-2">
                          {benefitTabs.map((tab, idx) => (
                            <button
                              key={tab.id}
                              type="button"
                              onClick={() => setSelectedBenefitTabEditIdx(idx)}
                              className={`py-2 px-1 rounded-lg text-[10px] font-bold border transition-all cursor-pointer ${selectedBenefitTabEditIdx === idx ? 'bg-primary text-white border-primary shadow-sm' : 'bg-card border-border-main text-text-main opacity-70 hover:opacity-100'}`}
                            >
                              {lang === 'ar' ? `التبويب ${idx + 1}` : `Tab ${idx + 1}`}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Title Ar */}
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold opacity-70">{lang === 'ar' ? 'العنوان باللغة العربية' : 'Title (Arabic)'}</label>
                        <input 
                          type="text"
                          value={benefitTabs[selectedBenefitTabEditIdx]?.titleAr || ''}
                          onChange={(e) => {
                            const updated = [...benefitTabs];
                            updated[selectedBenefitTabEditIdx].titleAr = e.target.value;
                            saveBenefitTabs(updated);
                          }}
                          className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main font-semibold"
                        />
                      </div>

                      {/* Title En */}
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold opacity-70">{lang === 'ar' ? 'العنوان باللغة الإنجليزية' : 'Title (English)'}</label>
                        <input 
                          type="text"
                          value={benefitTabs[selectedBenefitTabEditIdx]?.titleEn || ''}
                          onChange={(e) => {
                            const updated = [...benefitTabs];
                            updated[selectedBenefitTabEditIdx].titleEn = e.target.value;
                            saveBenefitTabs(updated);
                          }}
                          className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main font-semibold"
                        />
                      </div>

                      {/* Desc Ar */}
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold opacity-70">{lang === 'ar' ? 'الوصف باللغة العربية' : 'Description (Arabic)'}</label>
                        <textarea 
                          rows={2}
                          value={benefitTabs[selectedBenefitTabEditIdx]?.descAr || ''}
                          onChange={(e) => {
                            const updated = [...benefitTabs];
                            updated[selectedBenefitTabEditIdx].descAr = e.target.value;
                            saveBenefitTabs(updated);
                          }}
                          className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main leading-relaxed"
                        />
                      </div>

                      {/* Desc En */}
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold opacity-70">{lang === 'ar' ? 'الوصف باللغة الإنجليزية' : 'Description (English)'}</label>
                        <textarea 
                          rows={2}
                          value={benefitTabs[selectedBenefitTabEditIdx]?.descEn || ''}
                          onChange={(e) => {
                            const updated = [...benefitTabs];
                            updated[selectedBenefitTabEditIdx].descEn = e.target.value;
                            saveBenefitTabs(updated);
                          }}
                          className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main leading-relaxed"
                        />
                      </div>

                      {/* Render custom fields based on index */}
                      {selectedBenefitTabEditIdx === 0 && (
                        <div className="space-y-3 pt-3 border-t border-border-main/50">
                          <h5 className="text-[10px] font-black text-primary">{lang === 'ar' ? 'خطوات دليل التوفير السريع' : 'Saving Guide Steps'}</h5>
                          
                          {/* Step 1 */}
                          <div className="space-y-1 bg-primary/5 p-2 rounded-xl">
                            <label className="text-[9px] font-bold opacity-70">{lang === 'ar' ? 'الخطوة 1 (عربي)' : 'Step 1 (Arabic)'}</label>
                            <input 
                              type="text"
                              value={benefitTabs[0]?.step1Ar || ''}
                              onChange={(e) => {
                                const updated = [...benefitTabs];
                                updated[0].step1Ar = e.target.value;
                                saveBenefitTabs(updated);
                              }}
                              className="w-full text-[11px] p-2 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                            />
                            <label className="text-[9px] font-bold opacity-70 mt-1 block">{lang === 'ar' ? 'الخطوة 1 (إنجليزي)' : 'Step 1 (English)'}</label>
                            <input 
                              type="text"
                              value={benefitTabs[0]?.step1En || ''}
                              onChange={(e) => {
                                const updated = [...benefitTabs];
                                updated[0].step1En = e.target.value;
                                saveBenefitTabs(updated);
                              }}
                              className="w-full text-[11px] p-2 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                            />
                          </div>

                          {/* Step 2 */}
                          <div className="space-y-1 bg-primary/5 p-2 rounded-xl">
                            <label className="text-[9px] font-bold opacity-70">{lang === 'ar' ? 'الخطوة 2 (عربي)' : 'Step 2 (Arabic)'}</label>
                            <input 
                              type="text"
                              value={benefitTabs[0]?.step2Ar || ''}
                              onChange={(e) => {
                                const updated = [...benefitTabs];
                                updated[0].step2Ar = e.target.value;
                                saveBenefitTabs(updated);
                              }}
                              className="w-full text-[11px] p-2 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                            />
                            <label className="text-[9px] font-bold opacity-70 mt-1 block">{lang === 'ar' ? 'الخطوة 2 (إنجليزي)' : 'Step 2 (English)'}</label>
                            <input 
                              type="text"
                              value={benefitTabs[0]?.step2En || ''}
                              onChange={(e) => {
                                const updated = [...benefitTabs];
                                updated[0].step2En = e.target.value;
                                saveBenefitTabs(updated);
                              }}
                              className="w-full text-[11px] p-2 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                            />
                          </div>

                          {/* Step 3 */}
                          <div className="space-y-1 bg-primary/5 p-2 rounded-xl">
                            <label className="text-[9px] font-bold opacity-70">{lang === 'ar' ? 'الخطوة 3 (عربي)' : 'Step 3 (Arabic)'}</label>
                            <input 
                              type="text"
                              value={benefitTabs[0]?.step3Ar || ''}
                              onChange={(e) => {
                                const updated = [...benefitTabs];
                                updated[0].step3Ar = e.target.value;
                                saveBenefitTabs(updated);
                              }}
                              className="w-full text-[11px] p-2 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                            />
                            <label className="text-[9px] font-bold opacity-70 mt-1 block">{lang === 'ar' ? 'الخطوة 3 (إنجليزي)' : 'Step 3 (English)'}</label>
                            <input 
                              type="text"
                              value={benefitTabs[0]?.step3En || ''}
                              onChange={(e) => {
                                const updated = [...benefitTabs];
                                updated[0].step3En = e.target.value;
                                saveBenefitTabs(updated);
                              }}
                              className="w-full text-[11px] p-2 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                            />
                          </div>
                        </div>
                      )}

                      {selectedBenefitTabEditIdx === 2 && (
                        <div className="space-y-3 pt-3 border-t border-border-main/50">
                          <h5 className="text-[10px] font-black text-primary">{lang === 'ar' ? 'نصائح التسوق الذكية' : 'Smart Shopping Tips'}</h5>
                          
                          {/* Tip 1 */}
                          <div className="space-y-1 bg-primary/5 p-2 rounded-xl">
                            <label className="text-[9px] font-bold opacity-70">{lang === 'ar' ? 'النصيحة 1 (عربي)' : 'Tip 1 (Arabic)'}</label>
                            <input 
                              type="text"
                              value={benefitTabs[2]?.tip1Ar || ''}
                              onChange={(e) => {
                                const updated = [...benefitTabs];
                                updated[2].tip1Ar = e.target.value;
                                saveBenefitTabs(updated);
                              }}
                              className="w-full text-[11px] p-2 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                            />
                            <label className="text-[9px] font-bold opacity-70 mt-1 block">{lang === 'ar' ? 'النصيحة 1 (إنجليزي)' : 'Tip 1 (English)'}</label>
                            <input 
                              type="text"
                              value={benefitTabs[2]?.tip1En || ''}
                              onChange={(e) => {
                                const updated = [...benefitTabs];
                                updated[2].tip1En = e.target.value;
                                saveBenefitTabs(updated);
                              }}
                              className="w-full text-[11px] p-2 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                            />
                          </div>

                          {/* Tip 2 */}
                          <div className="space-y-1 bg-primary/5 p-2 rounded-xl">
                            <label className="text-[9px] font-bold opacity-70">{lang === 'ar' ? 'النصيحة 2 (عربي)' : 'Tip 2 (Arabic)'}</label>
                            <input 
                              type="text"
                              value={benefitTabs[2]?.tip2Ar || ''}
                              onChange={(e) => {
                                const updated = [...benefitTabs];
                                updated[2].tip2Ar = e.target.value;
                                saveBenefitTabs(updated);
                              }}
                              className="w-full text-[11px] p-2 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                            />
                            <label className="text-[9px] font-bold opacity-70 mt-1 block">{lang === 'ar' ? 'النصيحة 2 (إنجليزي)' : 'Tip 2 (English)'}</label>
                            <input 
                              type="text"
                              value={benefitTabs[2]?.tip2En || ''}
                              onChange={(e) => {
                                const updated = [...benefitTabs];
                                updated[2].tip2En = e.target.value;
                                saveBenefitTabs(updated);
                              }}
                              className="w-full text-[11px] p-2 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                            />
                          </div>

                          {/* Tip 3 */}
                          <div className="space-y-1 bg-primary/5 p-2 rounded-xl">
                            <label className="text-[9px] font-bold opacity-70">{lang === 'ar' ? 'النصيحة 3 (عربي)' : 'Tip 3 (Arabic)'}</label>
                            <input 
                              type="text"
                              value={benefitTabs[2]?.tip3Ar || ''}
                              onChange={(e) => {
                                const updated = [...benefitTabs];
                                updated[2].tip3Ar = e.target.value;
                                saveBenefitTabs(updated);
                              }}
                              className="w-full text-[11px] p-2 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                            />
                            <label className="text-[9px] font-bold opacity-70 mt-1 block">{lang === 'ar' ? 'النصيحة 3 (إنجليزي)' : 'Tip 3 (English)'}</label>
                            <input 
                              type="text"
                              value={benefitTabs[2]?.tip3En || ''}
                              onChange={(e) => {
                                const updated = [...benefitTabs];
                                updated[2].tip3En = e.target.value;
                                saveBenefitTabs(updated);
                              }}
                              className="w-full text-[11px] p-2 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main"
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {activeAdminTab === 'messages' && (
                    <div className="space-y-4 animate-fadeIn text-right" dir="rtl">
                      <div className="flex items-center gap-2 pb-2 border-b border-border-main justify-start">
                        <Mail size={16} className="text-primary" />
                        <h4 className="text-xs font-black text-primary">
                          {lang === 'ar' ? 'رسائل اتصل بنا من زوار الموقع' : 'Visitor Contact Messages'}
                        </h4>
                      </div>

                      <p className="text-[10px] text-text-main opacity-70 leading-relaxed text-right">
                        {lang === 'ar' 
                          ? 'استقبل واقرأ هنا جميع الرسائل والاستفسارات الحقيقية التي يرسلها زوار موقعك من صفحة اتصل بنا.' 
                          : 'Receive and read here all the contact messages sent by your website visitors from the contact form.'}
                      </p>

                      <div className="space-y-3">
                        {visitorMessages.length === 0 ? (
                          <div className="p-8 text-center text-xs opacity-60 bg-bg rounded-2xl border border-dashed border-border-main">
                            📭 {lang === 'ar' ? 'لا توجد رسائل جديدة حالياً.' : 'No visitor messages yet.'}
                          </div>
                        ) : (
                          visitorMessages.map((msg: any) => (
                            <div key={msg.id} className="p-4 bg-card rounded-2xl border border-border-main space-y-2.5 shadow-xs relative group text-right">
                              <button 
                                onClick={() => {
                                  if (confirm(lang === 'ar' ? 'هل أنت متأكد من حذف هذه الرسالة؟' : 'Are you sure you want to delete this message?')) {
                                    setVisitorMessages(visitorMessages.filter((m: any) => m.id !== msg.id));
                                  }
                                }}
                                className="absolute top-3 left-3 text-red-500 opacity-0 group-hover:opacity-100 transition p-1 hover:bg-red-500/10 rounded-lg cursor-pointer"
                                title={lang === 'ar' ? 'حذف الرسالة' : 'Delete Message'}
                              >
                                <Trash2 size={14} />
                              </button>
                              
                              <div className="flex flex-wrap items-center justify-between gap-1.5 border-b border-border-main/50 pb-2">
                                <div>
                                  <span className="font-extrabold text-xs text-text-main block">{msg.name}</span>
                                  <a href={`mailto:${msg.email}`} className="text-[10px] text-primary hover:underline font-semibold block">{msg.email}</a>
                                </div>
                                <span className="text-[9px] text-text-main opacity-50 flex items-center gap-1">
                                  <Clock size={10} />
                                  {msg.date}
                                </span>
                              </div>

                              <div className="space-y-1">
                                <span className="text-[10px] font-black uppercase text-primary tracking-wider">{lang === 'ar' ? 'الموضوع:' : 'Subject:'} {msg.subject}</span>
                                <p className="text-xs text-text-main/90 leading-relaxed whitespace-pre-wrap bg-bg p-3 rounded-xl border border-border-main/40">
                                  {msg.message}
                                </p>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  )}

                  {activeAdminTab === 'seo_metadata' && (
                    <div className="space-y-4 animate-fadeIn text-right" dir="rtl">
                      <div className="flex items-center gap-2 pb-2 border-b border-border-main justify-start">
                        <Globe size={16} className="text-emerald-500" />
                        <h4 className="text-xs font-black text-emerald-500">
                          {lang === 'ar' ? 'إعدادات الأرشفة وسيو محركات البحث' : 'SEO & Archiving Settings'}
                        </h4>
                      </div>

                      <p className="text-[10px] text-text-main opacity-70 leading-relaxed text-right">
                        {lang === 'ar' 
                          ? 'خصص بدقة معلومات الموقع والعناوين الموجهة لعناكب بحث جوجل لضمان ظهور موقعك في الترتيب الأول للأكواد.' 
                          : 'Customize exactly how search bots index your site. These metadata values feed directly into Google, Bing, and Social Share Cards.'}
                      </p>

                      {/* Title inputs */}
                      <div className="grid grid-cols-1 gap-3">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold opacity-70 block text-right">{lang === 'ar' ? 'العنوان الرئيسي بالعربية (Title)' : 'Site Title (Arabic)'}</label>
                          <input 
                            type="text"
                            value={seoTitleAr}
                            onChange={(e) => setSeoTitleAr(e.target.value)}
                            className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-emerald-500 text-text-main font-semibold text-right"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold opacity-70 block text-right">{lang === 'ar' ? 'العنوان الرئيسي بالإنجليزية' : 'Site Title (English)'}</label>
                          <input 
                            type="text"
                            value={seoTitleEn}
                            onChange={(e) => setSeoTitleEn(e.target.value)}
                            className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-emerald-500 text-text-main font-semibold text-left"
                          />
                        </div>
                      </div>

                      {/* Description inputs */}
                      <div className="grid grid-cols-1 gap-3">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold opacity-70 block text-right">{lang === 'ar' ? 'الوصف بالعربية (Meta Description)' : 'Meta Description (Arabic)'}</label>
                          <textarea 
                            rows={2}
                            value={seoDescAr}
                            onChange={(e) => setSeoDescAr(e.target.value)}
                            className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-emerald-500 text-text-main text-right"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold opacity-70 block text-right">{lang === 'ar' ? 'الوصف بالإنجليزية' : 'Meta Description (English)'}</label>
                          <textarea 
                            rows={2}
                            value={seoDescEn}
                            onChange={(e) => setSeoDescEn(e.target.value)}
                            className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-emerald-500 text-text-main text-left"
                          />
                        </div>
                      </div>

                      {/* Keywords inputs */}
                      <div className="grid grid-cols-1 gap-3">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold opacity-70 block text-right">{lang === 'ar' ? 'الكلمات الدلالية بالعربية (Keywords)' : 'Keywords (Arabic)'}</label>
                          <input 
                            type="text"
                            value={seoKeywordsAr}
                            onChange={(e) => setSeoKeywordsAr(e.target.value)}
                            className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-emerald-500 text-text-main text-right"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold opacity-70 block text-right">{lang === 'ar' ? 'الكلمات الدلالية بالإنجليزية' : 'Keywords (English)'}</label>
                          <input 
                            type="text"
                            value={seoKeywordsEn}
                            onChange={(e) => setSeoKeywordsEn(e.target.value)}
                            className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-emerald-500 text-text-main text-left"
                          />
                        </div>
                      </div>

                      {/* Sitemap & Robots generation block */}
                      <div className="bg-emerald-500/5 p-4 rounded-2xl border border-emerald-500/20 space-y-3 mt-4 text-right">
                        <h5 className="text-[11px] font-black text-emerald-500 flex items-center gap-1 justify-start">
                          <Globe size={14} />
                          <span>{lang === 'ar' ? 'تحميل ملفات الأرشفة والخرائط (Sitemaps)' : 'Download Sitemaps'}</span>
                        </h5>
                        <p className="text-[10px] text-text-main/80 leading-relaxed text-right">
                          {lang === 'ar' 
                            ? 'اضغط أدناه لتوليد وتحميل ملفات الأرشيف الحية لموقعك فوراً لتقوم برفعها يدوياً في Google Search Console إذا رغبت.' 
                            : 'Download real sitemap.xml and robots.txt files compiled dynamically with your current stores and pages.'}
                        </p>
                        <div className="grid grid-cols-2 gap-2 pt-1">
                          <button
                            type="button"
                            onClick={() => {
                              // Generate XML
                              let xml = `<?xml version="1.0" encoding="UTF-8"?>\n`;
                              xml += `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n`;
                              
                              const base = window.location.origin || 'https://wafeer.ai.studio';
                              xml += `  <url>\n    <loc>${base}/</loc>\n    <priority>1.0</priority>\n    <changefreq>daily</changefreq>\n  </url>\n`;
                              xml += `  <url>\n    <loc>${base}/#about</loc>\n    <priority>0.8</priority>\n    <changefreq>monthly</changefreq>\n  </url>\n`;
                              xml += `  <url>\n    <loc>${base}/#privacy</loc>\n    <priority>0.7</priority>\n    <changefreq>monthly</changefreq>\n  </url>\n`;
                              xml += `  <url>\n    <loc>${base}/#contact</loc>\n    <priority>0.7</priority>\n    <changefreq>monthly</changefreq>\n  </url>\n`;
                              
                              stores.forEach((store: any) => {
                                xml += `  <url>\n    <loc>${base}/#stores</loc>\n    <priority>0.9</priority>\n    <changefreq>weekly</changefreq>\n  </url>\n`;
                              });
                              xml += `</urlset>`;

                              const blob = new Blob([xml], { type: 'application/xml' });
                              const url = URL.createObjectURL(blob);
                              const a = document.createElement('a');
                              a.href = url;
                              a.download = 'sitemap.xml';
                              a.click();
                              URL.revokeObjectURL(url);
                              
                              pushNotification(
                                'deal',
                                '📂 تم توليد وتحميل ملف sitemap.xml الحقيقي لموقعك بنجاح!',
                                '📂 sitemap.xml file successfully generated and downloaded!'
                              );
                            }}
                            className="bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-2.5 px-3 rounded-xl text-[10px] transition cursor-pointer flex items-center justify-center gap-1 shadow-xs"
                          >
                            <span>xml سحب خريطة سيو</span>
                          </button>
                          
                          <button
                            type="button"
                            onClick={() => {
                              const base = window.location.origin || 'https://wafeer.ai.studio';
                              let txt = `User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /?admin=\n\nSitemap: ${base}/sitemap.xml\n`;

                              const blob = new Blob([txt], { type: 'text/plain' });
                              const url = URL.createObjectURL(blob);
                              const a = document.createElement('a');
                              a.href = url;
                              a.download = 'robots.txt';
                              a.click();
                              URL.revokeObjectURL(url);

                              pushNotification(
                                'deal',
                                '🤖 تم توليد وتحميل ملف robots.txt بنجاح!',
                                '🤖 robots.txt file successfully generated and downloaded!'
                              );
                            }}
                            className="bg-slate-700 hover:bg-slate-800 text-white font-bold py-2.5 px-3 rounded-xl text-[10px] transition cursor-pointer flex items-center justify-center gap-1 shadow-xs"
                          >
                            <span>تحميل robots.txt</span>
                          </button>
                        </div>
                      </div>

                      {/* Advanced Search Indexing & Webmaster Tools Dashboard */}
                      <div className="border-t border-border-main/50 pt-4 mt-4 space-y-3 text-right" dir="rtl">
                        <SEOTools
                          lang={lang}
                          googleVerificationCode={googleVerificationCode}
                          setGoogleVerificationCode={setGoogleVerificationCode}
                          bingVerificationCode={bingVerificationCode}
                          setBingVerificationCode={setBingVerificationCode}
                          seoTitleAr={seoTitleAr}
                          seoTitleEn={seoTitleEn}
                          seoDescAr={seoDescAr}
                          seoDescEn={seoDescEn}
                          pushNotification={pushNotification}
                        />
                      </div>

                      {/* Live Keyword Density Checker Admin Feature */}
                      <div className="border-t border-border-main/50 pt-4 mt-4 space-y-3 text-right" dir="rtl">
                        <KeywordDensityChecker
                          lang={lang}
                          stores={stores}
                          articles={articles}
                          benefits={benefitTabs}
                          seoTitleAr={seoTitleAr}
                          seoTitleEn={seoTitleEn}
                          seoDescAr={seoDescAr}
                          seoDescEn={seoDescEn}
                          seoKeywordsAr={seoKeywordsAr}
                          seoKeywordsEn={seoKeywordsEn}
                          heroSlides={heroSlides}
                        />
                      </div>
                    </div>
                  )}

                  {activeAdminTab === 'footer_config' && (
                    <div className="space-y-5 animate-fadeIn text-right" dir="rtl">
                      <div className="flex items-center gap-2 pb-2 border-b border-border-main justify-start">
                        <Settings size={16} className="text-primary" />
                        <h4 className="text-xs font-black text-primary">
                          {lang === 'ar' ? 'تعديل الفوتر كاملاً / Custom Footer Config' : 'Full Footer Editor'}
                        </h4>
                      </div>

                      <p className="text-[10px] text-text-main opacity-70 leading-relaxed text-right">
                        {lang === 'ar' 
                          ? 'من هنا يمكنك تخصيص وتعديل كافة النصوص والمعلومات الظاهرة في أسفل الموقع (الفوتر) لترسيخ الهوية البصرية واسم العلامة التجارية الخاصة بك.'
                          : 'Here you can customize and edit all the texts and information displayed in the footer section of your website.'}
                      </p>

                      {/* Section 1: Brand Info */}
                      <div className="p-4 bg-card border border-border-main rounded-2xl space-y-3 shadow-xs">
                        <h5 className="text-[11px] font-black text-primary flex items-center gap-1.5 justify-start">
                          🏢 {lang === 'ar' ? 'عمود العلامة التجارية والوصف' : 'Brand Column & Description'}
                        </h5>
                        <div className="space-y-3">
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold opacity-70 block text-right">{lang === 'ar' ? 'وصف الموقع بالفوتر - بالعربية' : 'Footer Brand Description (AR)'}</label>
                            <textarea
                              rows={2}
                              value={footerDescAr}
                              onChange={(e) => saveFooterState('footer_desc_ar', e.target.value, setFooterDescAr)}
                              className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main text-right"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold opacity-70 block text-right">{lang === 'ar' ? 'وصف الموقع بالفوتر - بالإنجليزية' : 'Footer Brand Description (EN)'}</label>
                            <textarea
                              rows={2}
                              value={footerDescEn}
                              onChange={(e) => saveFooterState('footer_desc_en', e.target.value, setFooterDescEn)}
                              className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main text-left"
                              dir="ltr"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Section 2: Contact Info */}
                      <div className="p-4 bg-card border border-border-main rounded-2xl space-y-3 shadow-xs">
                        <h5 className="text-[11px] font-black text-primary flex items-center gap-1.5 justify-start">
                          📞 {lang === 'ar' ? 'روابط واتصل بنا والروابط السريعة' : 'Contact Links & Quick Links'}
                        </h5>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold opacity-70 block text-right">{lang === 'ar' ? 'عنوان العمود - بالعربية' : 'Column Header (AR)'}</label>
                            <input 
                              type="text"
                              value={footerLinksTitleAr}
                              onChange={(e) => saveFooterState('footer_links_title_ar', e.target.value, setFooterLinksTitleAr)}
                              className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main text-right"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold opacity-70 block text-right">{lang === 'ar' ? 'عنوان العمود - بالإنجليزية' : 'Column Header (EN)'}</label>
                            <input 
                              type="text"
                              value={footerLinksTitleEn}
                              onChange={(e) => saveFooterState('footer_links_title_en', e.target.value, setFooterLinksTitleEn)}
                              className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main text-left"
                              dir="ltr"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold opacity-70 block text-right">{lang === 'ar' ? 'رقم الهاتف' : 'Phone Number'}</label>
                            <input 
                              type="text"
                              value={contactPhone}
                              onChange={(e) => saveContactPhone(e.target.value)}
                              className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main text-right"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold opacity-70 block text-right">{lang === 'ar' ? 'البريد الإلكتروني' : 'Email Address'}</label>
                            <input 
                              type="email"
                              value={contactEmail}
                              onChange={(e) => saveContactEmail(e.target.value)}
                              className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main text-left"
                              dir="ltr"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold opacity-70 block text-right">{lang === 'ar' ? 'العنوان / الموقع بالعربية' : 'Location (AR)'}</label>
                            <input 
                              type="text"
                              value={footerLocationAr}
                              onChange={(e) => saveFooterState('footer_location_ar', e.target.value, setFooterLocationAr)}
                              className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main text-right"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold opacity-70 block text-right">{lang === 'ar' ? 'العنوان / الموقع بالإنجليزية' : 'Location (EN)'}</label>
                            <input 
                              type="text"
                              value={footerLocationEn}
                              onChange={(e) => saveFooterState('footer_location_en', e.target.value, setFooterLocationEn)}
                              className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main text-left"
                              dir="ltr"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Section 3: Social & Follow-Us */}
                      <div className="p-4 bg-card border border-border-main rounded-2xl space-y-3 shadow-xs">
                        <h5 className="text-[11px] font-black text-primary flex items-center gap-1.5 justify-start">
                          👥 {lang === 'ar' ? 'عنوان وتفاصيل شبكات التواصل الاجتماعي' : 'Social Channels Column'}
                        </h5>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold opacity-70 block text-right">{lang === 'ar' ? 'عنوان العمود - بالعربية' : 'Column Header (AR)'}</label>
                            <input 
                              type="text"
                              value={footerSocialTitleAr}
                              onChange={(e) => saveFooterState('footer_social_title_ar', e.target.value, setFooterSocialTitleAr)}
                              className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main text-right"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold opacity-70 block text-right">{lang === 'ar' ? 'عنوان العمود - بالإنجليزية' : 'Column Header (EN)'}</label>
                            <input 
                              type="text"
                              value={footerSocialTitleEn}
                              onChange={(e) => saveFooterState('footer_social_title_en', e.target.value, setFooterSocialTitleEn)}
                              className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main text-left"
                              dir="ltr"
                            />
                          </div>
                          <div className="space-y-1 sm:col-span-2">
                            <label className="text-[10px] font-bold opacity-70 block text-right">{lang === 'ar' ? 'وصف العمود - بالعربية' : 'Description (AR)'}</label>
                            <textarea
                              rows={2}
                              value={footerSocialDescAr}
                              onChange={(e) => saveFooterState('footer_social_desc_ar', e.target.value, setFooterSocialDescAr)}
                              className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main text-right"
                            />
                          </div>
                          <div className="space-y-1 sm:col-span-2">
                            <label className="text-[10px] font-bold opacity-70 block text-right">{lang === 'ar' ? 'وصف العمود - بالإنجليزية' : 'Description (EN)'}</label>
                            <textarea
                              rows={2}
                              value={footerSocialDescEn}
                              onChange={(e) => saveFooterState('footer_social_desc_en', e.target.value, setFooterSocialDescEn)}
                              className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main text-left"
                              dir="ltr"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Section 4: Copyright and Disclaimer Bar */}
                      <div className="p-4 bg-card border border-border-main rounded-2xl space-y-3 shadow-xs">
                        <h5 className="text-[11px] font-black text-primary flex items-center gap-1.5 justify-start">
                          ⚖️ {lang === 'ar' ? 'شريط حقوق الملكية والتشغيل' : 'Copyright & Disclaimer Bar'}
                        </h5>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold opacity-70 block text-right">{lang === 'ar' ? 'جملة صنع بـ ❤️ - بالعربية' : 'Made with statement (AR)'}</label>
                            <input 
                              type="text"
                              value={footerCopyrightTextAr}
                              onChange={(e) => saveFooterState('footer_copyright_text_ar', e.target.value, setFooterCopyrightTextAr)}
                              className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main text-right"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[10px] font-bold opacity-70 block text-right">{lang === 'ar' ? 'جملة صنع بـ ❤️ - بالإنجليزية' : 'Made with statement (EN)'}</label>
                            <input 
                              type="text"
                              value={footerCopyrightTextEn}
                              onChange={(e) => saveFooterState('footer_copyright_text_en', e.target.value, setFooterCopyrightTextEn)}
                              className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main text-left"
                              dir="ltr"
                            />
                          </div>
                          <div className="space-y-1 sm:col-span-2">
                            <label className="text-[10px] font-bold opacity-70 block text-right">{lang === 'ar' ? 'اسم الشركة / الموقع الظاهر بجانب حقوق الطبع' : 'Copyright Company/Site Name'}</label>
                            <input 
                              type="text"
                              value={footerCopyrightCompany}
                              onChange={(e) => saveFooterState('footer_copyright_company', e.target.value, setFooterCopyrightCompany)}
                              className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-primary text-text-main text-right font-black text-primary"
                            />
                          </div>
                        </div>
                      </div>

                      <div className="bg-primary/10 p-4 rounded-2xl border border-primary/20 text-center text-xs text-primary font-bold">
                        🎉 {lang === 'ar' ? 'تم الحفظ والمزامنة تلقائياً مع الفوتر السفلي مباشرة!' : 'All footer adjustments are automatically saved and synced instantly!'}
                      </div>
                    </div>
                  )}
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>

        {/* Coupon Copied Step-by-Step Guidance Modal */}
        <AnimatePresence>
          {copiedCouponInfo && (
            <>
              {/* Overlay Backdrop */}
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.6 }}
                exit={{ opacity: 0 }}
                onClick={() => setCopiedCouponInfo(null)}
                className="fixed inset-0 bg-black/70 backdrop-blur-xs z-50 pointer-events-auto"
              />
              
              {/* Modal Container */}
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 30 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 30 }}
                className="fixed inset-x-4 bottom-4 md:bottom-auto md:top-1/2 md:left-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:w-[500px] bg-card rounded-3xl border border-border-main shadow-2xl z-50 overflow-hidden text-text-main p-6 text-center max-h-[90vh] overflow-y-auto"
              >
                {/* Animated Celebration Icon */}
                <div className="flex justify-center mb-4">
                  <div className="w-16 h-16 bg-green-500/10 text-green-500 rounded-full flex items-center justify-center relative">
                    <motion.div
                      initial={{ scale: 0.5, opacity: 0 }}
                      animate={{ scale: 1.2, opacity: 0 }}
                      transition={{ repeat: Infinity, duration: 2, ease: "easeOut" }}
                      className="absolute inset-0 bg-green-500/20 rounded-full"
                    />
                    <Check size={32} className="relative z-10" />
                  </div>
                </div>

                {/* Title */}
                <h4 className="text-xl font-black text-text-main mb-1">
                  {lang === 'ar' ? 'تم نسخ الكوبون بنجاح!' : 'Coupon Copied Successfully!'}
                </h4>
                <p className="text-xs text-text-main/60 mb-6">
                  {lang === 'ar' ? 'اتبع الخطوات البسيطة التالية للاستفادة من الخصم:' : 'Follow these simple steps to claim your discount:'}
                </p>

                {/* Store Brand Header Card */}
                <div className="bg-bg border border-border-main rounded-2xl p-4 mb-6 flex items-center gap-4 text-right">
                  <div className="w-14 h-14 bg-white rounded-xl flex items-center justify-center p-2 border border-border-main/50 overflow-hidden flex-shrink-0">
                    <StoreLogo 
                      logo={copiedCouponInfo.storeLogo || ''} 
                      name={copiedCouponInfo.storeName} 
                      nameAr={copiedCouponInfo.storeName} 
                      className="max-w-full max-h-full object-contain" 
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h5 className="font-bold text-sm text-text-main opacity-80">
                      {lang === 'ar' ? `متجر ${copiedCouponInfo.storeName}` : `${copiedCouponInfo.storeName} Store`}
                    </h5>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs font-mono font-black text-primary tracking-widest bg-primary/10 px-3 py-1 rounded-lg border border-primary/20">
                        {copiedCouponInfo.code}
                      </span>
                      <span className="text-[10px] text-green-500 font-bold bg-green-500/10 px-2 py-0.5 rounded-full">
                        {lang === 'ar' ? 'جاهز للصق' : 'Ready to paste'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Visual Roadmap / Steps */}
                <div className="space-y-4 text-right mb-6" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
                  {/* Step 1 */}
                  <div className="flex items-start gap-3 p-3 rounded-xl bg-green-500/[0.03] border border-green-500/10">
                    <div className="w-6 h-6 rounded-full bg-green-500 text-white flex items-center justify-center text-xs font-black flex-shrink-0 mt-0.5">
                      {lang === 'ar' ? '١' : '1'}
                    </div>
                    <div>
                      <p className="text-xs font-black text-text-main">
                        {lang === 'ar' ? 'تم نسخ الرمز الترويجي تلقائياً' : 'Promo Code Copied'}
                      </p>
                      <p className="text-[10px] text-text-main/60 mt-0.5">
                        {lang === 'ar' ? 'الرمز الآن محفوظ في حافظة جهازك وجاهز للاستخدام مباشرة.' : 'The code is safely saved to your device clipboard.'}
                      </p>
                    </div>
                  </div>

                  {/* Step 2 */}
                  <div className="flex items-start gap-3 p-3 rounded-xl bg-primary/[0.03] border border-primary/10">
                    <div className="w-6 h-6 rounded-full bg-primary text-white flex items-center justify-center text-xs font-black flex-shrink-0 mt-0.5">
                      {lang === 'ar' ? '٢' : '2'}
                    </div>
                    <div>
                      <p className="text-xs font-black text-text-main">
                        {lang === 'ar' ? 'الانتقال إلى موقع المتجر وتعبئة عربة التسوق' : 'Go to Store & Shop'}
                      </p>
                      <p className="text-[10px] text-text-main/60 mt-0.5">
                        {lang === 'ar' 
                          ? 'جاري فتح موقع المتجر الرسمي في صفحة جديدة. اختر منتجاتك المفضلة وأضفها للسلة.' 
                          : 'The store has been opened in a new tab. Choose your favorite products and add them to cart.'}
                      </p>
                    </div>
                  </div>

                  {/* Step 3 */}
                  <div className="flex items-start gap-3 p-3 rounded-xl bg-yellow-500/[0.03] border border-yellow-500/10">
                    <div className="w-6 h-6 rounded-full bg-yellow-500 text-white flex items-center justify-center text-xs font-black flex-shrink-0 mt-0.5">
                      {lang === 'ar' ? '٣' : '3'}
                    </div>
                    <div>
                      <p className="text-xs font-black text-text-main">
                        {lang === 'ar' ? 'لصق الكود في صفحة الدفع وتفعيل الخصم!' : 'Paste Code & Save!'}
                      </p>
                      <p className="text-[10px] text-text-main/60 mt-0.5">
                        {lang === 'ar' 
                          ? `قم بلصق الكود (${copiedCouponInfo.code}) في خانة "رمز الخصم" أو "الكوبون" عند الدفع لتحصل على التخفيض فوراً.` 
                          : `Paste the code (${copiedCouponInfo.code}) in the promo code field during checkout to enjoy your discount.`}
                      </p>
                    </div>
                  </div>
                </div>

                {/* CTA Actions */}
                <div className="flex flex-col sm:flex-row gap-3">
                  <button 
                    onClick={() => {
                      window.open(copiedCouponInfo.link, '_blank');
                      setCopiedCouponInfo(null);
                      setSelectedArticle(null);
                    }}
                    className="flex-1 bg-primary text-white font-black py-3 px-4 rounded-xl flex items-center justify-center gap-2 shadow-md hover:bg-primary-hover active:scale-95 transition cursor-pointer text-xs"
                  >
                    <ExternalLink size={14} />
                    {lang === 'ar' ? 'توجيهي للمتجر الآن' : 'Go to Store Now'}
                  </button>
                  
                  <button 
                    onClick={() => setCopiedCouponInfo(null)}
                    className="sm:w-28 bg-bg border border-border-main text-text-main font-bold py-3 px-4 rounded-xl hover:bg-border-main/20 active:scale-95 transition cursor-pointer text-xs"
                  >
                    {lang === 'ar' ? 'إغلاق نافذة التنبيه' : 'Close'}
                  </button>
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>

        {/* Selected Article Reading Modal with interactive coupon box */}
        <AnimatePresence>
          {selectedArticle && (
            <>
              {/* Overlay Backdrop */}
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.6 }}
                exit={{ opacity: 0 }}
                onClick={() => setSelectedArticle(null)}
                className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50"
              />
              {/* Modal Container */}
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="fixed inset-4 md:inset-auto md:top-1/2 md:left-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:w-[600px] md:max-h-[85vh] bg-card rounded-3xl border border-border-main shadow-2xl z-50 flex flex-col overflow-hidden text-text-main"
              >
                {/* Header */}
                <div className="p-6 border-b border-border-main flex items-center justify-between bg-bg/50">
                  <div className="flex items-center gap-2 text-primary">
                    <BookOpen size={20} />
                    <span className="text-xs font-black uppercase tracking-wider">{lang === 'ar' ? 'تفاصيل مقال التسوق الذكي' : 'Smart Shopping Article Detail'}</span>
                  </div>
                  <button 
                    onClick={() => setSelectedArticle(null)}
                    className="p-1.5 hover:bg-border-main/50 rounded-lg text-text-main opacity-70 transition cursor-pointer"
                  >
                    <X size={20} />
                  </button>
                </div>

                {/* Content Area */}
                <div className="p-6 overflow-y-auto space-y-6 flex-1 text-right">
                  <div>
                    <h4 className="text-xl md:text-2xl font-black text-text-main leading-tight">
                      {lang === 'ar' ? selectedArticle.title : (selectedArticle.titleEn || selectedArticle.title)}
                    </h4>
                    <div className="w-12 h-1 bg-primary rounded-full mt-3" />
                  </div>

                  <p className="text-sm md:text-base text-text-main/80 leading-relaxed whitespace-pre-wrap font-sans">
                    {selectedArticle.text}
                  </p>

                  {/* Inline Modal AdSense slot */}
                  {adConfig.showAds && (
                    <div className="my-4 p-3 bg-bg border border-border-main rounded-2xl flex flex-col items-center justify-center relative overflow-hidden animate-fadeIn">
                      <span className="absolute top-1 right-2 text-[8px] uppercase tracking-wider font-bold opacity-30">إعلان / Advertisement</span>
                      {adConfig.adBannerUrl ? (
                        <img src={adConfig.adBannerUrl} alt="" className="max-h-20 object-contain rounded-lg mt-2" referrerPolicy="no-referrer" loading="lazy" />
                      ) : (
                        <div className="py-2 text-center mt-2">
                          <span className="text-[10px] text-yellow-500 font-bold block">⚡ مساحة إعلانية برعاية جوجل</span>
                          <span className="text-[9px] text-text-main opacity-50 block">Publisher ID: {adConfig.adClientId || 'Default'}</span>
                        </div>
                      )}
                    </div>
                  )}

                  {/* ATTRACTIVE COUPON CARD */}
                  {selectedArticle.hasCoupon && (
                    <div className="mt-8 overflow-hidden rounded-2xl border-2 border-dashed border-primary/40 bg-primary/5 p-5 relative group transition hover:border-primary/60 hover:bg-primary/[0.08]">
                      {/* Country Flag Badge */}
                      <div className="absolute top-3 left-3 bg-card px-2.5 py-1 rounded-full text-xs font-black shadow-sm border border-border-main flex items-center gap-1.5">
                        <span className="text-sm">{selectedArticle.countryFlag || '🇸🇦'}</span>
                        <span className="text-[10px] text-text-main opacity-60">
                          {selectedArticle.countryFlag === '🇸🇦' ? (lang === 'ar' ? 'السعودية' : 'KSA') :
                           selectedArticle.countryFlag === '🇦🇪' ? (lang === 'ar' ? 'الإمارات' : 'UAE') :
                           selectedArticle.countryFlag === '🇰🇼' ? (lang === 'ar' ? 'الكويت' : 'Kuwait') :
                           selectedArticle.countryFlag === '🇪🇬' ? (lang === 'ar' ? 'مصر' : 'Egypt') :
                           selectedArticle.countryFlag === '🇶🇦' ? (lang === 'ar' ? 'قطر' : 'Qatar') :
                           selectedArticle.countryFlag === '🇧🇭' ? (lang === 'ar' ? 'البحرين' : 'Bahrain') :
                           selectedArticle.countryFlag === '🇴🇲' ? (lang === 'ar' ? 'عمان' : 'Oman') :
                           (lang === 'ar' ? 'عالمي' : 'Global')}
                        </span>
                      </div>

                      <div className="flex flex-col sm:flex-row items-center gap-4 text-center sm:text-right mt-3 sm:mt-0">
                        {/* Store Logo with circular frame */}
                        <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center border border-primary/20 shadow-sm overflow-hidden p-2 flex-shrink-0">
                          <StoreLogo 
                            logo={selectedArticle.customStoreLogo} 
                            name={selectedArticle.customStoreName || 'Store'} 
                            nameAr={selectedArticle.customStoreName} 
                            className="max-w-full max-h-full object-contain" 
                          />
                        </div>

                        <div className="flex-1 min-w-0">
                          <span className="text-xs font-bold text-primary bg-primary/10 px-2.5 py-0.5 rounded-full">
                            {selectedArticle.customStoreName || (lang === 'ar' ? 'عرض خاص' : 'Special Offer')}
                          </span>
                          <h5 className="text-lg font-black mt-2 text-text-main">
                            {selectedArticle.discountText || (lang === 'ar' ? 'كوبون خصم حصري ومميز' : 'Exclusive Discount Coupon')}
                          </h5>
                          <p className="text-[11px] text-text-main/60 mt-1">
                            {lang === 'ar' ? '* اضغط على الكود للنسخ والتوجه للمتجر فوراً' : '* Click on the code to copy and go to store'}
                          </p>
                        </div>
                      </div>

                      {/* Coupon Code copy and CTA block */}
                      <div className="mt-5 flex flex-col sm:flex-row gap-2">
                        {selectedArticle.couponCode ? (
                          <button 
                            onClick={() => {
                              navigator.clipboard.writeText(selectedArticle.couponCode);
                              setCopiedArticleId(selectedArticle.id);
                              setTimeout(() => setCopiedArticleId(null), 2000);
                              
                              setCopiedCouponInfo({
                                code: selectedArticle.couponCode,
                                storeName: selectedArticle.customStoreName || 'Store',
                                storeLogo: selectedArticle.customStoreLogo,
                                link: selectedArticle.referralLink || '#'
                              });
                            }}
                            className="flex-1 bg-primary text-white font-black py-3 px-4 rounded-xl flex items-center justify-center gap-2 shadow-md hover:bg-primary-hover active:scale-95 transition cursor-pointer text-sm"
                          >
                            {copiedArticleId === selectedArticle.id ? (
                              <>
                                <Check size={16} />
                                {lang === 'ar' ? 'تم نسخ الرمز الترويجي!' : 'Promo Code Copied!'}
                              </>
                            ) : (
                              <>
                                <Copy size={16} />
                                <span>{lang === 'ar' ? 'نسخ كود الكوبون: ' : 'Copy Code: '}</span>
                                <span className="bg-white/20 px-2 py-0.5 rounded font-mono text-base ml-1 tracking-wider">
                                  {selectedArticle.couponCode}
                                </span>
                              </>
                            )}
                          </button>
                        ) : (
                          selectedArticle.referralLink && (
                            <a 
                              href={selectedArticle.referralLink} 
                              target="_blank" 
                              rel="noreferrer"
                              className="flex-1 bg-primary text-white font-black py-3 px-4 rounded-xl flex items-center justify-center gap-2 shadow-md hover:bg-primary-hover transition text-sm text-center"
                            >
                              <ExternalLink size={16} />
                              {lang === 'ar' ? 'الانتقال للعرض مباشرة' : 'Go directly to offer'}
                            </a>
                          )
                        )}
                      </div>
                    </div>
                  )}
                </div>

                {/* Footer */}
                <div className="p-4 border-t border-border-main flex items-center justify-end bg-bg/30">
                  <button 
                    onClick={() => setSelectedArticle(null)}
                    className="px-6 py-2 bg-text-main text-card text-xs font-bold rounded-xl hover:opacity-90 transition cursor-pointer"
                  >
                    {lang === 'ar' ? 'إغلاق' : 'Close'}
                  </button>
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>

        <main className="flex-1 flex flex-col p-4 md:p-6 gap-6 max-w-7xl mx-auto w-full">
          {currentView === 'privacy' ? (
            <PrivacyPolicyPage lang={lang} />
          ) : currentView === 'about' ? (
            <AboutUsPage lang={lang} />
          ) : currentView === 'contact' ? (
            <ContactUsPage 
              lang={lang} 
              pushNotification={pushNotification} 
              onAddMessage={(msg) => setVisitorMessages([msg, ...visitorMessages])} 
              contactBannerUrl={contactBannerUrl}
              contactLogoUrl={contactLogoUrl}
              contactEmail={contactEmail}
            />
          ) : currentView === 'store' ? (
            <StoreDetailsPage 
              lang={lang} 
              storeId={selectedStoreId} 
              stores={stores} 
              handleCopy={handleCopy} 
              copiedId={copiedId} 
              onBack={() => {
                setCurrentView('home');
                setSelectedStoreId(null);
                window.location.hash = '';
              }}
            />
          ) : (
            <>
              {/* Top Section: Hero/Search and Actions - Styled Full Width for Premium Feel */}
              <div className="w-full">
              {/* Hero & Smart Search */}
              <div 
                className="relative w-full h-[340px] sm:h-[360px] lg:h-[390px] rounded-3xl overflow-hidden shadow-lg group p-6 sm:p-8 lg:p-10 flex flex-col justify-center text-white"
              >
                {/* Slideshow background Ken Burns layer */}
                <div className="absolute inset-0 z-0 overflow-hidden select-none">
                  <AnimatePresence mode="popLayout">
                    <motion.div
                      key={activeSlide}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 1.2, ease: 'easeInOut' }}
                      className="absolute inset-0"
                    >
                      {heroSlides[activeSlide]?.bgType === 'image' && heroSlides[activeSlide]?.bgImageUrl ? (
                        <div 
                          style={{
                            backgroundImage: `url(${heroSlides[activeSlide].bgImageUrl})`,
                            backgroundSize: 'cover',
                            backgroundPosition: 'center',
                          }}
                          className={`w-full h-full ${
                            heroSlides[activeSlide].panDirection === 'left' 
                              ? 'animate-pan-left-zoom' 
                              : 'animate-pan-right-zoom'
                          }`}
                        />
                      ) : heroSlides[activeSlide]?.bgType === 'color' ? (
                        <div 
                          style={{ backgroundColor: heroSlides[activeSlide].solidColor }}
                          className="w-full h-full"
                        />
                      ) : (
                        <div className="w-full h-full bg-gradient-to-br from-primary to-primary-hover" />
                      )}
                    </motion.div>
                  </AnimatePresence>
                  {/* Visual rich dark overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/50 to-black/35 z-10 pointer-events-none" />
                </div>

                {editMode && (
                  <div className="absolute top-4 right-4 z-20 flex flex-wrap gap-2" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
                    <label className="bg-black/80 hover:bg-black/95 text-white text-[10px] font-black py-2 px-3.5 rounded-xl flex items-center gap-1.5 cursor-pointer shadow-lg border border-white/20 transition-all active:scale-95">
                      <Camera size={12} />
                      <span>{lang === 'ar' ? 'رفع صورة من الكمبيوتر للبانر 🖼️' : 'Upload Banner Image from PC 🖼️'}</span>
                      <input 
                         type="file" 
                         accept="image/*"
                         onChange={(e) => {
                           const file = e.target.files?.[0];
                           if (file) {
                             const reader = new FileReader();
                             reader.onloadend = () => {
                               saveHeroConfig({ ...heroConfig, bgType: 'image', bgImageUrl: reader.result as string });
                             };
                             reader.readAsDataURL(file);
                           }
                         }}
                         className="hidden"
                      />
                    </label>
                    
                    <button
                      onClick={() => {
                        setIsAdminOpen(true);
                        setActiveAdminTab('hero');
                      }}
                      className="bg-black/80 hover:bg-black/95 text-white text-[10px] font-black py-2 px-3 rounded-xl flex items-center gap-1 shadow-lg border border-white/20 transition-all active:scale-95 cursor-pointer"
                    >
                      ⚙️ {lang === 'ar' ? `تعديل الشريحة ${activeSlide + 1}` : `Edit Slide ${activeSlide + 1}`}
                    </button>

                    {heroConfig.bgType === 'image' && (
                      <button
                        onClick={() => saveHeroConfig({ ...heroConfig, bgType: 'gradient' })}
                        className="bg-black/80 hover:bg-black/95 text-white text-[10px] font-black py-2 px-3 rounded-xl flex items-center gap-1 shadow-lg border border-white/20 transition-all active:scale-95 cursor-pointer"
                      >
                        🌈 {lang === 'ar' ? 'إعادة التدرج اللوني' : 'Restore Gradient'}
                      </button>
                    )}
                  </div>
                )}

                {/* Slider Manual Arrows */}
                <button 
                  type="button"
                  onClick={() => setActiveSlide((prev) => (prev - 1 + heroSlides.length) % heroSlides.length)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-black/45 hover:bg-black/75 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 cursor-pointer border border-white/10"
                >
                  <ChevronLeft size={20} />
                </button>
                <button 
                  type="button"
                  onClick={() => setActiveSlide((prev) => (prev + 1) % heroSlides.length)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-black/45 hover:bg-black/75 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 cursor-pointer border border-white/10"
                >
                  <ChevronRight size={20} />
                </button>

                <div className="relative z-10 w-full">
                  {/* Animated Slideshow texts block */}
                  <div className="min-h-[140px] flex flex-col justify-center">
                    <AnimatePresence mode="wait">
                      <motion.div
                        key={activeSlide}
                        initial={{ opacity: 0, y: 12 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -12 }}
                        transition={{ duration: 0.4 }}
                      >
                        <span className="bg-primary text-white text-[10px] font-black px-4 py-1.5 rounded-full w-fit mb-3.5 uppercase tracking-widest inline-block shadow-sm">
                          {lang === 'ar' ? 'أكواد خصم حصرية 🏷️' : 'EXCLUSIVE OFFERS 🏷️'}
                        </span>
                        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black mb-3 leading-tight text-white drop-shadow tracking-tight">
                          {lang === 'ar' ? heroSlides[activeSlide]?.titleAr : heroSlides[activeSlide]?.titleEn}
                        </h1>
                        <p className="text-white/90 text-sm sm:text-base mb-6 max-w-xl leading-relaxed drop-shadow-sm font-medium">
                          {lang === 'ar' ? heroSlides[activeSlide]?.subAr : heroSlides[activeSlide]?.subEn}
                        </p>
                      </motion.div>
                    </AnimatePresence>
                  </div>
                  
                  {/* Smart Search Bar - Kept static relative z-10 to never lose input focus */}
                  <div className="relative flex flex-col sm:flex-row gap-3 max-w-xl mt-1">
                    <div className="relative flex-1">
                      <Search className={`absolute ${lang === 'ar' ? 'right-4' : 'left-4'} top-1/2 -translate-y-1/2 text-white/60`} size={20} />
                      <input 
                        type="text" 
                        placeholder={currLang.searchPlaceholder}
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className={`w-full h-14 bg-white/10 backdrop-blur-md border border-white/20 text-white placeholder-white/60 rounded-xl outline-none focus:border-white focus:ring-4 focus:ring-white/20 transition-all ${lang === 'ar' ? 'pr-12 pl-12' : 'pl-12 pr-12'}`}
                      />
                      {searchQuery && (
                        <button
                          type="button"
                          onClick={() => setSearchQuery('')}
                          className={`absolute ${lang === 'ar' ? 'left-4' : 'right-4'} top-1/2 -translate-y-1/2 text-white/60 hover:text-white hover:scale-110 active:scale-95 transition-all cursor-pointer p-1 rounded-full hover:bg-white/10`}
                          title={lang === 'ar' ? 'مسح البحث' : 'Clear Search'}
                        >
                          <X size={16} />
                        </button>
                      )}
                    </div>
                    <button 
                      onClick={handleSmartSearch}
                      disabled={isSearching}
                      className="bg-white text-slate-900 hover:text-black font-black px-8 py-3 h-14 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center min-w-[140px] cursor-pointer"
                    >
                      {isSearching ? <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin" /> : currLang.searchBtn}
                    </button>
                  </div>
                  
                  <AnimatePresence>
                    {searchResults && (
                      <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 10 }}
                        className="absolute top-full left-0 mt-4 bg-black/70 backdrop-blur-xl p-5 rounded-2xl border border-white/20 max-w-xl w-full shadow-2xl z-30 max-h-[200px] overflow-y-auto animate-fadeIn"
                      >
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-bold flex items-center gap-2"><Search size={16} /> {lang === 'ar' ? 'نتائج البحث الذكي' : 'Smart Search Results'}</h3>
                          <button onClick={() => setSearchResults('')} className="p-1 rounded hover:bg-white/10 text-white/70">
                            <X size={14} />
                          </button>
                        </div>
                        <div className="text-sm leading-relaxed opacity-90 whitespace-pre-wrap">{searchResults}</div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* Sliding Indicator Dots */}
                <div className="absolute bottom-4 left-6 z-10 flex gap-2">
                  {heroSlides.map((_, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setActiveSlide(idx)}
                      className={`h-2 rounded-full transition-all duration-300 cursor-pointer ${activeSlide === idx ? 'bg-yellow-400 w-6' : 'bg-white/40 hover:bg-white/70 w-2'}`}
                      aria-label={`Go to slide ${idx + 1}`}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Single Unified Advertisement Slot under Hero Banner - Exactly One Ad */}
            {(adConfig.showAds || adConfig.showSideAd) && (
              <div className="w-full bg-card rounded-3xl border border-neutral-100 dark:border-neutral-800 p-4 flex flex-col items-center justify-center relative overflow-hidden transition shadow-sm animate-fadeIn mt-6">
                <span className="absolute top-2 right-4 text-[9px] uppercase font-black tracking-widest text-text-main opacity-40">
                  {lang === 'ar' ? 'إعلان مروج' : 'SPONSORED AD'}
                </span>
                
                {adConfig.showAds ? (
                  /* Google AdSense or its custom fallback banner */
                  adConfig.adBannerUrl ? (
                    <a href="https://google.com/adsense" target="_blank" rel="noreferrer" className="w-full flex justify-center mt-3">
                      <img 
                        src={adConfig.adBannerUrl} 
                        alt="AdSense banner advertisement" 
                        className="max-h-24 md:max-h-28 w-auto object-contain rounded-xl"
                        referrerPolicy="no-referrer"
                        loading="lazy"
                      />
                    </a>
                  ) : (
                    <div className="py-4 md:py-6 flex flex-col items-center text-center max-w-lg mt-2">
                      <div className="flex items-center gap-1.5 text-yellow-500 font-bold mb-1.5">
                        <Sparkles size={16} className="animate-pulse" />
                        <span className="text-xs uppercase tracking-wider font-bold">مساحة إعلانية نشطة / Approved AdSense Slot</span>
                      </div>
                      <p className="text-[11px] text-text-main opacity-60 leading-relaxed px-4">
                        {lang === 'ar' 
                          ? `تم ربط حساب أدسنس بنجاح (العميل: ${adConfig.adClientId || 'غير محدد'} | المساحة: ${adConfig.adSlotId || 'افتراضي'}). تظهر الإعلانات تلقائياً للزوار عند تصفح الموقع.` 
                          : `AdSense Connected Successfully (Client: ${adConfig.adClientId || 'Default'} | Slot: ${adConfig.adSlotId || 'Default'}). Ads will serve here.`}
                      </p>
                    </div>
                  )
                ) : (
                  /* Custom Partner Banner styled horizontally for high-end store feel */
                  <a 
                    href={adConfig.sideAdLink || '#'} 
                    target="_blank" 
                    rel="noreferrer"
                    className="w-full relative group block overflow-hidden rounded-2xl border border-border-main mt-3"
                  >
                    <img 
                      src={adConfig.sideAdBannerUrl || 'https://images.unsplash.com/photo-1511556532299-8f662fc26c06?q=80&w=1200&auto=format&fit=crop'} 
                      alt="Advertisement" 
                      className="w-full h-24 md:h-28 object-cover group-hover:scale-[1.02] transition-transform duration-500"
                      referrerPolicy="no-referrer"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-black/20 group-hover:bg-black/30 transition-colors flex items-center justify-between px-6 md:px-12">
                      <div className="text-right text-white drop-shadow-sm" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
                        <h4 className="text-xs sm:text-sm font-black uppercase tracking-wider">
                          {lang === 'ar' ? 'عروض الشركاء الحصرية' : 'Exclusive Partner Deals'}
                        </h4>
                        <p className="text-[10px] sm:text-xs text-white/80 mt-1 max-w-md hidden sm:block">
                          {lang === 'ar' ? 'تسوق من خلال روابطنا الحصرية لدعم المنصة واستمتع بخصومات حصرية.' : 'Shop through our exclusive links to support us and enjoy extra discounts.'}
                        </p>
                      </div>
                      <span className="bg-white text-slate-900 text-[10px] font-black py-2 px-4 rounded-xl shadow-md flex items-center gap-1 group-hover:bg-primary group-hover:text-white transition-all">
                        {lang === 'ar' ? 'احصل على العرض 🛍️' : 'Get Offer 🛍️'}
                      </span>
                    </div>
                  </a>
                )}
              </div>
            )}

          {/* Coupons Section (Grid or Slider) */}
          <div id="offers" className="scroll-mt-24" />
          <div id="stores" className="mt-8 relative scroll-mt-24">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-2">
                <h3 className="font-black text-xl sm:text-2xl text-slate-900 dark:text-white uppercase tracking-wider">{currLang.latestOffers}</h3>
                {editMode && (
                  <span className="bg-red-500 text-white text-[10px] px-2 py-0.5 rounded-full font-bold animate-pulse">وضع التعديل ناشط</span>
                )}
              </div>
              
              <div className="flex items-center gap-3">
                {/* Slideshow Arrow Controls (Only visible in slider mode) */}
                {storesViewMode === 'slider' && (
                  <div className="flex items-center gap-1.5 animate-fadeIn">
                    <button 
                      onClick={scrollPrev}
                      className="p-2 bg-card border border-border-main rounded-full hover:bg-border-main/20 text-text-main transition shadow-sm"
                      aria-label="Previous slide"
                    >
                      <ChevronRight size={18} className="rtl:rotate-0 ltr:rotate-180" />
                    </button>
                    <button 
                      onClick={scrollNext}
                      className="p-2 bg-card border border-border-main rounded-full hover:bg-border-main/20 text-text-main transition shadow-sm"
                      aria-label="Next slide"
                    >
                      <ChevronLeft size={18} className="rtl:rotate-0 ltr:rotate-180" />
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Option 1: Regional Stores Country Filter */}
            <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-card border border-border-main p-4 rounded-2xl">
              <div className="flex items-center gap-2">
                <span className="text-sm font-black text-text-main">
                  📍 {lang === 'ar' ? 'حدد دولتك لتصفح الكوبونات المناسبة:' : 'Select country for regional coupons:'}
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-1.5 overflow-x-auto no-scrollbar scroll-smooth">
                {COUNTRIES.map((country) => {
                  const isSelected = selectedCountryFilter === country.id;
                  return (
                    <motion.button
                      key={country.id}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => {
                        setSelectedCountryFilter(country.id);
                        localStorage.setItem('selected_country_filter', country.id);
                      }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 border shrink-0 ${
                        isSelected
                          ? 'bg-primary text-white border-primary shadow-[0_4px_12px_rgba(239,68,68,0.25)]'
                          : 'bg-bg hover:bg-card border-border-main text-text-main/80 hover:text-text-main'
                      }`}
                    >
                      <span className="text-base leading-none">{country.flag}</span>
                      <span>{lang === 'ar' ? country.nameAr : country.nameEn}</span>
                    </motion.button>
                  );
                })}
              </div>
            </div>

            {/* Coupons Sorting Feature Bar */}
            <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-card border border-border-main p-4 rounded-2xl">
              <div className="flex items-center gap-2">
                <span className="text-sm font-black text-text-main">
                  ⚡ {lang === 'ar' ? 'ترتيب المتاجر حسب:' : 'Sort stores by:'}
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-1.5 overflow-x-auto no-scrollbar scroll-smooth">
                {[
                  { id: 'newest', labelAr: '⏰ الأحدث إضافاً', labelEn: '⏰ Newest Added' },
                  { id: 'discount', labelAr: '🔥 الأعلى خصماً', labelEn: '🔥 Most Discounted' },
                  { id: 'alphabetical', labelAr: '🔤 الترتيب الأبجدي', labelEn: '🔤 Alphabetical' }
                ].map((option) => {
                  const isSelected = storeSortOption === option.id;
                  return (
                    <motion.button
                      key={option.id}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => {
                        setStoreSortOption(option.id as any);
                        localStorage.setItem('store_sort_option', option.id);
                      }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 border shrink-0 ${
                        isSelected
                          ? 'bg-primary text-white border-primary shadow-[0_4px_12px_rgba(239,68,68,0.25)]'
                          : 'bg-bg hover:bg-card border-border-main text-text-main/80 hover:text-text-main'
                      }`}
                    >
                      <span>{lang === 'ar' ? option.labelAr : option.labelEn}</span>
                    </motion.button>
                  );
                })}
              </div>
            </div>
            
            {filteredStores.length === 0 ? (
              <div className="text-center py-12 bg-card border border-border-main rounded-3xl text-text-main opacity-60">
                {currLang.noStores || (lang === 'ar' ? 'لا توجد متاجر تطابق البحث' : 'No stores matching search')}
              </div>
            ) : storesViewMode === 'grid' ? (
              /* Stores Grid Layout */
              <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-6 animate-fadeIn">
                {filteredStores.map((store: any, sIdx: number) => {
                  const isBgImage = store.bgType === 'image' && store.bgImageUrl;
                  const isBgLogoBlur = store.bgType === 'logoBlur' && store.logo;
                  return (
                    <motion.div 
                      key={store.id}
                      initial={{ opacity: 0, y: 15 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ 
                        type: "spring",
                        stiffness: 110, 
                        damping: 15,
                        delay: Math.min(sIdx * 0.03, 0.2) 
                      }}
                      whileHover={{ 
                        y: -6, 
                        boxShadow: "0 20px 40px -10px rgba(0, 0, 0, 0.06), 0 8px 16px -8px rgba(0, 0, 0, 0.03)",
                      }}
                      whileTap={{ scale: 0.99 }}
                      onClick={() => {
                        if (!editMode) {
                          handleCopy(store.code, store.id, store.link);
                        }
                      }}
                      style={{
                        backgroundColor: store.customBg || (isBgImage || isBgLogoBlur ? 'transparent' : 'var(--slider-card-bg)'),
                        color: store.customText || (isBgImage || isBgLogoBlur ? '#ffffff' : 'var(--slider-card-text)'),
                        borderColor: editMode ? 'rgb(239, 68, 68)' : 'var(--border-color)',
                        backgroundImage: isBgImage ? `url(${store.bgImageUrl})` : undefined,
                        backgroundSize: isBgImage ? 'cover' : undefined,
                        backgroundPosition: isBgImage ? 'center' : undefined,
                      }}
                      className={`p-4 sm:p-6 rounded-2xl border ${editMode ? 'border-dashed animate-pulse' : 'border-border-main'} shadow-[0_4px_20px_-4px_rgba(0,0,0,0.02)] flex flex-col items-center text-center group transition-all duration-300 h-full relative overflow-hidden cursor-pointer`}
                    >

                      {/* Logo blur background layer */}
                      {isBgLogoBlur && (
                        <div 
                          className="absolute inset-0 bg-cover bg-center filter blur-2xl scale-125 opacity-30 pointer-events-none z-0" 
                          style={{ backgroundImage: `url(${store.logo})` }}
                        />
                      )}
                      {/* Overlays for dark/light overlay readability */}
                      {(isBgImage || isBgLogoBlur) && (
                        <div className="absolute inset-0 bg-black/45 z-0 pointer-events-none" />
                      )}

                      {/* Expiring Soon or Hot Deal Badge */}
                      {getExpiryStatus(store.expiryDate) === 'expiring_soon' ? (
                        <div className="absolute top-2 left-2 z-20 bg-amber-500 hover:bg-amber-600 text-white text-[9px] font-black px-2 py-0.5 rounded-lg shadow-md animate-pulse flex items-center gap-1 select-none">
                          <span>{currLang.expiringSoon}</span>
                        </div>
                      ) : isHotDeal(store.discount) ? (
                        <div className="absolute top-2 left-2 z-20 bg-rose-500 hover:bg-rose-600 text-white text-[9px] font-black px-2 py-0.5 rounded-lg shadow-md flex items-center gap-1 select-none transition-all duration-300">
                          <span>🔥 {lang === 'ar' ? 'عرض ساخن' : 'Hot Deal'}</span>
                        </div>
                      ) : null}

                      {/* Country Flag Badge */}
                      {store.country && store.country !== 'all' && COUNTRIES_MAP[store.country] && (
                        <div 
                          className="absolute top-2 right-2 z-20 bg-slate-900/80 backdrop-blur-xs text-white text-[10px] font-black px-2 py-0.5 rounded-lg shadow-md flex items-center gap-1.5 select-none hover:bg-slate-950 transition-all duration-300 border border-slate-700/30"
                          title={lang === 'ar' ? COUNTRIES_MAP[store.country].nameAr : COUNTRIES_MAP[store.country].nameEn}
                        >
                          <span>{COUNTRIES_MAP[store.country].flag}</span>
                          <span className="text-[8px] font-extrabold uppercase tracking-wider">{store.country}</span>
                        </div>
                      )}

                      <div className="relative z-10 flex flex-col items-center h-full w-full">
                        {editMode && (
                          <button 
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteStore(store.id);
                            }}
                            className="absolute top-0 right-0 bg-red-500 text-white p-2 rounded-full shadow hover:bg-red-600 transition cursor-pointer z-20"
                            title="حذف المتجر"
                          >
                            <Trash2 size={14} />
                          </button>
                        )}
                        
                        {/* Premium Logo container with clear frame */}
                        <div 
                          className="w-20 h-11 sm:w-28 sm:h-16 bg-white dark:bg-slate-100 rounded-xl flex items-center justify-center mb-3.5 sm:mb-5 font-bold border border-border-main overflow-hidden p-2 shadow-xs"
                        >
                          <StoreLogo logo={store.logo} name={store.name} nameAr={store.nameAr} className="max-w-full max-h-full object-contain filter group-hover:scale-105 transition-transform duration-300" />
                        </div>
                        
                        {/* Store name with bold geometric sans/RTL feel */}
                        <h4 className="text-xs sm:text-base font-black mb-0.5 sm:mb-1 text-text-main tracking-tight transition-colors group-hover:text-primary truncate max-w-full">
                          {lang === 'ar' ? (store.nameAr || store.name) : store.name}
                        </h4>
                        
                        {/* Bold Fashion discount values */}
                        <p className="text-sm sm:text-lg font-black text-primary tracking-tight leading-none mb-2 sm:mb-3 mt-1">
                          {store.discount}
                        </p>

                        <span className="text-[10px] sm:text-xs text-text-main/50 font-medium tracking-wide mb-4">
                          {lang === 'ar' ? 'كود خصم فعال ومجرب ١٠٠٪' : '100% Active & Verified Code'}
                        </span>
                        
                        {/* Premium Interactive Promo Copy Bar */}
                        <div className="w-full mt-auto">
                          <div className="border border-dashed border-primary/20 bg-bg/50 hover:border-primary/50 rounded-xl p-1 sm:p-1.5 flex justify-between items-center transition-colors duration-300 gap-1.5">
                            <span className="text-text-main font-mono font-extrabold ml-2 sm:ml-3 text-xs sm:text-sm tracking-wider uppercase select-all truncate">{store.code}</span>
                            <motion.button 
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                              onClick={(e) => {
                                e.stopPropagation();
                                handleCopy(store.code, store.id, store.link);
                              }}
                              className="bg-slate-900 hover:bg-black dark:bg-primary dark:hover:bg-primary-hover text-white text-[9px] sm:text-[11px] px-2.5 sm:px-4 py-1.5 sm:py-2 rounded-lg font-black tracking-wide uppercase transition-colors duration-300 flex items-center gap-1 cursor-pointer shrink-0"
                            >
                              {copiedId === store.id ? (
                                <>
                                  <Check size={11} className="stroke-[2.5]" />
                                  <span>{lang === 'ar' ? 'نسخ' : 'Copied'}</span>
                                </>
                              ) : (
                                <>
                                  <Copy size={11} className="stroke-[2.5]" />
                                  <span>{lang === 'ar' ? 'نسخ' : 'Copy'}</span>
                                </>
                              )}
                            </motion.button>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            ) : (
              /* Stores Slider Layout */
              <div className="embla" ref={emblaRef}>
                <div className="embla__container">
                  {filteredStores.map((store: any, sIdx: number) => {
                    const isBgImage = store.bgType === 'image' && store.bgImageUrl;
                    const isBgLogoBlur = store.bgType === 'logoBlur' && store.logo;
                    return (
                      <div className="embla__slide" key={store.id}>
                        <motion.div 
                          initial={{ opacity: 0, y: 30, scale: 0.95 }}
                          whileInView={{ opacity: 1, y: 0, scale: 1 }}
                          viewport={{ once: true }}
                          transition={{ 
                            type: "spring",
                            stiffness: 100, 
                            damping: 15,
                            delay: Math.min(sIdx * 0.05, 0.3) 
                          }}
                          whileHover={{ 
                            y: -6, 
                            boxShadow: "0 20px 40px -10px rgba(0, 0, 0, 0.06), 0 8px 16px -8px rgba(0, 0, 0, 0.03)",
                          }}
                          whileTap={{ scale: 0.99 }}
                          onClick={() => {
                            if (!editMode) {
                              handleCopy(store.code, store.id, store.link);
                            }
                          }}
                          style={{
                            backgroundColor: store.customBg || (isBgImage || isBgLogoBlur ? 'transparent' : 'var(--slider-card-bg)'),
                            color: store.customText || (isBgImage || isBgLogoBlur ? '#ffffff' : 'var(--slider-card-text)'),
                            borderColor: editMode ? 'rgb(239, 68, 68)' : 'var(--border-color)',
                            backgroundImage: isBgImage ? `url(${store.bgImageUrl})` : undefined,
                            backgroundSize: isBgImage ? 'cover' : undefined,
                            backgroundPosition: isBgImage ? 'center' : undefined,
                          }}
                          className={`p-4 sm:p-6 rounded-2xl border ${editMode ? 'border-dashed animate-pulse' : 'border-border-main'} shadow-[0_4px_20px_-4px_rgba(0,0,0,0.02)] flex flex-col items-center text-center group transition-all duration-300 h-full relative overflow-hidden cursor-pointer`}
                        >
                          {/* Logo blur background layer */}
                          {isBgLogoBlur && (
                            <div 
                              className="absolute inset-0 bg-cover bg-center filter blur-2xl scale-125 opacity-30 pointer-events-none z-0" 
                              style={{ backgroundImage: `url(${store.logo})` }}
                            />
                          )}
                          {/* Overlays for dark/light overlay readability */}
                          {(isBgImage || isBgLogoBlur) && (
                            <div className="absolute inset-0 bg-black/45 z-0 pointer-events-none" />
                          )}

                          {/* Expiring Soon or Hot Deal Badge */}
                          {getExpiryStatus(store.expiryDate) === 'expiring_soon' ? (
                            <div className="absolute top-2 left-2 z-20 bg-amber-500 hover:bg-amber-600 text-white text-[9px] font-black px-2 py-0.5 rounded-lg shadow-md animate-pulse flex items-center gap-1 select-none">
                              <span>{currLang.expiringSoon}</span>
                            </div>
                          ) : isHotDeal(store.discount) ? (
                            <div className="absolute top-2 left-2 z-20 bg-rose-500 hover:bg-rose-600 text-white text-[9px] font-black px-2 py-0.5 rounded-lg shadow-md flex items-center gap-1 select-none transition-all duration-300">
                              <span>🔥 {lang === 'ar' ? 'عرض ساخن' : 'Hot Deal'}</span>
                            </div>
                          ) : null}

                          {/* Country Flag Badge */}
                          {store.country && store.country !== 'all' && COUNTRIES_MAP[store.country] && (
                            <div 
                              className="absolute top-2 right-2 z-20 bg-slate-900/80 backdrop-blur-xs text-white text-[10px] font-black px-2 py-0.5 rounded-lg shadow-md flex items-center gap-1.5 select-none hover:bg-slate-950 transition-all duration-300 border border-slate-700/30"
                              title={lang === 'ar' ? COUNTRIES_MAP[store.country].nameAr : COUNTRIES_MAP[store.country].nameEn}
                            >
                              <span>{COUNTRIES_MAP[store.country].flag}</span>
                              <span className="text-[8px] font-extrabold uppercase tracking-wider">{store.country}</span>
                            </div>
                          )}

                          <div className="relative z-10 flex flex-col items-center h-full w-full">
                            {editMode && (
                              <button 
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDeleteStore(store.id);
                                }}
                                className="absolute top-0 right-0 bg-red-500 text-white p-2 rounded-full shadow hover:bg-red-600 transition cursor-pointer z-20"
                                title="حذف المتجر"
                              >
                                <Trash2 size={14} />
                              </button>
                            )}
                            
                            {/* Premium Logo container with clear frame */}
                            <div 
                              className="w-20 h-11 sm:w-28 sm:h-16 bg-white dark:bg-slate-100 rounded-xl flex items-center justify-center mb-3.5 sm:mb-5 font-bold border border-border-main overflow-hidden p-2 shadow-xs"
                            >
                              <StoreLogo logo={store.logo} name={store.name} nameAr={store.nameAr} className="max-w-full max-h-full object-contain filter group-hover:scale-105 transition-transform duration-300" />
                            </div>
                            
                            {/* Store name with bold geometric sans/RTL feel */}
                            <h4 className="text-xs sm:text-base font-black mb-0.5 sm:mb-1 text-text-main tracking-tight transition-colors group-hover:text-primary truncate max-w-full">
                              {lang === 'ar' ? (store.nameAr || store.name) : store.name}
                            </h4>
                            
                            {/* Bold Fashion discount values */}
                            <p className="text-sm sm:text-lg font-black text-primary tracking-tight leading-none mb-2 sm:mb-3 mt-1">
                              {store.discount}
                            </p>

                            <span className="text-[10px] sm:text-xs text-text-main/50 font-medium tracking-wide mb-4">
                              {lang === 'ar' ? 'كود خصم فعال ومجرب ١٠٪' : '100% Active & Verified Code'}
                            </span>
                            
                            {/* Premium Interactive Promo Copy Bar */}
                            <div className="w-full mt-auto">
                              <div className="border border-dashed border-primary/20 bg-bg/50 hover:border-primary/50 rounded-xl p-1 sm:p-1.5 flex justify-between items-center transition-colors duration-300 gap-1.5">
                                <span className="text-text-main font-mono font-extrabold ml-2 sm:ml-3 text-xs sm:text-sm tracking-wider uppercase select-all truncate">{store.code}</span>
                                <motion.button 
                                  whileHover={{ scale: 1.05 }}
                                  whileTap={{ scale: 0.95 }}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleCopy(store.code, store.id, store.link);
                                  }}
                                  className="bg-slate-900 hover:bg-black dark:bg-primary dark:hover:bg-primary-hover text-white text-[9px] sm:text-[11px] px-2.5 sm:px-4 py-1.5 sm:py-2 rounded-lg font-black tracking-wide uppercase transition-colors duration-300 flex items-center gap-1 cursor-pointer shrink-0"
                                >
                                  {copiedId === store.id ? (
                                    <>
                                      <Check size={11} className="stroke-[2.5]" />
                                      <span>{lang === 'ar' ? 'نسخ' : 'Copied'}</span>
                                    </>
                                  ) : (
                                    <>
                                      <Copy size={11} className="stroke-[2.5]" />
                                      <span>{lang === 'ar' ? 'نسخ' : 'Copy'}</span>
                                    </>
                                  )}
                                </motion.button>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Section 2: Browse by Category (تصفح حسب الفئة) */}
          <div className="w-full bg-card rounded-3xl p-6 sm:p-8 border border-border-main shadow-xs text-right animate-fadeIn mt-8" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
            <div className="text-center mb-8">
              <h3 className="font-black text-xl sm:text-2xl text-text-main uppercase tracking-wider">
                {lang === 'ar' ? 'تصفح حسب الفئات' : 'Browse by Category'}
              </h3>
              <p className="text-xs text-text-main/50 mt-2 max-w-lg mx-auto text-center font-medium">
                {lang === 'ar' 
                  ? 'اختر الفئة المفضلة لديك لتصفح أقوى الكوبونات والعروض الحصرية المتاحة لها فوراً.' 
                  : 'Select your favorite category to instantly browse the strongest available coupons and exclusive offers.'}
              </p>
            </div>

            {/* Grid of Categories matching the uploaded mockup */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-6 gap-4">
              {CATEGORIES.map((cat, idx) => {
                const isSelected = selectedCategoryFilter === cat.id;
                return (
                  <motion.button
                    key={cat.id}
                    initial={{ opacity: 0, y: 15 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.35, delay: idx * 0.03 }}
                    whileHover={{ 
                      scale: 1.05, 
                      y: -4,
                      boxShadow: '0 12px 20px -8px rgba(220, 38, 38, 0.15)'
                    }}
                    whileTap={{ scale: 0.96 }}
                    onClick={() => {
                      setSelectedCategoryFilter(isSelected ? null : cat.id);
                      // Clear store filter to prevent conflicts
                      setSelectedStoreFilter(null);
                    }}
                    className={`flex flex-col items-center justify-center p-5 rounded-2xl border transition-all duration-300 cursor-pointer relative group overflow-hidden ${
                      isSelected 
                        ? 'border-primary bg-primary/10 shadow-md ring-2 ring-primary/20' 
                        : 'border-border-main/60 bg-bg/50 hover:border-primary/40 hover:bg-card hover:shadow-xs'
                    }`}
                  >
                    {/* Beautiful 3D Icon container with floating and glowing animation */}
                    <div className="relative mb-3.5 flex items-center justify-center w-14 h-14">
                      {/* Ambient glowing background on selection or hover */}
                      <motion.div 
                        className={`absolute inset-0 rounded-full blur-md opacity-30 transition-all duration-300 ${
                          isSelected ? 'bg-primary scale-125' : 'bg-primary/5 group-hover:bg-primary/30 group-hover:scale-110'
                        }`}
                        animate={isSelected ? { scale: [1, 1.25, 1], opacity: [0.3, 0.5, 0.3] } : {}}
                        transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
                      />
                      
                      {failedImages[cat.id] ? (
                        <cat.icon size={28} className="text-primary stroke-[1.8] relative z-10" />
                      ) : (
                        <motion.img 
                          src={cat.imgUrl} 
                          alt={lang === 'ar' ? cat.nameAr : cat.nameEn}
                          className={`w-12 h-12 relative z-10 select-none pointer-events-none ${
                            ['appliances', 'medical', 'baby'].includes(cat.id)
                              ? 'object-cover rounded-full border border-neutral-200 dark:border-neutral-800 shadow-xs'
                              : 'object-contain filter drop-shadow-md'
                          }`}
                          onError={() => setFailedImages(prev => ({ ...prev, [cat.id]: true }))}
                          referrerPolicy="no-referrer"
                          loading="lazy"
                          // Continuous floating animation
                          animate={{
                            y: [0, -4, 0],
                          }}
                          transition={{
                            duration: 2 + (idx % 3) * 0.4,
                            repeat: Infinity,
                            ease: "easeInOut"
                          }}
                          whileHover={{
                            scale: 1.15,
                            rotate: idx % 2 === 0 ? 8 : -8,
                          }}
                        />
                      )}
                    </div>

                    <span className={`text-[11px] sm:text-xs font-black text-center leading-tight transition-colors duration-300 relative z-10 ${isSelected ? 'text-primary' : 'text-text-main opacity-80 group-hover:opacity-100'}`}>
                      {lang === 'ar' ? cat.nameAr : cat.nameEn}
                    </span>
                  </motion.button>
                );
              })}
            </div>

            {/* Clear Filter Bar if a category is selected */}
            {selectedCategoryFilter && (
              <div className="mt-6 flex justify-center">
                <button
                  onClick={() => setSelectedCategoryFilter(null)}
                  className="text-xs bg-primary/10 hover:bg-primary/20 text-primary font-extrabold px-5 py-2 rounded-xl transition-all flex items-center gap-2 shadow-xs cursor-pointer active:scale-95"
                >
                  ✨ {lang === 'ar' ? 'عرض جميع الفئات والمتاجر' : 'Show All Categories & Stores'}
                </button>
              </div>
            )}
          </div>

          {/* Bottom Ad Banner */}
          {adConfig.showBottomAd && (
            <div className="w-full bg-card rounded-3xl border border-border-main p-4 flex flex-col items-center justify-center relative overflow-hidden transition shadow-sm animate-fadeIn mt-6">
              <span className="absolute top-2 right-4 text-[8px] uppercase font-black tracking-widest text-text-main opacity-40">
                {lang === 'ar' ? 'مساحة إعلانية سفلية' : 'Bottom Advertisement Slot'}
              </span>
              
              <a 
                href={adConfig.bottomAdLink || '#'} 
                target="_blank" 
                rel="noreferrer" 
                className="w-full flex justify-center mt-3 relative group overflow-hidden rounded-2xl border border-border-main"
              >
                <img 
                  src={adConfig.bottomAdBannerUrl || 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?q=80&w=1200&auto=format&fit=crop'} 
                  alt="Bottom Banner Advertisement" 
                  className="max-h-36 md:max-h-44 w-full object-cover group-hover:scale-[1.02] transition-transform duration-500"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-black/40 group-hover:bg-black/30 transition-colors flex items-center justify-between px-6 md:px-12 text-white">
                  <div className="text-right" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
                    <span className="bg-yellow-400 text-black text-[9px] font-black px-2 py-0.5 rounded-full mb-1 inline-block uppercase tracking-wider">
                      {lang === 'ar' ? 'إعلان خاص' : 'Special Ad'}
                    </span>
                    <h3 className="text-sm md:text-xl font-extrabold text-white leading-tight">
                      {lang === 'ar' ? 'تسوق المنتجات العالمية بأفضل الأسعار' : 'Shop Global Products at the Best Prices'}
                    </h3>
                    <p className="text-[10px] md:text-xs text-white/95 mt-1 hidden sm:block">
                      {lang === 'ar' ? 'اضغط هنا لزيارة شركائنا المعتمدين والاستمتاع بالعروض.' : 'Click to visit our verified partners and enjoy the deals.'}
                    </p>
                  </div>
                  <span className="bg-white text-primary text-xs font-black py-2.5 px-5 rounded-xl shadow-lg transition-transform group-hover:scale-105">
                    {lang === 'ar' ? 'تسوّق الآن' : 'Shop Now'}
                  </span>
                </div>
              </a>
            </div>
          )}

          {/* Bottom Section: SEO Articles - Full Width */}
          <div className="w-full mt-8" id="blog">
            {/* Articles */}
            <div className="w-full bg-card rounded-3xl p-6 md:p-8 border border-border-main shadow-sm transition-colors duration-300">
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-xl">{currLang.articles}</h3>
                  {editMode && (
                    <span className="bg-red-500 text-white text-[10px] px-2 py-0.5 rounded-full font-bold">وضع التعديل</span>
                  )}
                </div>
                <a href="#" className="text-primary text-sm font-bold hover:underline">{lang === 'ar' ? 'مشاهدة الكل' : 'View All'}</a>
              </div>
              
              {filteredArticles.length === 0 ? (
                <div className="text-center py-8 text-text-main opacity-60">
                  {lang === 'ar' ? 'لا توجد مقالات تطابق البحث.' : 'No articles matching search.'}
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {filteredArticles.map((article: any) => {
                    const isArticleCoupon = article.hasCoupon;
                    return (
                      <div 
                        key={article.id} 
                        className={`flex gap-4 group p-4 rounded-3xl border border-border-main hover:border-primary/30 bg-card/50 hover:bg-card transition duration-300 relative ${editMode ? 'border border-dashed border-red-500/50 bg-red-500/5' : ''}`}
                      >
                        <div className="w-16 h-16 md:w-20 md:h-20 bg-bg rounded-2xl flex-shrink-0 flex items-center justify-center text-text-main group-hover:bg-primary/10 transition-colors relative">
                          <BookOpen size={24} className="opacity-60 group-hover:opacity-100 group-hover:text-primary transition-all" />
                          {isArticleCoupon && (
                            <span className="absolute -top-1 -right-1 bg-primary text-white text-[9px] px-1.5 py-0.5 rounded-full font-black flex items-center gap-0.5 shadow">
                              <Sparkles size={8} />
                              {article.countryFlag || '🇸🇦'}
                            </span>
                          )}
                        </div>
                        <div className="flex flex-col justify-center flex-1 min-w-0">
                          <h5 className="text-sm md:text-base font-black leading-tight truncate mb-1">
                            {lang === 'ar' ? article.title : (article.titleEn || article.title)}
                          </h5>
                          <p className="text-xs text-text-main opacity-70 line-clamp-2 leading-relaxed mb-3">{article.text}</p>
                          
                          <div className="flex items-center justify-between mt-auto">
                            <button 
                              onClick={() => setSelectedArticle(article)}
                              className="text-xs text-primary font-bold flex items-center gap-1 hover:underline w-fit cursor-pointer"
                            >
                              <BookOpen size={14} /> {currLang.readArticle}
                            </button>
                            
                            {editMode && (
                              <button 
                                onClick={() => handleDeleteArticle(article.id)}
                                className="text-red-500 hover:text-red-600 transition cursor-pointer"
                                title="حذف المقال"
                              >
                                <Trash2 size={14} />
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Section 5: FAQs Section - Accordion (الأسئلة الشائعة حول الكوبونات) */}
          <div className="w-full mt-8" id="faq">
            <div className="w-full bg-card rounded-3xl p-6 md:p-8 border border-border-main shadow-xs text-right" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
              <div className="text-center max-w-xl mx-auto mb-8">
                <span className="bg-primary/10 text-primary text-[10px] font-black px-3.5 py-1.5 rounded-full inline-block mb-2 uppercase tracking-wide">
                  {lang === 'ar' ? 'أجوبة سريعة وموثوقة 💡' : 'Quick & Trusted Answers 💡'}
                </span>
                <h3 className="font-extrabold text-xl sm:text-2xl text-text-main">
                  {lang === 'ar' ? 'الأسئلة الشائعة حول كود الخصم والكوبونات' : 'Frequently Asked Questions About Coupons'}
                </h3>
                <p className="text-xs text-text-main opacity-60 mt-2 leading-relaxed">
                  {lang === 'ar' 
                    ? 'كل ما تود معرفته حول كيفية عمل أكواد الخصم والحصول على أقصى توفير عند التسوق عبر الإنترنت.' 
                    : 'Everything you need to know about how promo codes work and how to maximize your savings online.'}
                </p>
              </div>

              <div className="max-w-3xl mx-auto space-y-4">
                {[
                  {
                    qAr: "كيف يمكنني تفعيل واستخدام كود الخصم بنجاح؟",
                    qEn: "How do I successfully apply and use a promo code?",
                    aAr: "لتفعيل الكود بنجاح، قم بالضغط على زر 'نسخ الكوبون' في موقعنا، وسيتم نسخ الرمز الترويجي تلقائياً وفتح صفحة المتجر الشريك. عند إتمام عملية الشراء في المتجر، قم بلصق الكود في المربع المخصص لرمز الخصم قبل الدفع وستلاحظ خصم القيمة فوراً.",
                    aEn: "To activate the code, click 'Copy Coupon' on our site. The promo code will be copied automatically, and the store page will open. During checkout at the store, paste the code in the discount code field to apply your savings instantly."
                  },
                  {
                    qAr: "لماذا يظهر الكوبون غير فعال في بعض الأحيان؟",
                    qEn: "Why does a coupon code sometimes appear as invalid?",
                    aAr: "تخضع الكوبونات لشروط وأحكام يحددها المتجر نفسه، مثل: الحد الأدنى لقيمة السلة، أو اقتصار الخصم على منتجات غير مخفضة، أو انتهاء فترة العرض الترويجي. نحن في منصة وفير نقوم بتحديث ومراجعة الكوبونات يومياً لنضمن لك أعلى نسبة فعالية.",
                    aEn: "Coupons are subject to terms set by the store, such as a minimum cart value, applicability to non-sale items only, or promotion expiry. At Wafeer, we verify and update our discount codes daily to ensure maximum reliability."
                  },
                  {
                    qAr: "هل موقع وفير مجاني بالكامل؟",
                    qEn: "Is Wafeer completely free to use?",
                    aAr: "نعم، موقع وفير مجاني 100% ولا يتطلب أي رسوم أو تسجيل حساب للاستفادة من الكوبونات. هدفنا هو تزويد جميع المستهلكين بأفضل العروض وتسهيل تجربة تسوق ممتعة وموفرة للمال.",
                    aEn: "Yes, Wafeer is 100% free and does not require any fees or registration to enjoy coupons. Our mission is to provide shoppers with the best active deals to make online shopping affordable."
                  },
                  {
                    qAr: "كيف أضمن الحصول على أكبر قيمة توفير ممكنة؟",
                    qEn: "How can I guarantee getting the highest savings possible?",
                    aAr: "لضمان التوفير الأقصى، ننصحك بالتحقق من موقعنا بشكل دوري قبل كل عملية تسوق، والجمع بين الكوبونات الحصرية التي نقدمها مع عروض الشحن المجاني وفترات التصفيات الموسمية (مثل البلاك فرايدي وعروض الأعياد).",
                    aEn: "To guarantee maximum savings, we recommend checking our platform before every purchase, and combining our exclusive coupon codes with free shipping offers and seasonal sales."
                  }
                ].map((item, idx) => {
                  const isOpen = faqOpenIndex === idx;
                  return (
                    <div 
                      key={idx} 
                      className="border border-border-main rounded-2xl overflow-hidden bg-bg/40 hover:bg-bg transition duration-300"
                    >
                      <button
                        onClick={() => setFaqOpenIndex(isOpen ? null : idx)}
                        className="w-full p-5 text-right flex items-center justify-between gap-4 font-bold text-sm sm:text-base text-text-main cursor-pointer"
                        dir={lang === 'ar' ? 'rtl' : 'ltr'}
                      >
                        <span className="leading-snug">{lang === 'ar' ? item.qAr : item.qEn}</span>
                        <ChevronDown 
                          size={18} 
                          className={`text-primary flex-shrink-0 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} 
                        />
                      </button>
                      
                      <AnimatePresence initial={false}>
                        {isOpen && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: "auto", opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.25, ease: "easeInOut" }}
                          >
                            <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-text-main opacity-80 leading-relaxed border-t border-border-main/50 bg-card/60">
                              {lang === 'ar' ? item.aAr : item.aEn}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
            </>
          )}
        </main>

        {/* Full-Width Footer at the Bottom */}
        <footer className="w-full bg-footer-bg text-slate-100 mt-8 border-t border-white/10 transition-colors duration-300 py-6 px-4 sm:px-6 lg:px-8 text-right" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
          <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6 pb-6 border-b border-white/10">
            {/* About / Brand column */}
            <div className="space-y-2">
              <h4 className="text-base font-extrabold text-white tracking-tight flex items-center gap-2 justify-start">
                💰 {lang === 'ar' ? 'وفير / Wafeer' : 'Wafeer'}
              </h4>
              <p className="text-xs text-slate-200 leading-relaxed font-medium">
                {lang === 'ar' ? footerDescAr : footerDescEn}
              </p>
            </div>

            {/* Quick Links & Contact Column (Merged) */}
            <div className="space-y-2">
              <h4 className="text-sm font-extrabold text-white uppercase tracking-wider justify-start">
                {lang === 'ar' ? footerLinksTitleAr : footerLinksTitleEn}
              </h4>
              <div className="grid grid-cols-2 gap-4">
                <ul className="space-y-1.5 text-xs font-semibold">
                  <li>
                    <a href="#" className="text-slate-200 hover:text-amber-300 hover:underline transition-all flex items-center gap-1">
                      <span>•</span> {lang === 'ar' ? 'الرئيسية' : 'Home'}
                    </a>
                  </li>
                  <li>
                    <a href="#about" className="text-slate-200 hover:text-amber-300 hover:underline transition-all flex items-center gap-1">
                      <span>•</span> {lang === 'ar' ? 'من نحن' : 'About Us'}
                    </a>
                  </li>
                  <li>
                    <a href="#privacy" className="text-slate-200 hover:text-amber-300 hover:underline transition-all flex items-center gap-1">
                      <span>•</span> {lang === 'ar' ? 'سياسة الخصوصية' : 'Privacy Policy'}
                    </a>
                  </li>
                  <li>
                    <a href="#contact" className="text-slate-200 hover:text-amber-300 hover:underline transition-all flex items-center gap-1">
                      <span>•</span> {lang === 'ar' ? 'اتصل بنا' : 'Contact Us'}
                    </a>
                  </li>
                </ul>

                <ul className="space-y-1.5 text-xs text-slate-200 font-medium">
                  <li className="flex items-center gap-2">
                    <Phone size={12} className="text-amber-300 flex-shrink-0" />
                    <a href={`tel:${contactPhone.replace(/\s+/g, '')}`} className="hover:text-amber-300 hover:underline transition-colors text-[11px] font-semibold">
                      {contactPhone}
                    </a>
                  </li>
                  <li className="flex items-center gap-2">
                    <Mail size={12} className="text-amber-300 flex-shrink-0" />
                    <a href={`mailto:${contactEmail}`} className="hover:text-amber-300 hover:underline transition-colors text-[11px] whitespace-nowrap font-semibold">
                      {contactEmail}
                    </a>
                  </li>
                  <li className="flex items-center gap-2">
                    <MapPin size={12} className="text-amber-300 flex-shrink-0" />
                    <span className="text-[11px]">
                      {lang === 'ar' ? footerLocationAr : footerLocationEn}
                    </span>
                  </li>
                </ul>
              </div>
            </div>

            {/* Social channels column */}
            <div className="space-y-2">
              <h4 className="text-sm font-extrabold text-white uppercase tracking-wider justify-start">
                {lang === 'ar' ? footerSocialTitleAr : footerSocialTitleEn}
              </h4>
              <p className="text-xs text-slate-200 leading-relaxed font-medium">
                {lang === 'ar' ? footerSocialDescAr : footerSocialDescEn}
              </p>
              <div className="flex flex-wrap gap-2 pt-1">
                {socialLinks.map((link: any) => (
                  <a 
                    key={link.id}
                    href={link.url} 
                    target="_blank" 
                    rel="noreferrer" 
                    className="w-8 h-8 rounded-lg bg-[#1d4ed8]/30 flex items-center justify-center cursor-pointer hover:bg-amber-400 hover:text-blue-900 hover:scale-105 active:scale-95 text-slate-100 transition-all border border-[#1d4ed8]/50 hover:border-amber-400"
                    title={lang === 'ar' ? link.nameAr : link.nameEn}
                  >
                    {getSocialIcon(link.platform, link.nameEn || link.nameAr)}
                  </a>
                ))}
              </div>
            </div>
          </div>

          {/* Copyright bar */}
          <div className="max-w-7xl mx-auto pt-6 flex flex-col md:flex-row items-center justify-between text-xs text-slate-300 font-medium gap-4">
            <p className="text-center md:text-right">
              {currLang.footerText}
            </p>
            <p className="flex items-center gap-1.5 text-center md:text-left text-slate-300">
              <span>{lang === 'ar' ? footerCopyrightTextAr : footerCopyrightTextEn}</span>
              <span>•</span>
              <span className="opacity-90">© {new Date().getFullYear()} {footerCopyrightCompany}</span>
            </p>
          </div>
        </footer>

        {/* Floating WhatsApp Chat Widget */}
        <div className={`fixed bottom-6 ${lang === 'ar' ? 'left-6' : 'right-6'} z-40 flex flex-col items-end gap-3`}>
          <AnimatePresence>
            {isWhatsappWidgetOpen && (
              <motion.div
                initial={{ opacity: 0, scale: 0.85, y: 25 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.85, y: 25 }}
                transition={{ type: 'spring', damping: 20, stiffness: 260 }}
                className="w-80 bg-card rounded-2xl shadow-2xl border border-border-main overflow-hidden flex flex-col mb-2 text-text-main"
                dir={lang === 'ar' ? 'rtl' : 'ltr'}
              >
                {/* Header */}
                <div className="bg-[#25D366] text-white p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center text-white relative">
                      <MessageCircle size={22} />
                      <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-400 border-2 border-[#25D366] animate-pulse" />
                    </div>
                    <div>
                      <h4 className="font-extrabold text-sm">{lang === 'ar' ? 'انضم لجروب الواتساب الرسمي' : 'Join Official WhatsApp Group'}</h4>
                      <p className="text-[10px] text-white/90 font-medium flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
                        {lang === 'ar' ? 'متاح للانضمام الآن' : 'Open for joining now'}
                      </p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setIsWhatsappWidgetOpen(false)}
                    className="p-1 hover:bg-white/10 text-white rounded-lg transition"
                  >
                    <X size={16} />
                  </button>
                </div>

                {/* Body message */}
                <div className="p-5 bg-bg/45 text-xs space-y-3.5 leading-relaxed">
                  <div className="p-3 bg-card rounded-xl rounded-tl-none shadow-sm text-text-main/80 border border-border-main">
                    {lang === 'ar' ? 'أهلاً بك 👋 هل ترغب بتوفير المال بذكاء؟' : 'Welcome! 👋 Want to save money smartly?'}
                  </div>
                  <div className="p-3 bg-card rounded-xl rounded-tl-none shadow-sm text-text-main/80 border border-border-main">
                    {lang === 'ar' ? 'انضم إلى الجروب الرسمي الخاص بنا وتلقى أحدث الكوبونات والخصومات الحصرية الموفرة للكاش مباشرة على هاتفك فور صدورها مجاناً!' : 'Join our official group and receive the latest coupons and cash-saving discounts directly on your phone as soon as they drop!'}
                  </div>
                </div>

                {/* Footer action */}
                <div className="p-3.5 bg-card border-t border-border-main flex justify-center">
                  <a 
                    href={whatsappLink} 
                    target="_blank" 
                    rel="noreferrer" 
                    onClick={() => setIsWhatsappWidgetOpen(false)}
                    className="w-full bg-[#25D366] hover:bg-[#20b858] text-white font-bold py-3 px-4 rounded-xl flex items-center justify-center gap-2 text-xs shadow-md active:scale-95 transition-all text-center"
                  >
                    <MessageCircle size={16} />
                    <span>{lang === 'ar' ? 'انضم للجروب الرسمي الآن' : 'Join Official Group Now'}</span>
                  </a>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Trigger button with pulsing indicator */}
          <motion.button
            onClick={() => setIsWhatsappWidgetOpen(!isWhatsappWidgetOpen)}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="w-14 h-14 rounded-full bg-[#25D366] text-white flex items-center justify-center shadow-2xl hover:bg-[#20b858] transition-colors relative cursor-pointer z-40 border border-emerald-400/20"
            title={lang === 'ar' ? 'انضم لجروب الواتساب' : 'Join WhatsApp Group'}
          >
            <MessageCircle size={28} className="animate-pulse" />
            
            {/* Pulsing attention grabber */}
            <span className="absolute -top-1.5 -right-1.5 bg-red-500 text-white text-[10px] font-black w-5.5 h-5.5 rounded-full flex items-center justify-center shadow animate-bounce border-2 border-white dark:border-slate-900">
              1
            </span>
            <span className="absolute inset-0 rounded-full border-4 border-[#25D366]/40 animate-ping -z-10" />
          </motion.button>
        </div>

        {/* Floating Back to Top Button */}
        <AnimatePresence>
          {showScrollTop && (
            <motion.button
              initial={{ opacity: 0, scale: 0.8, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: 10 }}
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              whileHover={{ scale: 1.1, y: -2 }}
              whileTap={{ scale: 0.95 }}
              className={`fixed bottom-6 ${lang === 'ar' ? 'right-6' : 'left-6'} z-40 w-12 h-12 rounded-xl bg-card border border-border-main/80 text-text-main shadow-xl flex items-center justify-center cursor-pointer transition-all duration-300 hover:bg-primary hover:text-white hover:border-primary`}
              title={lang === 'ar' ? 'الرجوع للأعلى' : 'Back to Top'}
            >
              <ArrowUp size={22} />
            </motion.button>
          )}
        </AnimatePresence>

        {/* Admin Login Modal */}
        <AnimatePresence>
          {showLoginModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              {/* Backdrop */}
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.6 }}
                exit={{ opacity: 0 }}
                onClick={() => setShowLoginModal(false)}
                className="absolute inset-0 bg-black"
              />
              {/* Modal Card */}
              <motion.div 
                initial={{ scale: 0.95, opacity: 0, y: 10 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.95, opacity: 0, y: 10 }}
                transition={{ type: 'spring', damping: 25, stiffness: 350 }}
                className="relative bg-card border border-border-main rounded-3xl p-6 w-full max-w-md shadow-2xl z-10 space-y-6"
                dir={lang === 'ar' ? 'rtl' : 'ltr'}
              >
                <div className="flex flex-col items-center text-center space-y-2">
                  <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center text-primary mb-2">
                    <Lock size={24} />
                  </div>
                  <h3 className="font-extrabold text-xl text-text-main">
                    {lang === 'ar' ? 'لوحة تحكم المدير' : 'Admin Control Panel'}
                  </h3>
                  <p className="text-xs text-text-main opacity-70 leading-relaxed">
                    {lang === 'ar' ? 'الرجاء إدخال كلمة المرور للوصول لخيارات التحكم والتعديل البصري للموقع.' : 'Please enter the admin password to access template customizer and visual settings.'}
                  </p>
                </div>

                <form 
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (inputPassword === adminPasswordVal) {
                      setIsAdminAuthenticated(true);
                      localStorage.setItem('isAdminAuthenticated', 'true');
                      setShowLoginModal(false);
                      setIsAdminOpen(true);
                      setLoginError('');
                      
                      const pendingTab = localStorage.getItem('pending_admin_tab');
                      if (pendingTab) {
                        setActiveAdminTab(pendingTab as any);
                        localStorage.removeItem('pending_admin_tab');
                      }
                    } else {
                      setLoginError(lang === 'ar' ? 'كلمة المرور غير صحيحة!' : 'Incorrect password!');
                    }
                  }}
                  className="space-y-4"
                >
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-text-main block">
                      {lang === 'ar' ? 'كلمة مرور المدير' : 'Admin Password'}
                    </label>
                    <input 
                      type="password"
                      placeholder="••••••"
                      value={inputPassword}
                      onChange={(e) => setInputPassword(e.target.value)}
                      className="w-full bg-bg border border-border-main rounded-xl px-4 py-3 text-sm text-text-main focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition"
                      autoFocus
                    />
                    {loginError && (
                      <p className="text-xs text-red-500 font-bold mt-1">
                        {loginError}
                      </p>
                    )}
                  </div>

                  <div className="flex gap-3">
                    <button 
                      type="button"
                      onClick={() => setShowLoginModal(false)}
                      className="flex-1 py-3 bg-border-main/40 text-text-main rounded-xl text-xs font-bold hover:bg-border-main/60 transition cursor-pointer"
                    >
                      {lang === 'ar' ? 'إلغاء' : 'Cancel'}
                    </button>
                    <button 
                      type="submit"
                      className="flex-1 py-3 bg-primary text-white rounded-xl text-xs font-bold hover:bg-primary-hover transition cursor-pointer flex items-center justify-center gap-2"
                    >
                      <Unlock size={14} />
                      <span>{lang === 'ar' ? 'دخول' : 'Login'}</span>
                    </button>
                  </div>
                  
                  <p className="text-[10px] text-center opacity-40">
                    {lang === 'ar' ? 'كلمة المرور الافتراضية هي admin2026' : 'Default password is admin2026'}
                  </p>
                </form>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </div>
    </HelmetProvider>
  );
}
