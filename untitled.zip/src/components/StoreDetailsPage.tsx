import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, 
  ArrowRight,
  Check, 
  Copy, 
  ExternalLink, 
  Star, 
  MessageCircle, 
  Send, 
  Calendar,
  User,
  Info,
  ChevronDown,
  Gift,
  CheckCircle2,
  Share2
} from 'lucide-react';

interface Store {
  id: string;
  name: string;
  nameAr?: string;
  logo: string;
  discount: string;
  code: string;
  link: string;
  categories?: string[];
  customBg?: string;
  customText?: string;
  bgType?: 'solid' | 'gradient' | 'image' | 'logoBlur';
  bgImageUrl?: string;
  descriptionAr?: string;
  descriptionEn?: string;
  expiryDate?: string;
}

interface StoreDetailsPageProps {
  lang: 'ar' | 'en';
  storeId: string | null;
  stores: Store[];
  handleCopy: (code: string, id: string, link: string) => void;
  copiedId: string | null;
  onBack: () => void;
}

interface Review {
  id: string;
  name: string;
  rating: number;
  comment: string;
  date: string;
}

export const StoreDetailsPage: React.FC<StoreDetailsPageProps> = ({
  lang,
  storeId,
  stores,
  handleCopy,
  copiedId,
  onBack
}) => {
  const isAr = lang === 'ar';
  
  const getExpiryStatus = (expiryDateStr: string | undefined | null) => {
    if (!expiryDateStr) return 'none';
    try {
      const expiryDate = new Date(expiryDateStr);
      if (isNaN(expiryDate.getTime())) return 'none';
      const now = new Date();
      const todayOnly = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const expiryOnly = new Date(expiryDate.getFullYear(), expiryDate.getMonth(), expiryDate.getDate());
      const diffTime = expiryOnly.getTime() - todayOnly.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 3600 * 24));
      
      if (diffDays < 0) return 'expired';
      if (diffDays >= 0 && diffDays <= 3) return 'expiring_soon';
      return 'normal';
    } catch {
      return 'none';
    }
  };
  
  // Find the current store
  const store = stores.find(s => s.id === storeId);

  // Local reviews state
  const [reviews, setReviews] = useState<Review[]>([]);
  const [newReviewName, setNewReviewName] = useState('');
  const [newReviewRating, setNewReviewRating] = useState(5);
  const [newReviewComment, setNewReviewComment] = useState('');
  const [reviewSubmitted, setReviewSubmitted] = useState(false);
  const [activeFaq, setActiveFaq] = useState<number | null>(null);
  const [showShareTooltip, setShowShareTooltip] = useState(false);

  // Load reviews from localStorage
  useEffect(() => {
    if (storeId) {
      const savedReviews = localStorage.getItem(`store_reviews_${storeId}`);
      if (savedReviews) {
        try {
          setReviews(JSON.parse(savedReviews));
        } catch (e) {
          console.error(e);
        }
      } else {
        // Seed default reviews for better visual polish
        const defaultReviews: Review[] = [
          {
            id: '1',
            name: isAr ? 'أحمد الحربي' : 'Ahmed Al-Harbi',
            rating: 5,
            comment: isAr ? 'الكوبون شغال وممتاز جداً ووفر لي أكثر من 50 ريال، شكراً لكم منصة وفير' : 'The coupon is working and excellent, saved me more than 50 SAR. Thank you Wafeer!',
            date: '2026-07-10'
          },
          {
            id: '2',
            name: isAr ? 'سارة الشمري' : 'Sarah Al-Shammari',
            rating: 5,
            comment: isAr ? 'جربت كود الخصم على السلة وتفعل فوراً، أنصح الجميع باستخدامه قبل الدفع' : 'Tried the discount code on my cart and it was activated immediately. Highly recommend using it before paying.',
            date: '2026-07-14'
          }
        ];
        setReviews(defaultReviews);
        localStorage.setItem(`store_reviews_${storeId}`, JSON.stringify(defaultReviews));
      }
    }
  }, [storeId, isAr]);

  if (!store) {
    return (
      <div className="text-center py-20 bg-card border border-border-main rounded-3xl" dir={isAr ? 'rtl' : 'ltr'}>
        <h2 className="text-xl font-bold text-text-main mb-4">
          {isAr ? 'المتجر غير موجود' : 'Store Not Found'}
        </h2>
        <button onClick={onBack} className="bg-primary text-white px-6 py-2 rounded-xl font-extrabold cursor-pointer hover:bg-primary-hover transition">
          {isAr ? 'العودة للرئيسية' : 'Go Back Home'}
        </button>
      </div>
    );
  }

  // Handle Review submission
  const handleAddReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReviewName.trim() || !newReviewComment.trim()) return;

    const newReview: Review = {
      id: Date.now().toString(),
      name: newReviewName,
      rating: newReviewRating,
      comment: newReviewComment,
      date: new Date().toISOString().split('T')[0]
    };

    const updatedReviews = [newReview, ...reviews];
    setReviews(updatedReviews);
    localStorage.setItem(`store_reviews_${store.id}`, JSON.stringify(updatedReviews));

    // Reset Form
    setNewReviewName('');
    setNewReviewRating(5);
    setNewReviewComment('');
    setReviewSubmitted(true);
    setTimeout(() => setReviewSubmitted(false), 3000);
  };

  // Calculate Average Rating
  const averageRating = reviews.length > 0 
    ? (reviews.reduce((acc, r) => acc + r.rating, 0) / reviews.length).toFixed(1)
    : '5.0';

  // Meta Title & Description for SEO
  const seoTitle = isAr 
    ? `كود خصم ${store.nameAr || store.name} 2026 | كوبون فعال بقيمة ${store.discount} - وفير`
    : `${store.name} Coupon Code 2026 | ${store.discount} Active Discount - Wafeer`;
  
  const seoDesc = isAr
    ? `وفر أموالك مع أقوى كود خصم ${store.nameAr || store.name} المحدث لعام 2026. احصل على توفير ${store.discount} فوراً ومجاناً على جميع الطلبيات والمنتجات.`
    : `Save money with the best active ${store.name} coupon code updated for 2026. Get an instant ${store.discount} discount on your orders for free.`;

  // Sharing functionality
  const handleShare = () => {
    const pageUrl = window.location.href;
    const shareText = `${seoTitle}\n${pageUrl}`;
    
    if (navigator.share) {
      navigator.share({
        title: seoTitle,
        text: seoDesc,
        url: pageUrl
      }).catch(console.error);
    } else {
      navigator.clipboard.writeText(shareText).then(() => {
        setShowShareTooltip(true);
        setTimeout(() => setShowShareTooltip(false), 2000);
      });
    }
  };

  // Store descriptive translation or custom fallback
  const storeDesc = isAr 
    ? (store.descriptionAr || `استخدم كود خصم ${store.nameAr || store.name} الحصري لعام 2026 للحصول على أعلى نسبة توفير إضافية متاحة على جميع مشترياتك. الكود فعال ومجرب على كافة المنتجات المخفضة وغير المخفضة.`)
    : (store.descriptionEn || `Use our exclusive ${store.name} coupon code for 2026 to unlock the maximum extra discount on your cart. Tested and fully verified on all products.`);

  // Custom static FAQs based on store
  const faqs = [
    {
      qAr: `كيف يمكنني تفعيل كود خصم ${store.nameAr || store.name}؟`,
      qEn: `How do I activate the ${store.name} coupon code?`,
      aAr: `لتفعيل الخصم بنجاح: 1) اضغط على زر "نسخ الكوبون" لنسخ الرمز تلقائياً. 2) اضغط على زر "الذهاب للمتجر" لفتح موقع المتجر الرسمي. 3) أضف مشترياتك المفضلة إلى السلة. 4) قبل خطوة الدفع، الصق الكوبون في المربع المخصص له واضغط تطبيق لتلاحظ خصم القيمة فوراً!`,
      aEn: `To activate the discount: 1) Click "Copy Code" to automatically copy the coupon. 2) Click "Go to Store" to visit the official shop. 3) Add products to your cart. 4) Paste the coupon code in the promo/discount box at checkout and apply to see the price drop instantly!`
    },
    {
      qAr: `هل كود خصم ${store.nameAr || store.name} فعال على جميع المنتجات؟`,
      qEn: `Is the ${store.name} discount code valid on all items?`,
      aAr: `نعم، الكود الموفر من خلال منصة وفير فعال ومجرب على معظم المنتجات والماركات المتوفرة في المتجر، بما في ذلك المنتجات الخاضعة لخصومات موسمية أو عروض خاصة لتستمتع بخصم تراكمي رائع.`,
      aEn: `Yes, the coupon provided on Wafeer is tested and valid on most brands and items in the store, including already discounted or on-sale products, giving you an extra stackable discount.`
    },
    {
      qAr: `كم مرة يمكنني استخدام كود خصم ${store.nameAr || store.name}؟`,
      qEn: `How many times can I use the ${store.name} discount code?`,
      aAr: `يمكنك استخدام كود الخصم في كل عملية تسوق جديدة تقوم بها من المتجر. احرص دائماً على زيارة وفير للحصول على أحدث الأكواد الفعالة قبل أي عملية شراء لضمان التوفير.`,
      aEn: `You can reuse this discount code for every new order you place. Make sure to visit Wafeer to grab the latest active coupon before finalizing any purchase.`
    }
  ];

  // Recommendations
  const relatedStores = stores
    .filter(s => s.id !== store.id)
    .slice(0, 4);

  return (
    <div className="w-full flex flex-col gap-6" dir={isAr ? 'rtl' : 'ltr'}>
      <Helmet>
        <title>{seoTitle}</title>
        <meta name="description" content={seoDesc} />
        <meta name="keywords" content={`${store.name}, ${store.nameAr || ''}, كود خصم ${store.nameAr || ''}, كوبون خصم ${store.nameAr || ''}, كوبونات 2026`} />
      </Helmet>

      {/* Breadcrumbs for SEO */}
      <div className="flex items-center justify-between bg-card px-4 py-3 rounded-2xl border border-border-main text-xs sm:text-sm text-text-main/80 animate-fadeIn">
        <div className="flex items-center gap-1.5 sm:gap-2">
          <a href="#" className="hover:text-primary transition font-bold">{isAr ? 'الرئيسية' : 'Home'}</a>
          <span className="opacity-40">/</span>
          <a href="#stores" className="hover:text-primary transition font-bold">{isAr ? 'المتاجر' : 'Stores'}</a>
          <span className="opacity-40">/</span>
          <span className="text-primary font-extrabold truncate max-w-[120px] sm:max-w-none">
            {isAr ? `كود خصم ${store.nameAr || store.name}` : `${store.name} Coupon`}
          </span>
        </div>
        <button 
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs bg-primary/10 text-primary hover:bg-primary/20 px-3 py-1.5 rounded-lg transition font-bold cursor-pointer active:scale-95 shrink-0"
        >
          {isAr ? <ArrowLeft size={14} /> : <ArrowRight size={14} />}
          <span>{isAr ? 'العودة' : 'Back'}</span>
        </button>
      </div>

      {/* Main Grid Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Store Card Info & FAQs */}
        <div className="lg:col-span-2 flex flex-col gap-6">
          
          {/* Enhanced Store Cover / Profile Card */}
          <div className="bg-card rounded-3xl border border-border-main p-6 md:p-8 relative overflow-hidden shadow-xs animate-fadeIn">
            {/* Background Accent Gradients */}
            <div className="absolute top-0 right-0 w-48 h-48 bg-primary/5 rounded-full blur-3xl -z-10" />
            <div className="absolute bottom-0 left-0 w-36 h-36 bg-primary/5 rounded-full blur-2xl -z-10" />

            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6 text-center sm:text-right relative z-10">
              {/* Large Store Logo with glow container */}
              <div className="relative group shrink-0">
                <div className="absolute -inset-1 bg-gradient-to-r from-primary to-primary-hover rounded-2xl blur-md opacity-20 group-hover:opacity-40 transition duration-300" />
                <div className="w-24 h-16 sm:w-32 sm:h-20 bg-white rounded-2xl flex items-center justify-center p-2.5 shadow-sm border border-slate-100 relative z-10">
                  <img src={store.logo} alt={store.name} className="max-w-full max-h-full object-contain select-none" loading="lazy" />
                </div>
              </div>

              {/* Store Details and Rating */}
              <div className="flex-1 flex flex-col justify-between h-full">
                <div>
                  <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 mb-2">
                    <h1 className="text-xl sm:text-3xl font-black text-text-main">
                      {isAr ? `كود خصم ${store.nameAr || store.name}` : `${store.name} Coupon Code`}
                    </h1>
                    <span className="self-center sm:self-start px-2.5 py-1 bg-primary/10 text-primary rounded-full text-xs font-black flex items-center gap-1 shrink-0">
                      <span className="w-1.5 h-1.5 bg-primary rounded-full animate-ping" />
                      {isAr ? 'فعال ومجرب' : 'Active & Verified'}
                    </span>
                  </div>

                  {/* Rating Badge */}
                  <div className="flex items-center justify-center sm:justify-start gap-2 text-sm text-text-main/80 mb-4">
                    <div className="flex text-amber-400">
                      {[1, 2, 3, 4, 5].map((s) => (
                        <Star key={s} size={15} fill={s <= Math.round(parseFloat(averageRating)) ? "currentColor" : "none"} />
                      ))}
                    </div>
                    <span className="font-extrabold text-text-main">{averageRating}</span>
                    <span className="opacity-40">|</span>
                    <span className="text-xs font-bold opacity-60">({reviews.length} {isAr ? 'تقييمات' : 'reviews'})</span>
                  </div>

                  <p className="text-sm text-text-main/70 leading-relaxed mb-6">
                    {storeDesc}
                  </p>
                </div>

                {/* Info Pills */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 border-t border-border-main/50 pt-5 text-right sm:text-right">
                  <div>
                    <span className="block text-[11px] opacity-50 font-bold mb-1">{isAr ? 'أقوى قيمة توفير' : 'Max Saving'}</span>
                    <span className="font-black text-sm text-primary">{store.discount}</span>
                  </div>
                  <div>
                    <span className="block text-[11px] opacity-50 font-bold mb-1">{isAr ? 'حالة الكوبون' : 'Coupon Status'}</span>
                    <span className="font-black text-sm text-primary">{isAr ? 'مستمر ومحدث' : 'Active'}</span>
                  </div>
                  <div className="col-span-2 sm:col-span-1">
                    <span className="block text-[11px] opacity-50 font-bold mb-1">{isAr ? 'صلاحية الكود' : 'Validity'}</span>
                    <div className="flex flex-col gap-0.5">
                      <span className="font-black text-sm text-text-main opacity-90">
                        {store.expiryDate ? store.expiryDate : (isAr ? 'مستمر وفعال' : 'Continuous & Active')}
                      </span>
                      {getExpiryStatus(store.expiryDate) === 'expiring_soon' && (
                        <span className="text-[10px] text-amber-500 font-bold animate-pulse">
                          ⚠️ {isAr ? 'ينتهي قريباً!' : 'Expiring soon!'}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Active Promo Box */}
          <div className="bg-card rounded-3xl border border-border-main p-6 sm:p-8 shadow-xs animate-fadeIn">
            <div className="flex items-center gap-3 mb-6 pb-3 border-b border-border-main/50">
              <div className="p-2 bg-primary/10 text-primary rounded-xl">
                <Gift size={20} />
              </div>
              <h3 className="text-lg font-black text-text-main">
                {isAr ? 'كوبونات خصم المتجر الحالية' : 'Current Active Coupons'}
              </h3>
            </div>

            {/* Standard Big Coupon Card */}
            <div className="bg-bg/40 border border-primary/20 hover:border-primary/50 transition-all rounded-2xl sm:rounded-3xl p-5 sm:p-7 relative overflow-hidden flex flex-col sm:flex-row items-center justify-between gap-6 group">
              <div className="absolute top-0 right-0 w-24 h-24 bg-primary/5 rounded-full blur-xl -z-10" />
              
              <div className="flex-1 text-center sm:text-right w-full sm:w-auto">
                <span className="px-3 py-1 bg-primary/10 text-primary rounded-xl text-xs font-black inline-block mb-3">
                  🔥 {isAr ? 'العرض الأكثر توفيراً لليوم' : 'Todays Best Value Deal'}
                </span>
                <h4 className="text-lg sm:text-xl font-black text-text-main mb-2">
                  {isAr ? `توفير مذهل بقيمة ${store.discount} على السلة` : `Save ${store.discount} on your cart`}
                </h4>
                <p className="text-xs text-text-main/60 max-w-md">
                  {isAr ? 'انسخ هذا الكوبون الذهبي الفعال والملائم لكل المنتجات، والصقه في خانة التخفيض واستمتع بأقصى توفير مجاني لعام 2026.' : 'Copy this premium active coupon and paste it at checkout for a direct cash saving on your order.'}
                </p>
                {getExpiryStatus(store.expiryDate) === 'expiring_soon' && (
                  <div className="mt-2 text-xs font-bold text-amber-500 animate-pulse flex items-center gap-1 justify-center sm:justify-start">
                    <span>⏰ {isAr ? 'هذا الكوبون ينتهي خلال أقل من ٣ أيام! سارع بالاستفادة منه.' : 'This coupon expires in less than 3 days! Use it now.'}</span>
                  </div>
                )}
              </div>

              {/* Action Side */}
              <div className="flex flex-col items-center gap-3 w-full sm:w-auto shrink-0">
                {/* Promo Code Box */}
                <div className="w-full sm:w-56 border-2 border-dashed border-primary/40 bg-card rounded-2xl p-2 flex items-center justify-between gap-4 group-hover:border-primary transition-colors">
                  <span className="text-primary font-mono font-black text-lg sm:text-xl tracking-wider pl-3 uppercase select-all">
                    {store.code}
                  </span>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => handleCopy(store.code, store.id, store.link)}
                    className="bg-primary hover:bg-primary-hover text-white p-2.5 rounded-xl font-bold cursor-pointer transition flex items-center justify-center gap-1 shrink-0"
                    title={isAr ? 'نسخ الكوبون' : 'Copy Code'}
                  >
                    {copiedId === store.id ? (
                      <Check size={16} className="text-white" />
                    ) : (
                      <Copy size={16} className="text-white" />
                    )}
                  </motion.button>
                </div>

                {/* Direct Link */}
                <a 
                  href={store.link} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="w-full sm:w-56 bg-primary hover:bg-primary-hover text-white py-3 px-4 rounded-xl font-black text-xs sm:text-sm text-center flex items-center justify-center gap-2 transition shadow-sm hover:shadow-md cursor-pointer group/btn"
                >
                  <span>{isAr ? 'تفعيل العرض والذهاب للمتجر' : 'Activate & Go to Store'}</span>
                  <ExternalLink size={14} className="group-hover/btn:translate-x-[-2px] transition-transform" />
                </a>

                {/* Share Page Link */}
                <button 
                  onClick={handleShare}
                  className="text-xs font-bold text-text-main/60 hover:text-primary transition flex items-center gap-1 cursor-pointer mt-1"
                >
                  <Share2 size={13} />
                  <span>{isAr ? 'مشاركة الكود الموفر مع الأصدقاء' : 'Share coupon with friends'}</span>
                  {showShareTooltip && (
                    <span className="text-[10px] text-primary font-extrabold animate-pulse">
                      ({isAr ? 'تم نسخ رابط المشاركة!' : 'Share link copied!'})
                    </span>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* FAQs / Accordion Sections */}
          <div className="bg-card rounded-3xl border border-border-main p-6 sm:p-8 shadow-xs animate-fadeIn">
            <div className="flex items-center gap-3 mb-6 pb-3 border-b border-border-main/50">
              <div className="p-2 bg-primary/10 text-primary rounded-xl">
                <Info size={20} />
              </div>
              <h3 className="text-lg font-black text-text-main">
                {isAr ? `الأسئلة الشائعة وتفعيل كود خصم ${store.nameAr || store.name}` : `FAQs about ${store.name} Promo Codes`}
              </h3>
            </div>

            <div className="flex flex-col gap-3">
              {faqs.map((faq, idx) => {
                const isOpen = activeFaq === idx;
                return (
                  <div 
                    key={idx}
                    className="border border-border-main/50 rounded-2xl overflow-hidden transition-all duration-200"
                  >
                    <button
                      onClick={() => setActiveFaq(isOpen ? null : idx)}
                      className="w-full text-right sm:text-right px-5 py-4 bg-bg/20 hover:bg-bg/40 font-bold text-xs sm:text-sm text-text-main flex items-center justify-between gap-4 cursor-pointer"
                    >
                      <span>{isAr ? faq.qAr : faq.qEn}</span>
                      <ChevronDown 
                        size={16} 
                        className={`transition-transform duration-300 opacity-60 shrink-0 ${isOpen ? 'rotate-180 text-primary opacity-100' : ''}`} 
                      />
                    </button>
                    
                    <AnimatePresence>
                      {isOpen && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.2 }}
                          className="overflow-hidden bg-card border-t border-border-main/30"
                        >
                          <p className="px-5 py-4 text-xs sm:text-sm leading-relaxed text-text-main/70">
                            {isAr ? faq.aAr : faq.aEn}
                          </p>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
              })}
            </div>
          </div>

          {/* User Reviews and Comment Submission Section */}
          <div className="bg-card rounded-3xl border border-border-main p-6 sm:p-8 shadow-xs animate-fadeIn">
            <div className="flex items-center gap-3 mb-6 pb-3 border-b border-border-main/50">
              <div className="p-2 bg-primary/10 text-primary rounded-xl">
                <MessageCircle size={20} />
              </div>
              <h3 className="text-lg font-black text-text-main">
                {isAr ? 'تقييمات الزوار وأراء المتسوقين' : 'Shopper Reviews & Feedback'}
              </h3>
            </div>

            {/* Average score card */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center bg-bg/30 p-5 rounded-2xl border border-border-main/40 mb-8 text-center md:text-right">
              <div className="flex flex-col items-center justify-center border-b md:border-b-0 md:border-l border-border-main/60 pb-4 md:pb-0 md:pl-6">
                <span className="text-4xl sm:text-5xl font-black text-text-main mb-1">{averageRating}</span>
                <span className="text-xs font-bold text-text-main opacity-50 mb-3">{isAr ? 'من أصل 5 نجوم' : 'out of 5 stars'}</span>
                <div className="flex text-amber-400 gap-0.5 mb-1">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <Star key={s} size={16} fill={s <= Math.round(parseFloat(averageRating)) ? "currentColor" : "none"} />
                  ))}
                </div>
                <span className="text-[11px] font-bold text-text-main opacity-60">({reviews.length} {isAr ? 'تقييم حقيقي وموثق' : 'verified reviews'})</span>
              </div>

              {/* Progress Bars for ratings */}
              <div className="col-span-2 space-y-2 text-xs font-bold text-text-main/80 px-2 sm:px-4">
                {[5, 4, 3, 2, 1].map((stars) => {
                  const count = reviews.filter(r => r.rating === stars).length;
                  const percent = reviews.length > 0 ? (count / reviews.length) * 100 : 0;
                  return (
                    <div key={stars} className="flex items-center gap-3">
                      <span className="w-10 text-right shrink-0 flex items-center gap-1">
                        <span>{stars}</span>
                        <Star size={11} fill="currentColor" className="text-amber-400 shrink-0" />
                      </span>
                      <div className="flex-1 h-2 bg-border-main/40 rounded-full overflow-hidden">
                        <div className="h-full bg-amber-400 rounded-full" style={{ width: `${percent}%` }} />
                      </div>
                      <span className="w-8 text-left shrink-0 opacity-60">{Math.round(percent)}%</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* List of Reviews */}
            <div className="space-y-4 max-h-[400px] overflow-y-auto pr-1 scrollbar-thin">
              {reviews.map((rev) => (
                <div key={rev.id} className="p-4 bg-bg/25 border border-border-main/50 rounded-2xl flex flex-col gap-2.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center">
                        <User size={15} />
                      </div>
                      <div>
                        <h4 className="text-xs sm:text-sm font-black text-text-main">{rev.name}</h4>
                        <div className="flex text-amber-400 gap-0.5">
                          {[1, 2, 3, 4, 5].map((s) => (
                            <Star key={s} size={10} fill={s <= rev.rating ? "currentColor" : "none"} />
                          ))}
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] text-text-main opacity-40 font-bold flex items-center gap-1">
                      <Calendar size={11} />
                      {rev.date}
                    </span>
                  </div>
                  <p className="text-xs sm:text-sm text-text-main/85 leading-relaxed bg-card/40 p-2.5 rounded-xl">
                    {rev.comment}
                  </p>
                </div>
              ))}
            </div>

            {/* Write a Review Form */}
            <form onSubmit={handleAddReview} className="mt-8 border-t border-border-main/60 pt-8">
              <h4 className="text-sm sm:text-base font-black text-text-main mb-4">
                {isAr ? 'أضف تقييمك الخاص وتجربتك للكوبون' : 'Submit Your Feedback & Experience'}
              </h4>

              {reviewSubmitted && (
                <div className="p-4 mb-4 bg-primary/10 text-primary rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 animate-fadeIn">
                  <CheckCircle2 size={16} />
                  <span>{isAr ? 'شكراً لتقييمك! تم إرسال مراجعتك وإضافتها بنجاح.' : 'Thank you for rating! Your review has been added.'}</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                {/* Name */}
                <div className="space-y-1.5">
                  <label className="text-xs font-black text-text-main opacity-80">{isAr ? 'الاسم الثنائي' : 'Full Name'}</label>
                  <input
                    type="text"
                    required
                    value={newReviewName}
                    onChange={(e) => setNewReviewName(e.target.value)}
                    placeholder={isAr ? 'مثال: محمد السعيد' : 'e.g. John Doe'}
                    className="w-full bg-card rounded-xl border border-border-main p-3 text-xs sm:text-sm text-text-main outline-none focus:border-primary transition"
                  />
                </div>

                {/* Stars Rating Selector */}
                <div className="space-y-1.5">
                  <label className="text-xs font-black text-text-main opacity-80 block">{isAr ? 'تقييمك للكود (عدد النجوم)' : 'Rating (Stars)'}</label>
                  <div className="flex items-center h-11 gap-1.5">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        type="button"
                        key={star}
                        onClick={() => setNewReviewRating(star)}
                        className="text-amber-400 hover:scale-110 active:scale-90 transition cursor-pointer"
                        title={`${star} stars`}
                      >
                        <Star size={24} fill={star <= newReviewRating ? "currentColor" : "none"} />
                      </button>
                    ))}
                    <span className="text-xs font-extrabold text-text-main opacity-60 mr-2 sm:mr-4">
                      {newReviewRating} {isAr ? 'نجوم' : 'stars'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Comment text */}
              <div className="space-y-1.5 mb-4">
                <label className="text-xs font-black text-text-main opacity-80">{isAr ? 'اكتب تجربتك مع الخصم بالتفصيل' : 'Your Review Comment'}</label>
                <textarea
                  required
                  rows={3}
                  value={newReviewComment}
                  onChange={(e) => setNewReviewComment(e.target.value)}
                  placeholder={isAr ? 'اكتب هنا هل تفعل معك الكود؟ ما مقدار التوفير الذي حصلت عليه؟' : 'Write details here...'}
                  className="w-full bg-card rounded-xl border border-border-main p-3 text-xs sm:text-sm text-text-main outline-none focus:border-primary transition resize-none"
                />
              </div>

              <button
                type="submit"
                className="bg-primary hover:bg-primary-hover text-white py-3 px-6 rounded-xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition cursor-pointer shadow-sm hover:shadow active:scale-95"
              >
                <Send size={14} className="rtl:rotate-180" />
                <span>{isAr ? 'إرسال التقييم الآن' : 'Submit Review Now'}</span>
              </button>
            </form>
          </div>
        </div>

        {/* Right Column: Similar Stores & Coupons Table */}
        <div className="flex flex-col gap-6">
          
          {/* SEO Data Table Card */}
          <div className="bg-card rounded-3xl border border-border-main p-6 shadow-xs animate-fadeIn">
            <h3 className="text-sm sm:text-base font-black text-text-main mb-4 pb-3 border-b border-border-main/50">
              📊 {isAr ? 'جدول معلومات الخصم لعام 2026' : 'Discount Summary Table'}
            </h3>
            <div className="border border-border-main/50 rounded-2xl overflow-hidden divide-y divide-border-main/40 text-xs sm:text-sm">
              <div className="flex justify-between p-3.5 bg-bg/20">
                <span className="opacity-60 font-bold">{isAr ? 'اسم المتجر' : 'Store Name'}</span>
                <span className="font-extrabold text-text-main">{isAr ? (store.nameAr || store.name) : store.name}</span>
              </div>
              <div className="flex justify-between p-3.5">
                <span className="opacity-60 font-bold">{isAr ? 'أقوى كود خصم' : 'Promo Code'}</span>
                <span className="font-black text-primary uppercase bg-primary/10 px-2 py-0.5 rounded-md font-mono">{store.code}</span>
              </div>
              <div className="flex justify-between p-3.5 bg-bg/20">
                <span className="opacity-60 font-bold">{isAr ? 'قيمة التوفير المتاحة' : 'Saving Value'}</span>
                <span className="font-extrabold text-text-main">{store.discount}</span>
              </div>
              <div className="flex justify-between p-3.5">
                <span className="opacity-60 font-bold">{isAr ? 'حالة التجربة والفعالية' : 'Verification'}</span>
                <span className="font-extrabold text-primary">100% {isAr ? 'مُجرب ونشط' : 'Verified'}</span>
              </div>
              <div className="flex justify-between p-3.5 bg-bg/20">
                <span className="opacity-60 font-bold">{isAr ? 'صالح للاستخدام' : 'Valid Until'}</span>
                <span className="font-extrabold text-text-main opacity-80">2026-12-31</span>
              </div>
            </div>
          </div>

          {/* Similar Recommended Stores */}
          <div className="bg-card rounded-3xl border border-border-main p-6 shadow-xs animate-fadeIn">
            <h3 className="text-sm sm:text-base font-black text-text-main mb-4 pb-3 border-b border-border-main/50">
              🤝 {isAr ? 'متاجر مشابهة قد تهمك' : 'Recommended Stores'}
            </h3>

            <div className="flex flex-col gap-3">
              {relatedStores.map((s) => (
                <a 
                  key={s.id}
                  href={`#store-${s.id}`}
                  className="flex items-center gap-3.5 p-3 rounded-2xl border border-border-main/50 bg-bg/10 hover:bg-bg/40 hover:border-primary/30 transition duration-300"
                >
                  <div className="w-16 h-10 bg-white rounded-xl flex items-center justify-center p-1.5 shadow-sm shrink-0 border border-slate-100">
                    <img src={s.logo} alt={s.name} className="max-w-full max-h-full object-contain" loading="lazy" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <h4 className="text-xs sm:text-sm font-black text-text-main truncate">
                      {isAr ? (s.nameAr || s.name) : s.name}
                    </h4>
                    <span className="text-[10px] font-bold text-primary flex items-center gap-1 mt-0.5">
                      <span>{s.discount}</span>
                      <span className="opacity-40">•</span>
                      <span>{isAr ? 'كود حصرى' : 'Exclusive Code'}</span>
                    </span>
                  </div>
                </a>
              ))}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
