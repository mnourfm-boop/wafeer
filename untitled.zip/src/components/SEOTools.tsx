import React, { useState } from 'react';
import { 
  Globe, 
  Search, 
  CheckCircle, 
  Send, 
  Terminal, 
  Clipboard, 
  Info, 
  Settings,
  Flame,
  Award,
  Sparkles,
  Link,
  ChevronRight,
  RefreshCw,
  TrendingUp,
  HelpCircle,
  ExternalLink
} from 'lucide-react';

interface SEOToolsProps {
  lang: 'ar' | 'en';
  googleVerificationCode: string;
  setGoogleVerificationCode: (val: string) => void;
  bingVerificationCode: string;
  setBingVerificationCode: (val: string) => void;
  seoTitleAr: string;
  seoTitleEn: string;
  seoDescAr: string;
  seoDescEn: string;
  pushNotification: (type: 'coupon' | 'deal' | 'article', textAr: string, textEn: string) => void;
}

export default function SEOTools({
  lang,
  googleVerificationCode,
  setGoogleVerificationCode,
  bingVerificationCode,
  setBingVerificationCode,
  seoTitleAr,
  seoTitleEn,
  seoDescAr,
  seoDescEn,
  pushNotification
}: SEOToolsProps) {
  const isAr = lang === 'ar';
  
  // Interactive Pinger state
  const [pingerLoading, setPingerLoading] = useState(false);
  const [pingLogs, setPingLogs] = useState<string[]>([]);
  
  // Interactive checklist state (persisted in localStorage)
  const [checklist, setChecklist] = useState<{ [key: string]: boolean }>(() => {
    try {
      const saved = localStorage.getItem('seo_gold_checklist');
      return saved ? JSON.parse(saved) : {
        gsc: false,
        sitemap_submit: false,
        mobile_friendly: true, // pre-verified as we built it fully responsive
        speed: true,          // pre-verified
        keywords: false,
        alt_tags: true,        // pre-verified
        freshness: false,
        internal_links: false
      };
    } catch {
      return {
        gsc: false,
        sitemap_submit: false,
        mobile_friendly: true,
        speed: true,
        keywords: false,
        alt_tags: true,
        freshness: false,
        internal_links: false
      };
    }
  });

  const toggleChecklistItem = (id: string) => {
    const updated = { ...checklist, [id]: !checklist[id] };
    setChecklist(updated);
    localStorage.setItem('seo_gold_checklist', JSON.stringify(updated));
  };

  // Google Search Engine Sitemap Pinger handler
  const handlePingSitemap = async () => {
    if (pingerLoading) return;
    setPingerLoading(true);
    setPingLogs([
      `[info] ${isAr ? 'بدء تشغيل أداة الفهرسة الفورية للخرائط...' : 'Initializing Dynamic Indexer ping flow...'}`,
      `[info] ${isAr ? 'مستقبل الطلب الأول: Google Search Engine Bot' : 'Target receptor 1: Google Search Engine Bot'}`,
      `[info] ${isAr ? 'مستقبل الطلب الثاني: Bing (Microsoft) Index Bot' : 'Target receptor 2: Bing (Microsoft) Index Bot'}`
    ]);

    try {
      // Small timeout to simulate progress and ensure logs look interactive
      await new Promise(resolve => setTimeout(resolve, 800));
      
      setPingLogs(prev => [...prev, `[connect] ${isAr ? 'الاتصال بخادم API المحلي لبدء الإرسال...' : 'Connecting to local API proxy routing...'}`]);
      
      const response = await fetch('/api/ping-sitemap', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        }
      });
      
      const data = await response.json();
      
      if (response.ok && data.success) {
        // Feed the backend logs into our terminal visually
        if (data.logs && Array.isArray(data.logs)) {
          let currentLogIndex = 0;
          const interval = setInterval(() => {
            if (currentLogIndex < data.logs.length) {
              setPingLogs(prev => [...prev, data.logs[currentLogIndex]]);
              currentLogIndex++;
            } else {
              clearInterval(interval);
              setPingerLoading(false);
              pushNotification(
                'deal',
                '🚀 تم تحديث الفهرسة وإعلام محركات البحث بنجاح!',
                '🚀 Sitemap successfully pinged to Google & Bing!'
              );
            }
          }, 400);
        } else {
          setPingLogs(prev => [...prev, `[success] ${isAr ? 'تم استلام رد إيجابي من الخادم بنجاح.' : 'Received generic success payload from server.'}`]);
          setPingerLoading(false);
        }
      } else {
        throw new Error(data.error || 'Server rejected ping payload');
      }
    } catch (err: any) {
      setPingLogs(prev => [
        ...prev, 
        `[error] ${isAr ? 'حدث خطأ أثناء إرسال الكرولر:' : 'Failed to contact engines:'} ${err.message}`,
        `[critical] ${isAr ? 'تم الإلغاء. يرجى مراجعة اتصال الشبكة والمحاولة لاحقاً.' : 'Aborted. Verify connection and retry.'}`
      ]);
      setPingerLoading(false);
      pushNotification(
        'coupon',
        '❌ فشل إرسال إشعار خريطة الموقع لمحركات البحث',
        '❌ Failed to send sitemap ping request'
      );
    }
  };

  // Compute calculated checklist progress bar
  const totalTasks = Object.keys(checklist).length;
  const completedTasks = Object.values(checklist).filter(Boolean).length;
  const progressPercent = Math.round((completedTasks / totalTasks) * 100);

  return (
    <div className="space-y-6 text-right animate-fadeIn" dir={isAr ? 'rtl' : 'ltr'}>
      
      {/* SECTION 1: Webmaster Tools Verification Codes */}
      <div className="bg-card p-4 rounded-2xl border border-border-main/70 space-y-4 shadow-xs">
        <div className="flex items-center gap-1.5 border-b border-border-main/50 pb-2 justify-start">
          <Settings size={15} className="text-primary" />
          <h4 className="text-[11px] font-black text-text-main">
            {isAr ? 'أدوات التحقق لـ Google Search Console & Bing' : 'Webmaster Tools Verification Tags'}
          </h4>
        </div>
        
        <p className="text-[10px] text-text-main opacity-70 leading-relaxed text-right">
          {isAr 
            ? 'لإثبات ملكيتك للموقع في لوحة تحكم جوجل وبينج، الصق كود التعريف (HTML Tag Code) هنا وسنقوم بحقنه تلقائياً في ترويسة الموقع لمساعدتك على مراقبة الكلمات والظهور.'
            : 'Validate ownership in Google Search Console and Bing Webmaster. Paste the content value from the HTML meta tag verification options here.'}
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {/* Google site verification input */}
          <div className="space-y-1">
            <label className="text-[10px] font-bold opacity-75 block text-right">
              {isAr ? 'كود إثبات ملكية جوجل (Google Verification Code)' : 'Google Site Verification Value'}
            </label>
            <div className="relative">
              <input
                type="text"
                value={googleVerificationCode}
                onChange={(e) => setGoogleVerificationCode(e.target.value)}
                placeholder='e.g. google1a2b3c4d5e6f7g8h'
                className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-bg focus:outline-none focus:border-primary text-text-main font-semibold font-mono text-left"
                dir="ltr"
              />
              {googleVerificationCode && (
                <div className="absolute right-2 top-2.5 flex items-center">
                  <CheckCircle size={14} className="text-emerald-500" />
                </div>
              )}
            </div>
            <p className="text-[9px] text-text-main/60 text-right leading-tight">
              {isAr ? 'احصل عليه من خيار "علامة HTML" في Google Search Console' : 'Obtained from HTML tag verification method in Google Search Console'}
            </p>
          </div>

          {/* Bing site verification input */}
          <div className="space-y-1">
            <label className="text-[10px] font-bold opacity-75 block text-right">
              {isAr ? 'كود إثبات ملكية بينج (Bing Webmaster Code)' : 'Bing Site Verification Value'}
            </label>
            <div className="relative">
              <input
                type="text"
                value={bingVerificationCode}
                onChange={(e) => setBingVerificationCode(e.target.value)}
                placeholder='e.g. 1234567890ABCDEF1234567890ABCDEF'
                className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-bg focus:outline-none focus:border-primary text-text-main font-semibold font-mono text-left"
                dir="ltr"
              />
              {bingVerificationCode && (
                <div className="absolute right-2 top-2.5 flex items-center">
                  <CheckCircle size={14} className="text-emerald-500" />
                </div>
              )}
            </div>
            <p className="text-[9px] text-text-main/60 text-right leading-tight">
              {isAr ? 'مستخرج من كود <meta name="msvalidate.01">' : 'Extracted from the msvalidate.01 meta tag content'}
            </p>
          </div>
        </div>
      </div>

      {/* SECTION 2: Dynamic Sitemap Pinger & Console */}
      <div className="bg-card p-4 rounded-2xl border border-border-main/70 space-y-4 shadow-xs">
        <div className="flex items-center justify-between border-b border-border-main/50 pb-2">
          <div className="flex items-center gap-1.5 justify-start">
            <Globe size={15} className="text-emerald-500" />
            <span className="text-[11px] font-black text-text-main">
              {isAr ? 'مُرسل خرائط الموقع الفوري لمحركات البحث / Sitemap Pinger' : 'Instant Search Engine Indexer'}
            </span>
          </div>
          <span className="text-[9px] px-2 py-0.5 bg-emerald-500/10 text-emerald-500 rounded-md font-bold uppercase tracking-wider">
            {isAr ? 'أرشفة حية فائقة' : 'Live Indexer'}
          </span>
        </div>

        <p className="text-[10px] text-text-main opacity-70 leading-relaxed text-right">
          {isAr
            ? 'عند قيامك بإضافة متاجر أو عروض جديدة، يمكنك إرغام زواحف جوجل وبينج على زيارة موقعك وتحديث الأرشفة فوراً بدلاً من الانتظار لأسابيع!'
            : 'Force Google & Bing bots to crawl your updated sitemap immediately instead of waiting for automatic indexing rounds.'}
        </p>

        <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center">
          <div className="flex-1 space-y-1 text-right">
            <div className="text-[10px] font-black text-emerald-500">
              {isAr ? 'رابط خريطة السيو الخاصة بموقعك:' : 'Your target Sitemap url:'}
            </div>
            <div className="bg-bg border border-border-main rounded-xl p-2.5 font-mono text-xs text-text-main flex items-center justify-between group">
              <span className="truncate max-w-[280px] font-semibold text-primary">
                {typeof window !== 'undefined' ? `${window.location.origin}/sitemap.xml` : 'https://wafeer.ai.studio/sitemap.xml'}
              </span>
              <button
                type="button"
                onClick={() => {
                  const url = typeof window !== 'undefined' ? `${window.location.origin}/sitemap.xml` : 'https://wafeer.ai.studio/sitemap.xml';
                  navigator.clipboard.writeText(url);
                  pushNotification(
                    'deal',
                    '📋 تم نسخ رابط خريطة sitemap.xml بنجاح!',
                    '📋 sitemap.xml URL copied to clipboard!'
                  );
                }}
                className="text-[9px] text-primary hover:underline cursor-pointer flex items-center gap-0.5 font-bold"
              >
                <Clipboard size={12} />
                <span>{isAr ? 'نسخ الرابط' : 'Copy'}</span>
              </button>
            </div>
          </div>

          <div className="flex items-end justify-center pt-2 md:pt-0">
            <button
              type="button"
              disabled={pingerLoading}
              onClick={handlePingSitemap}
              className={`w-full md:w-auto bg-emerald-500 hover:bg-emerald-600 text-white font-black px-6 py-3.5 rounded-xl text-xs transition cursor-pointer flex items-center justify-center gap-1.5 shadow-sm ${pingerLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              {pingerLoading ? (
                <>
                  <RefreshCw size={14} className="animate-spin" />
                  <span>{isAr ? 'جاري إرسال الإشعار...' : 'Pinging Engines...'}</span>
                </>
              ) : (
                <>
                  <Send size={14} />
                  <span>{isAr ? 'تحديث الفهرسة الفورية (Ping)' : 'Request Instant Re-Indexing'}</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Dynamic Terminal Logs Console */}
        {pingLogs.length > 0 && (
          <div className="space-y-1 animate-slideDown">
            <div className="flex items-center justify-between text-[9px] font-black opacity-65">
              <span>{isAr ? 'شاشة مراقبة الاتصال الفوري بالكرولرز:' : 'Live crawler connection logs:'}</span>
              <button 
                type="button" 
                onClick={() => setPingLogs([])} 
                className="text-red-500 hover:underline cursor-pointer"
              >
                {isAr ? 'تفريغ السجل' : 'Clear Terminal'}
              </button>
            </div>
            <div className="bg-slate-950 text-emerald-400 p-3.5 rounded-xl font-mono text-[10px] h-36 overflow-y-auto leading-relaxed text-left scrollbar-thin select-text" dir="ltr">
              {pingLogs.map((log, idx) => {
                let colorClass = 'text-emerald-400';
                if (log.includes('[error]') || log.includes('[critical]')) colorClass = 'text-red-400 font-bold';
                else if (log.includes('[warning]')) colorClass = 'text-amber-300';
                else if (log.includes('[success]')) colorClass = 'text-cyan-300 font-black';
                else if (log.includes('[connect]')) colorClass = 'text-blue-300';
                
                return (
                  <div key={idx} className={`${colorClass} mb-1 border-b border-white/5 pb-0.5`}>
                    {log}
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* SECTION 3: Google Rich Snippet Search Result Simulator */}
      <div className="bg-card p-4 rounded-2xl border border-border-main/70 space-y-4 shadow-xs">
        <div className="flex items-center gap-1.5 border-b border-border-main/50 pb-2 justify-start">
          <Search size={15} className="text-blue-500" />
          <h4 className="text-[11px] font-black text-text-main">
            {isAr ? 'محاكي مظهر النتيجة الأولى في جوجل (Rich Snippets Simulator)' : 'Google Rich Snippets Result Simulator'}
          </h4>
        </div>

        <p className="text-[10px] text-text-main opacity-70 leading-relaxed text-right">
          {isAr
            ? 'شاهد كيف سيظهر موقعك كخيار أول للمستخدمين عند البحث في جوجل. نقوم بحقن Schema JSON-LD الذكية ليظهر تقييم النجوم ⭐ والروابط مباشرة لزيادة نسبة النقر (CTR).'
            : 'Visualize how your coupons platform and exclusive discount code schema structure will display to users in live Google search results.'}
        </p>

        {/* The Google Card Simulator */}
        <div className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-border-main/60 max-w-xl mx-auto shadow-xs text-left" dir="ltr">
          <div className="space-y-1.5">
            {/* Site header and breadcrumb */}
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-amber-100 rounded-full flex items-center justify-center text-xs">
                💰
              </div>
              <div className="flex flex-col text-left">
                <span className="text-[11px] font-sans font-medium text-slate-900 dark:text-slate-100 leading-tight">
                  {isAr ? 'وفير' : 'Wafeer'}
                </span>
                <span className="text-[9px] font-sans text-slate-500 dark:text-slate-400 leading-none">
                  https://wafeer.ai.studio
                </span>
              </div>
            </div>

            {/* Google Search Result Title */}
            <h3 className="text-[#1a0dab] dark:text-[#8ab4f8] font-sans hover:underline text-[16px] md:text-[18px] font-normal leading-tight cursor-pointer">
              {isAr ? seoTitleAr : seoTitleEn}
            </h3>

            {/* Rich Snippets Schema Star Rating */}
            <div className="flex items-center gap-1.5 text-[11px] font-sans text-slate-500 dark:text-slate-400">
              <div className="flex items-center gap-0.5 text-amber-500">
                <span>★</span><span>★</span><span>★</span><span>★</span><span>★</span>
              </div>
              <span>
                <strong>4.9</strong> ({isAr ? '14,285 تصويت' : '14,285 reviews'}) - {isAr ? 'مجاني بالكامل' : '100% Free Coupons'}
              </span>
            </div>

            {/* Google Snippet Description */}
            <p className="text-[#4d5156] dark:text-[#bdc1c6] font-sans text-[12px] md:text-[13px] leading-relaxed">
              {isAr ? seoDescAr : seoDescEn}
            </p>

            {/* Mock Google search sitelink links */}
            <div className="grid grid-cols-2 gap-x-4 gap-y-1 pt-1.5 text-[11px] font-sans text-[#1a0dab] dark:text-[#8ab4f8] border-t border-slate-100 dark:border-slate-800">
              <div className="hover:underline cursor-pointer">
                {isAr ? '🏷️ كود خصم نون 2026' : '🏷️ Noon Coupon Code'}
              </div>
              <div className="hover:underline cursor-pointer">
                {isAr ? '🔥 مقالات التسوق الموفر' : '🔥 Saving Blog'}
              </div>
              <div className="hover:underline cursor-pointer">
                {isAr ? '📞 اتصل بنا - وفير' : '📞 Contact Us'}
              </div>
              <div className="hover:underline cursor-pointer">
                {isAr ? 'ℹ️ من نحن' : 'ℹ️ About Us'}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* SECTION 4: Gold Indexing Checklist to rank #1 */}
      <div className="bg-card p-4 rounded-2xl border border-border-main/70 space-y-4 shadow-xs">
        <div className="flex items-center justify-between border-b border-border-main/50 pb-2">
          <div className="flex items-center gap-1.5 justify-start">
            <Award size={15} className="text-indigo-500" />
            <span className="text-[11px] font-black text-text-main">
              {isAr ? 'دليل الأرشفة الذهبي للوصول للترتيب الأول (SEO Gold Checklist)' : 'Gold-Standard SEO & Indexing Checklist'}
            </span>
          </div>
          <span className="text-[9px] text-text-main opacity-70">
            {isAr ? 'مستشارك الشخصي للأرشفة الصاروخية' : 'Your live task companion for rank #1'}
          </span>
        </div>

        {/* Progress Bar indicator */}
        <div className="space-y-1 bg-indigo-500/5 p-3 rounded-xl border border-indigo-500/10">
          <div className="flex items-center justify-between text-[10px]">
            <span className="font-bold text-indigo-600 dark:text-indigo-400">
              {isAr ? 'معدل جاهزية الموقع لتصدر محركات البحث:' : 'SEO Readiness Index:'}
            </span>
            <span className="font-black text-indigo-600 dark:text-indigo-400">{progressPercent}%</span>
          </div>
          <div className="w-full bg-border-main h-2 rounded-full overflow-hidden">
            <div 
              className="h-full bg-indigo-500 rounded-full transition-all duration-500"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
          <p className="text-[9px] text-text-main/75 text-right mt-1 leading-tight">
            {progressPercent === 100 
              ? (isAr ? '🎉 مبروك! موقعك جاهز بنسبة 100% للتصدر والتفوق على المنافسين!' : '🎉 Congratulations! Your site has met all the premium ranking requirements!')
              : (isAr ? '💡 أكمل المهام المتبقية بالأسفل لتقوية حضورك وظهورك في الصفحة الأولى.' : '💡 Complete the pending list tasks below to guarantee top indexing efficiency.')}
          </p>
        </div>

        {/* Interactive Checklist List */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
          {/* Item 1 */}
          <div 
            onClick={() => toggleChecklistItem('gsc')}
            className={`p-3 rounded-xl border transition cursor-pointer flex gap-2.5 items-start text-right ${checklist.gsc ? 'bg-indigo-500/5 border-indigo-500/20' : 'bg-bg/40 border-border-main hover:border-indigo-500/40'}`}
          >
            <input 
              type="checkbox" 
              checked={checklist.gsc}
              onChange={() => {}} // toggled on card click
              className="accent-indigo-500 mt-1 cursor-pointer"
            />
            <div className="space-y-0.5">
              <span className={`text-[11px] font-black block ${checklist.gsc ? 'line-through opacity-70' : 'text-text-main'}`}>
                {isAr ? 'ربط الموقع بـ Google Search Console' : 'Register with Google Search Console'}
              </span>
              <p className="text-[9px] text-text-main opacity-70 leading-relaxed">
                {isAr ? 'قم بالتسجيل في جوجل وضع كود التحقق في المربع بالأعلى لإثبات الملكية.' : 'Paste verification tag above to start receiving index impressions.'}
              </p>
            </div>
          </div>

          {/* Item 2 */}
          <div 
            onClick={() => toggleChecklistItem('sitemap_submit')}
            className={`p-3 rounded-xl border transition cursor-pointer flex gap-2.5 items-start text-right ${checklist.sitemap_submit ? 'bg-indigo-500/5 border-indigo-500/20' : 'bg-bg/40 border-border-main hover:border-indigo-500/40'}`}
          >
            <input 
              type="checkbox" 
              checked={checklist.sitemap_submit}
              onChange={() => {}}
              className="accent-indigo-500 mt-1 cursor-pointer"
            />
            <div className="space-y-0.5">
              <span className={`text-[11px] font-black block ${checklist.sitemap_submit ? 'line-through opacity-70' : 'text-text-main'}`}>
                {isAr ? 'تقديم ملف خريطة الموقع sitemap.xml' : 'Submit sitemap.xml to Google'}
              </span>
              <p className="text-[9px] text-text-main opacity-70 leading-relaxed">
                {isAr ? 'احصل على رابط الخريطة وحمله لجوجل، ثم اضغط (Ping) بالأعلى لتنبيه الزواحف.' : 'Submit the sitemap link and trigger the Instant index ping from above.'}
              </p>
            </div>
          </div>

          {/* Item 3 */}
          <div 
            onClick={() => toggleChecklistItem('keywords')}
            className={`p-3 rounded-xl border transition cursor-pointer flex gap-2.5 items-start text-right ${checklist.keywords ? 'bg-indigo-500/5 border-indigo-500/20' : 'bg-bg/40 border-border-main hover:border-indigo-500/40'}`}
          >
            <input 
              type="checkbox" 
              checked={checklist.keywords}
              onChange={() => {}}
              className="accent-indigo-500 mt-1 cursor-pointer"
            />
            <div className="space-y-0.5">
              <span className={`text-[11px] font-black block ${checklist.keywords ? 'line-through opacity-70' : 'text-text-main'}`}>
                {isAr ? 'مراجعة وتعديل الكلمات الدلالية بالمحلل' : 'Review Keyword Density with Analyzer'}
              </span>
              <p className="text-[9px] text-text-main opacity-70 leading-relaxed">
                {isAr ? 'تأكد أن كثافة عبارتك المفتاحية (مثل كود خصم) تقع بنسبة مثالية (1%-3%) في المحلل.' : 'Use our smart density checker below to optimize your core coupon terms.'}
              </p>
            </div>
          </div>

          {/* Item 4 */}
          <div 
            onClick={() => toggleChecklistItem('freshness')}
            className={`p-3 rounded-xl border transition cursor-pointer flex gap-2.5 items-start text-right ${checklist.freshness ? 'bg-indigo-500/5 border-indigo-500/20' : 'bg-bg/40 border-border-main hover:border-indigo-500/40'}`}
          >
            <input 
              type="checkbox" 
              checked={checklist.freshness}
              onChange={() => {}}
              className="accent-indigo-500 mt-1 cursor-pointer"
            />
            <div className="space-y-0.5">
              <span className={`text-[11px] font-black block ${checklist.freshness ? 'line-through opacity-70' : 'text-text-main'}`}>
                {isAr ? 'تحديث الكوبونات وإضافة عروض حصرية' : 'Freshness: Keep Coupons Updated'}
              </span>
              <p className="text-[9px] text-text-main opacity-70 leading-relaxed">
                {isAr ? 'المحتوى المتجدد يرسل إشارات إيجابية قوية لمحركات البحث لتكرار زيارة موقعك بشكل دوري.' : 'Add and modify active stores routinely to maintain higher search ranking.'}
              </p>
            </div>
          </div>

          {/* Item 5 */}
          <div 
            onClick={() => toggleChecklistItem('internal_links')}
            className={`p-3 rounded-xl border transition cursor-pointer flex gap-2.5 items-start text-right ${checklist.internal_links ? 'bg-indigo-500/5 border-indigo-500/20' : 'bg-bg/40 border-border-main hover:border-indigo-500/40'}`}
          >
            <input 
              type="checkbox" 
              checked={checklist.internal_links}
              onChange={() => {}}
              className="accent-indigo-500 mt-1 cursor-pointer"
            />
            <div className="space-y-0.5">
              <span className={`text-[11px] font-black block ${checklist.internal_links ? 'line-through opacity-70' : 'text-text-main'}`}>
                {isAr ? 'ربط المتاجر الذكية والمقالات ببعضها' : 'Leverage Smart Internal Linking'}
              </span>
              <p className="text-[9px] text-text-main opacity-70 leading-relaxed">
                {isAr ? 'أضف روابط داخل المتاجر والمقالات لتوجيه المستخدمين وتحسين تدفق الـ PageRank.' : 'Interlink active stores and smart shopping articles to boost page authority.'}
              </p>
            </div>
          </div>

          {/* Pre-verified Mobile-Friendly check (Item 6) */}
          <div className="p-3 rounded-xl border border-emerald-500/10 bg-emerald-500/5 flex gap-2.5 items-start text-right">
            <CheckCircle size={15} className="text-emerald-500 mt-0.5 flex-shrink-0" />
            <div className="space-y-0.5">
              <span className="text-[11px] font-black text-emerald-500 block">
                {isAr ? 'تصميم متوافق مع الهواتف 100% (Mobile First)' : 'Fully Responsive & Mobile-First'}
              </span>
              <p className="text-[9px] text-emerald-500/80 leading-relaxed">
                {isAr ? 'تحقق كامل: الكود ممتثل تماماً ومبني لدعم جميع أحجام الشاشات لضمان معايير أرشفة الهاتف.' : 'Success: Built with responsive grids that pass Google Mobile-Friendly parameters.'}
              </p>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
}
