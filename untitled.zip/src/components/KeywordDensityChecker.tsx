import React, { useState, useMemo } from 'react';
import { 
  FileText, 
  CheckCircle, 
  AlertTriangle, 
  Search, 
  Plus, 
  X, 
  RotateCcw, 
  Sparkles, 
  TrendingUp, 
  Layers, 
  Info,
  HelpCircle,
  ArrowRight
} from 'lucide-react';

interface KeywordDensityCheckerProps {
  lang: 'ar' | 'en';
  stores: any[];
  articles: any[];
  benefits?: any[];
  seoTitleAr: string;
  seoTitleEn: string;
  seoDescAr: string;
  seoDescEn: string;
  seoKeywordsAr: string;
  seoKeywordsEn: string;
  heroSlides?: any[];
}

export default function KeywordDensityChecker({
  lang,
  stores,
  articles,
  benefits = [],
  seoTitleAr,
  seoTitleEn,
  seoDescAr,
  seoDescEn,
  seoKeywordsAr,
  seoKeywordsEn,
  heroSlides = []
}: KeywordDensityCheckerProps) {
  const [analysisSource, setAnalysisSource] = useState<'all' | 'stores' | 'articles' | 'custom'>('all');
  const [customText, setCustomText] = useState('');
  const [filterStopWords, setFilterStopWords] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [newTargetKeyword, setNewTargetKeyword] = useState('');
  const [targetKeywords, setTargetKeywords] = useState<string[]>(() => {
    // Default regional target keywords
    return lang === 'ar' 
      ? ['كود خصم', 'كوبون', 'تخفيض', 'خصم نون', 'شحن مجاني']
      : ['coupon code', 'discount', 'promo', 'free shipping', 'exclusive'];
  });

  // Arabic and English common stop words
  const arabicStopWords = useMemo(() => new Set([
    'في', 'من', 'على', 'إلى', 'عن', 'مع', 'هذا', 'هذه', 'أو', 'ثم', 'ان', 'أن', 'لا', 'ما', 'لم', 'لن', 
    'كل', 'بعد', 'قبل', 'عند', 'بين', 'تحت', 'فوق', 'هو', 'هي', 'هم', 'هن', 'التي', 'الذي', 'الذين', 
    'ب', 'ل', 'و', 'يا', 'كان', 'كانت', 'إن', 'أنه', 'لكن', 'غير', 'إذا', 'هناك', 'هؤلاء', 'ذلك', 'تلك',
    'قد', 'لقد', 'تم', 'تمت', 'حيث', 'كيف', 'لماذا', 'ام', 'أم', 'سوف', 'بينما', 'حتى', 'معكم', 'لك', 'لكم'
  ]), []);

  const englishStopWords = useMemo(() => new Set([
    'the', 'and', 'of', 'to', 'in', 'a', 'is', 'that', 'it', 'on', 'for', 'with', 'as', 'at', 'by', 'an', 
    'be', 'this', 'are', 'from', 'or', 'you', 'your', 'i', 'we', 'they', 'our', 'us', 'me', 'it', 'its', 
    'he', 'she', 'his', 'her', 'has', 'have', 'had', 'do', 'does', 'did', 'but', 'not', 'no', 'all', 'any'
  ]), []);

  // Dynamically compile text body based on the source
  const compiledText = useMemo(() => {
    if (analysisSource === 'custom') {
      return customText;
    }

    let parts: string[] = [];

    // Add SEO Meta Details if analyzing whole homepage
    if (analysisSource === 'all') {
      parts.push(seoTitleAr);
      parts.push(seoTitleEn);
      parts.push(seoDescAr);
      parts.push(seoDescEn);
      parts.push(seoKeywordsAr);
      parts.push(seoKeywordsEn);

      // Add Hero Slider content
      heroSlides.forEach(slide => {
        parts.push(slide.titleAr || '');
        parts.push(slide.titleEn || '');
        parts.push(slide.subAr || '');
        parts.push(slide.subEn || '');
      });

      // Add Benefit Tabs
      benefits.forEach(b => {
        parts.push(b.titleAr || b.title || '');
        parts.push(b.textAr || b.text || '');
      });
    }

    // Add Stores content
    if (analysisSource === 'all' || analysisSource === 'stores') {
      stores.forEach(store => {
        parts.push(store.name || '');
        parts.push(store.nameAr || '');
        parts.push(store.discount || '');
        parts.push(store.code || '');
        parts.push(store.category || '');
      });
    }

    // Add Blog / Articles content
    if (analysisSource === 'all' || analysisSource === 'articles') {
      articles.forEach(art => {
        parts.push(art.title || '');
        parts.push(art.titleEn || '');
        parts.push(art.text || '');
        parts.push(art.discountText || '');
        parts.push(art.customStoreName || '');
      });
    }

    return parts.join(' ');
  }, [analysisSource, customText, stores, articles, benefits, seoTitleAr, seoTitleEn, seoDescAr, seoDescEn, seoKeywordsAr, seoKeywordsEn, heroSlides]);

  // Clean and parse text into words list
  const wordsList = useMemo(() => {
    if (!compiledText.trim()) return [];

    // Replace common symbols, tags, numbers, and punctuation with spaces
    const cleanText = compiledText
      .toLowerCase()
      .replace(/[0-9]/g, ' ')
      .replace(/[.,\/#!$%\^&\*;:{}=\-_`~()?"'<>Arabic|]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    // Split on whitespace
    return cleanText.split(/\s+/).filter(w => w.length > 1);
  }, [compiledText]);

  // Total word count after initial tokenization
  const totalWordsCount = wordsList.length;

  // Compute standard single-word frequencies and densities
  const keywordStats = useMemo(() => {
    if (wordsList.length === 0) return [];

    const freqMap: Record<string, number> = {};
    wordsList.forEach(word => {
      // Filter out stop words if enabled
      if (filterStopWords) {
        if (arabicStopWords.has(word) || englishStopWords.has(word)) return;
      }
      freqMap[word] = (freqMap[word] || 0) + 1;
    });

    const stats = Object.entries(freqMap).map(([word, count]) => {
      const density = (count / totalWordsCount) * 100;
      return { word, count, density };
    });

    // Sort by count descending
    return stats.sort((a, b) => b.count - a.count);
  }, [wordsList, filterStopWords, arabicStopWords, englishStopWords, totalWordsCount]);

  // Target phrase analyzer (supports multi-word target phrases)
  const targetPhraseAnalysis = useMemo(() => {
    if (!compiledText.trim()) return [];

    const textLower = compiledText.toLowerCase();

    return targetKeywords.map(phrase => {
      const phraseLower = phrase.toLowerCase().trim();
      if (!phraseLower) return { phrase, count: 0, density: 0 };

      // Escape regex special chars
      const escaped = phraseLower.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
      
      // Count non-overlapping occurrences
      let count = 0;
      try {
        const regex = new RegExp(escaped, 'g');
        const matches = textLower.match(regex);
        count = matches ? matches.length : 0;
      } catch (e) {
        // Fallback simple indexOf search if Regex fails
        let pos = textLower.indexOf(phraseLower);
        while (pos !== -1) {
          count++;
          pos = textLower.indexOf(phraseLower, pos + phraseLower.length);
        }
      }

      // Density is based on number of words in the phrase relative to total words
      const phraseWordCount = phraseLower.split(/\s+/).length;
      const occurrencesWords = count * phraseWordCount;
      const density = totalWordsCount > 0 ? (occurrencesWords / totalWordsCount) * 100 : 0;

      return {
        phrase,
        count,
        density,
        wordCount: phraseWordCount
      };
    });
  }, [compiledText, targetKeywords, totalWordsCount]);

  // Handler to add a target keyword
  const handleAddTarget = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = newTargetKeyword.trim();
    if (clean && !targetKeywords.includes(clean)) {
      setTargetKeywords([...targetKeywords, clean]);
      setNewTargetKeyword('');
    }
  };

  // Handler to remove a target keyword
  const handleRemoveTarget = (keyword: string) => {
    setTargetKeywords(targetKeywords.filter(k => k !== keyword));
  };

  // Live filter for word list
  const filteredKeywordStats = useMemo(() => {
    if (!searchTerm.trim()) return keywordStats.slice(0, 50); // limit to top 50 for performance
    return keywordStats.filter(stat => stat.word.includes(searchTerm.toLowerCase()));
  }, [keywordStats, searchTerm]);

  // Evaluate Density levels and provide corresponding labels / status
  const getDensityStatus = (density: number) => {
    if (density === 0) {
      return {
        color: 'text-slate-400 bg-slate-100 dark:bg-slate-800/50',
        labelAr: 'مفقود / غائب',
        labelEn: 'Missing',
        type: 'missing',
        tipAr: 'لم يتم ذكر هذه الكلمة في نصوص موقعك! من الأفضل إدراجها لتحسين الفهرسة.',
        tipEn: 'This keyword is not mentioned. Try incorporating it naturally in headers or descriptions.'
      };
    }
    if (density < 1.0) {
      return {
        color: 'text-amber-500 bg-amber-500/10 border-amber-500/20',
        labelAr: 'قليلة جداً',
        labelEn: 'Under-optimized',
        type: 'low',
        tipAr: 'الكثافة منخفضة (أقل من 1%). حاول تكرار الكلمة في عناوين المتاجر أو المقالات.',
        tipEn: 'Density is below 1%. Consider using it in headings or bold store tags to signal relevance.'
      };
    }
    if (density <= 3.5) {
      return {
        color: 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20',
        labelAr: 'ممتازة ومثالية ✨',
        labelEn: 'Optimal ✨',
        type: 'optimal',
        tipAr: 'كثافة مثالية جداً (1% - 3.5%). تمنح محركات البحث إشارة واضحة وموثوقة دون حشو.',
        tipEn: 'Perfect SEO density (1% - 3.5%). Google prefers this balanced density for modern search intent.'
      };
    }
    if (density <= 5.0) {
      return {
        color: 'text-orange-500 bg-orange-500/10 border-orange-500/20',
        labelAr: 'مرتفعة قليلاً',
        labelEn: 'Slightly High',
        type: 'high',
        tipAr: 'الكثافة تتجاوز الحد المفضل. احذر من زيادة تكرارها لتجنب خوارزميات مكافحة السبام.',
        tipEn: 'A bit high (3.5% - 5%). Keep an eye on it to make sure it reads naturally for visitors.'
      };
    }
    return {
      color: 'text-red-500 bg-red-500/10 border-red-500/20',
      labelAr: 'حشو مفرط خطر! ⚠️',
      labelEn: 'Keyword Stuffing! ⚠️',
      type: 'stuffing',
      tipAr: 'تنبيه عاجل! الكلمة مكررة بكثافة مزعجة (>5%). قم باستبدال بعض المرات بمرادفات لتجنب عقوبات جوجل.',
      tipEn: 'Warning: Stuffing detected (>5%). Replace some occurrences with synonyms or general phrases.'
    };
  };

  // General SEO optimization health score based on target keywords
  const keywordHealthScore = useMemo(() => {
    if (targetPhraseAnalysis.length === 0) return 100;
    let score = 100;
    targetPhraseAnalysis.forEach(item => {
      if (item.density === 0) score -= 12; // Missing is bad
      else if (item.density < 1.0) score -= 5; // Low optimization
      else if (item.density > 5.0) score -= 15; // Stuffing is worst for ranking
      else if (item.density > 3.5) score -= 4; // High is slightly risky
    });
    return Math.max(20, score);
  }, [targetPhraseAnalysis]);

  return (
    <div className="space-y-4 text-right animate-fadeIn" dir="rtl">
      
      {/* Alert Header */}
      <div className="p-4 bg-gradient-to-r from-emerald-500/10 to-blue-500/10 border border-emerald-500/20 rounded-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1 text-right">
          <div className="flex items-center gap-2 justify-start">
            <span className="p-1.5 bg-emerald-500 text-white rounded-lg">
              <TrendingUp size={16} />
            </span>
            <h4 className="text-sm font-black text-emerald-500">
              {lang === 'ar' ? 'محلل كثافة الكلمات الدلالية الذكي / Keyword Density Analyzer' : 'Live Keyword Density Analyzer'}
            </h4>
          </div>
          <p className="text-[11px] text-text-main opacity-80 leading-relaxed">
            {lang === 'ar' 
              ? 'أداة فورية لحساب نسبة تكرار الكلمات الدلالية في نصوص موقعك والتأكد من توافقها مع خوارزميات محركات البحث (سيو) وتجنب الحشو العشوائي.'
              : 'Analyze the frequency of words in your content. Keep your core keywords within the optimal 1% - 3.5% range to rank higher on Google.'}
          </p>
        </div>

        {/* Health Score Shield */}
        <div className="flex items-center gap-3 bg-card px-4 py-2.5 rounded-xl border border-border-main self-stretch md:self-auto justify-between shadow-xs">
          <div className="text-right">
            <div className="text-[9px] font-bold opacity-60 uppercase">{lang === 'ar' ? 'مؤشر صحة الكلمات' : 'Keyword SEO Score'}</div>
            <div className="text-xs font-black text-text-main mt-0.5">
              {keywordHealthScore >= 80 
                ? (lang === 'ar' ? 'ممتاز ومتوازن' : 'Excellent & Balanced')
                : keywordHealthScore >= 50 
                ? (lang === 'ar' ? 'مقبول وبحاجة لتنظيم' : 'Acceptable, Needs Tuning')
                : (lang === 'ar' ? 'مجهد للزحف - حشو أو غياب!' : 'Poor - Stuffing or Missing!')}
            </div>
          </div>
          <div className={`w-11 h-11 rounded-full flex items-center justify-center font-black text-sm border-2 ${
            keywordHealthScore >= 80 
              ? 'border-emerald-500 text-emerald-500 bg-emerald-500/10' 
              : keywordHealthScore >= 50 
              ? 'border-amber-500 text-amber-500 bg-amber-500/10' 
              : 'border-red-500 text-red-500 bg-red-500/10'
          }`}>
            {keywordHealthScore}%
          </div>
        </div>
      </div>

      {/* Control Tabs for Sources */}
      <div className="grid grid-cols-4 gap-2 bg-bg/50 p-1 rounded-xl border border-border-main">
        <button
          type="button"
          onClick={() => setAnalysisSource('all')}
          className={`py-2 px-1.5 rounded-lg text-[10px] font-black transition-all cursor-pointer flex flex-col items-center gap-1 ${analysisSource === 'all' ? 'bg-primary text-white shadow' : 'text-text-main opacity-70 hover:opacity-100'}`}
        >
          <Layers size={12} />
          <span>{lang === 'ar' ? 'كامل الصفحة' : 'Whole Page'}</span>
        </button>
        <button
          type="button"
          onClick={() => setAnalysisSource('stores')}
          className={`py-2 px-1.5 rounded-lg text-[10px] font-black transition-all cursor-pointer flex flex-col items-center gap-1 ${analysisSource === 'stores' ? 'bg-primary text-white shadow' : 'text-text-main opacity-70 hover:opacity-100'}`}
        >
          <CheckCircle size={12} />
          <span>{lang === 'ar' ? 'المتاجر فقط' : 'Stores Only'}</span>
        </button>
        <button
          type="button"
          onClick={() => setAnalysisSource('articles')}
          className={`py-2 px-1.5 rounded-lg text-[10px] font-black transition-all cursor-pointer flex flex-col items-center gap-1 ${analysisSource === 'articles' ? 'bg-primary text-white shadow' : 'text-text-main opacity-70 hover:opacity-100'}`}
        >
          <FileText size={12} />
          <span>{lang === 'ar' ? 'المقالات فقط' : 'Articles Only'}</span>
        </button>
        <button
          type="button"
          onClick={() => setAnalysisSource('custom')}
          className={`py-2 px-1.5 rounded-lg text-[10px] font-black transition-all cursor-pointer flex flex-col items-center gap-1 ${analysisSource === 'custom' ? 'bg-primary text-white shadow' : 'text-text-main opacity-70 hover:opacity-100'}`}
        >
          <Sparkles size={12} />
          <span>{lang === 'ar' ? 'نص مخصص' : 'Custom Text'}</span>
        </button>
      </div>

      {/* Custom Text Area if source is custom */}
      {analysisSource === 'custom' && (
        <div className="space-y-1 animate-slideDown">
          <div className="flex justify-between items-center">
            <label className="text-[10px] font-bold opacity-70">{lang === 'ar' ? 'أدخل أو ألصق النص المراد تحليله:' : 'Paste text to analyze:'}</label>
            <button 
              type="button"
              onClick={() => setCustomText('')}
              className="text-[9px] text-red-500 hover:underline flex items-center gap-0.5 cursor-pointer"
            >
              <RotateCcw size={10} />
              <span>{lang === 'ar' ? 'مسح النص' : 'Clear Text'}</span>
            </button>
          </div>
          <textarea
            value={customText}
            onChange={(e) => setCustomText(e.target.value)}
            placeholder={lang === 'ar' ? 'ألصق مقالات السيو أو المحتوى التسويقي هنا للتدقيق الفوري...' : 'Paste copy, store catalogs or discount articles here to evaluate word counts...'}
            rows={4}
            className="w-full text-xs p-2.5 rounded-lg border border-border-main bg-card focus:outline-none focus:border-emerald-500 text-text-main leading-relaxed"
          />
        </div>
      )}

      {/* Total Words Counter Info Banner */}
      <div className="flex items-center justify-between text-[10px] bg-bg p-2 rounded-xl border border-border-main">
        <span className="opacity-70 font-semibold">
          {lang === 'ar' ? 'المصدر المحدد حالياً:' : 'Current source:'} {' '}
          <strong className="text-primary font-black">
            {analysisSource === 'all' && (lang === 'ar' ? 'كامل الصفحة والمتاجر والمقالات والبنرات' : 'Entire Homepage & Meta')}
            {analysisSource === 'stores' && (lang === 'ar' ? 'كافة بيانات المتاجر المضافة' : 'All Added Stores & Coupons')}
            {analysisSource === 'articles' && (lang === 'ar' ? 'كافة نصوص المقالات الطويلة' : 'All Long Blog Articles')}
            {analysisSource === 'custom' && (lang === 'ar' ? 'النص المخصص المكتوب يدوياً' : 'Manual Custom Content Area')}
          </strong>
        </span>
        <span className="font-bold">
          {lang === 'ar' ? 'إجمالي الكلمات الدلالية المقروءة:' : 'Total valid words parsed:'} {' '}
          <span className="bg-emerald-500 text-white px-2 py-0.5 rounded-full text-[9px]">{totalWordsCount}</span>
        </span>
      </div>

      {/* Section 1: Monitored Core Target Keywords (Interactive Dashboard) */}
      <div className="space-y-2 bg-card p-4 rounded-2xl border border-border-main/75 shadow-xs">
        <div className="flex items-center justify-between border-b border-border-main/50 pb-2">
          <div className="flex items-center gap-1.5">
            <TrendingUp size={14} className="text-primary" />
            <span className="text-[11px] font-black text-text-main">
              {lang === 'ar' ? 'مراقبة الكلمات الدلالية المستهدفة / Track Target Keywords' : 'Track Target Keywords'}
            </span>
          </div>
          <span className="text-[9px] opacity-60">
            {lang === 'ar' ? 'تتبع نسبة دمج عبارتك المفتاحية بدقة' : 'Track exact search queries in your text'}
          </span>
        </div>

        {/* Input to add a new tracked target keyword */}
        <form onSubmit={handleAddTarget} className="flex gap-2">
          <input
            type="text"
            value={newTargetKeyword}
            onChange={(e) => setNewTargetKeyword(e.target.value)}
            placeholder={lang === 'ar' ? 'أضف عبارة دلالية جديدة لتتبعها... (مثال: كود خصم نون)' : 'Add keyword or phrase... (e.g. promo code)'}
            className="flex-1 text-xs p-2 rounded-lg border border-border-main bg-bg focus:outline-none focus:border-primary text-text-main"
          />
          <button
            type="submit"
            className="bg-primary hover:bg-primary-hover text-white text-[10px] font-bold px-3 py-2 rounded-lg flex items-center gap-1 transition cursor-pointer"
          >
            <Plus size={12} />
            <span>{lang === 'ar' ? 'إضافة للتتبع' : 'Track'}</span>
          </button>
        </form>

        {/* Dynamic target phrase analysis grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 pt-2">
          {targetPhraseAnalysis.length === 0 ? (
            <div className="col-span-2 text-center py-4 text-[10px] opacity-60">
              {lang === 'ar' ? 'لا توجد كلمات تتبع مضافة حالياً.' : 'No keywords tracked yet.'}
            </div>
          ) : (
            targetPhraseAnalysis.map((item, idx) => {
              const status = getDensityStatus(item.density);
              return (
                <div key={idx} className="p-3 bg-bg/50 border border-border-main rounded-xl flex flex-col justify-between space-y-2 animate-fadeIn relative overflow-hidden group">
                  <div className="flex items-start justify-between">
                    <div className="space-y-0.5">
                      <span className="text-xs font-black text-text-main">{item.phrase}</span>
                      <div className="flex items-center gap-1 text-[9px] font-semibold opacity-60">
                        <span>{lang === 'ar' ? 'تكرار:' : 'Mentions:'} <strong className="text-text-main">{item.count}</strong> {lang === 'ar' ? 'مرات' : 'times'}</span>
                        <span>•</span>
                        <span>{lang === 'ar' ? 'طول العبارة:' : 'Length:'} <strong className="text-text-main">{item.wordCount}</strong> {lang === 'ar' ? 'كلمات' : 'words'}</span>
                      </div>
                    </div>
                    
                    <button
                      type="button"
                      onClick={() => handleRemoveTarget(item.phrase)}
                      className="text-text-main/40 hover:text-red-500 p-0.5 rounded transition cursor-pointer"
                      title={lang === 'ar' ? 'إلغاء التتبع' : 'Untrack'}
                    >
                      <X size={12} />
                    </button>
                  </div>

                  {/* Meter / Progress Bar */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="opacity-80">{lang === 'ar' ? 'الكثافة الحالية:' : 'Density:'}</span>
                      <span className="font-mono font-black text-primary">{item.density.toFixed(2)}%</span>
                    </div>
                    <div className="w-full bg-border-main h-1.5 rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full transition-all duration-500 ${
                          status.type === 'missing' ? 'w-0' :
                          status.type === 'low' ? 'bg-amber-400' :
                          status.type === 'optimal' ? 'bg-emerald-500' :
                          status.type === 'high' ? 'bg-orange-500' : 'bg-red-500'
                        }`}
                        style={{ width: `${Math.min(100, item.density * 15)}%` }}
                      />
                    </div>
                  </div>

                  {/* Status Indicator Pill */}
                  <div className="flex items-center justify-between gap-2 text-[9px] pt-1 border-t border-border-main/30">
                    <span className="opacity-70">{lang === 'ar' ? 'تقييم سيو:' : 'SEO Assessment:'}</span>
                    <span className={`px-2 py-0.5 rounded-md font-bold ${status.color}`}>
                      {lang === 'ar' ? status.labelAr : status.labelEn}
                    </span>
                  </div>

                  {/* Custom tip */}
                  <div className="hidden group-hover:block p-1.5 bg-card border border-border-main text-[9px] text-text-main/80 rounded-lg absolute inset-x-2 bottom-2 shadow-md animate-slideUp z-10">
                    {lang === 'ar' ? status.tipAr : status.tipEn}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Section 2: Real-time Word Frequency List & Filter */}
      <div className="space-y-3 bg-card p-4 rounded-2xl border border-border-main/75 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-border-main/50 pb-3">
          <div className="flex items-center gap-1.5 justify-start">
            <FileText size={14} className="text-emerald-500" />
            <span className="text-[11px] font-black text-text-main">
              {lang === 'ar' ? 'جدول توزيع تردد وكثافة الكلمات الكلي' : 'All Word Frequency Distribution Table'}
            </span>
          </div>

          {/* Toggle and Search filters */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Filter Stop words checkbox */}
            <label className="flex items-center gap-1.5 cursor-pointer text-[10px] font-semibold select-none bg-bg hover:bg-border-main/30 py-1.5 px-2.5 rounded-lg border border-border-main">
              <input
                type="checkbox"
                checked={filterStopWords}
                onChange={(e) => setFilterStopWords(e.target.checked)}
                className="accent-primary w-3 h-3 rounded"
              />
              <span>{lang === 'ar' ? 'تصفية كلمات الربط الشائعة' : 'Ignore Stop Words'}</span>
            </label>

            {/* Search Box */}
            <div className="relative flex items-center">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder={lang === 'ar' ? 'ابحث عن كلمة...' : 'Search word...'}
                className="text-[10px] p-1.5 pr-6 w-32 rounded-lg border border-border-main bg-bg text-text-main focus:outline-none focus:border-primary font-medium"
              />
              <Search size={10} className="absolute right-2 text-text-main opacity-50" />
            </div>
          </div>
        </div>

        {/* Word density results table */}
        {totalWordsCount === 0 ? (
          <div className="text-center py-10 text-[11px] opacity-60 bg-bg rounded-xl border border-dashed border-border-main">
            {lang === 'ar' ? 'الرجاء كتابة أو توليد بعض النصوص للبدء في الفحص والتحليل.' : 'No text content detected for analysis.'}
          </div>
        ) : filteredKeywordStats.length === 0 ? (
          <div className="text-center py-8 text-[10px] opacity-60">
            {lang === 'ar' ? 'لا توجد كلمات مطابقة لبحثك.' : 'No matching words found.'}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <div className="max-h-64 overflow-y-auto border border-border-main rounded-xl">
              <table className="w-full text-right text-[11px] border-collapse">
                <thead className="bg-bg text-text-main opacity-80 sticky top-0 font-black border-b border-border-main shadow-xs">
                  <tr>
                    <th className="p-2 border-l border-border-main">{lang === 'ar' ? 'الترتيب' : 'Rank'}</th>
                    <th className="p-2 border-l border-border-main">{lang === 'ar' ? 'الكلمة' : 'Word'}</th>
                    <th className="p-2 border-l border-border-main text-center">{lang === 'ar' ? 'التكرار (مرة)' : 'Frequency'}</th>
                    <th className="p-2 border-l border-border-main text-center">{lang === 'ar' ? 'الكثافة %' : 'Density %'}</th>
                    <th className="p-2 text-center">{lang === 'ar' ? 'مستوى السيو' : 'SEO Level'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border-main/50">
                  {filteredKeywordStats.map((stat, idx) => {
                    const status = getDensityStatus(stat.density);
                    return (
                      <tr key={idx} className="hover:bg-bg/40 transition">
                        <td className="p-2 text-text-main/50 font-mono border-l border-border-main/50 font-medium">#{idx + 1}</td>
                        <td className="p-2 font-bold text-text-main border-l border-border-main/50">{stat.word}</td>
                        <td className="p-2 text-center font-semibold text-text-main/90 border-l border-border-main/50">{stat.count}</td>
                        <td className="p-2 text-center font-mono font-bold text-primary border-l border-border-main/50">{stat.density.toFixed(2)}%</td>
                        <td className="p-2">
                          <div className="flex items-center justify-center">
                            <span className={`px-2 py-0.5 rounded-full text-[9px] font-black text-center ${status.color}`}>
                              {lang === 'ar' ? status.labelAr.split(' ')[0] : status.labelEn}
                            </span>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Section 3: Smart SEO Tips & Guidelines Card */}
      <div className="p-3.5 bg-indigo-500/5 border border-indigo-500/20 rounded-2xl space-y-2">
        <div className="flex items-center gap-1 text-indigo-500 font-black text-xs">
          <HelpCircle size={14} />
          <span>{lang === 'ar' ? 'إرشادات السيو المثالي لكثافة الكلمات الدلالية' : 'SEO Keyword Density Guidelines'}</span>
        </div>
        <ul className="space-y-1 text-[10px] text-text-main/80 list-disc pr-4 text-right leading-relaxed">
          <li>
            {lang === 'ar'
              ? 'النسبة المثالية لأي كلمة دلالية رئيسية في موقعك هي بين 1% و 3% لتتفادى غرامات جوجل للحشو المفرط.'
              : 'Ideal density for core keywords should fall between 1% and 3.5% to trigger correct signals.'}
          </li>
          <li>
            {lang === 'ar'
              ? 'احرص على إدراج كلماتك الأساسية في العناوين الكبيرة (H1, H2) وأسماء المتاجر والفقرات الأولى للموقع.'
              : 'Include your high-priority keyword in the top title and the first paragraph of your home text.'}
          </li>
          <li>
            {lang === 'ar'
              ? 'ملف الـ sitemap و robots.txt التي تصدرها من الأعلى تكمل عمل الكلمات الدلالية لتسهيل فهرسة موقعك.'
              : 'Sitemap.xml and robots.txt compiled above integrate with content keyword indexes to boost authority.'}
          </li>
        </ul>
      </div>

    </div>
  );
}
