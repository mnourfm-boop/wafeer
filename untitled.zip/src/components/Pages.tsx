import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Shield, 
  Info, 
  Mail, 
  Phone, 
  MapPin, 
  Send, 
  CheckCircle2, 
  Clock, 
  Globe, 
  Sparkles, 
  Heart,
  ExternalLink,
  MessageCircle
} from 'lucide-react';

interface PagesProps {
  lang: 'ar' | 'en';
}

// ==========================================
// 1. PRIVACY POLICY PAGE (سياسة الخصوصية)
// ==========================================
export const PrivacyPolicyPage: React.FC<PagesProps> = ({ lang }) => {
  const isAr = lang === 'ar';

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      className="max-w-4xl mx-auto my-8 p-6 md:p-10 bg-card rounded-3xl border border-border-main shadow-xl transition-all duration-300"
      dir={isAr ? 'rtl' : 'ltr'}
    >
      <div className="flex items-center gap-4 mb-8 pb-4 border-b border-border-main">
        <div className="p-3 bg-primary/10 text-primary rounded-2xl">
          <Shield size={32} />
        </div>
        <div>
          <h1 className="text-2xl md:text-3xl font-black text-text-main">
            {isAr ? 'سياسة الخصوصية وسرية المعلومات' : 'Privacy Policy & Data Security'}
          </h1>
          <p className="text-xs text-text-main opacity-60 mt-1">
            {isAr ? 'آخر تحديث: يوليو 2026' : 'Last Updated: July 2026'}
          </p>
        </div>
      </div>

      <div className="space-y-8 text-sm md:text-base leading-relaxed text-text-main/90">
        <section className="space-y-3">
          <h3 className="text-lg font-extrabold text-primary flex items-center gap-2">
            <span>1.</span>
            {isAr ? 'جمع المعلومات والبيانات' : 'Information Collection'}
          </h3>
          <p className="text-xs md:text-sm opacity-80">
            {isAr ? 
              'نحن في منصة وفير نولي خصوصية زوارنا أهمية بالغة. لا نقوم بجمع أي معلومات شخصية تحدد هويتك عند تصفحك للموقع، باستثناء البيانات التي تختار تزويدنا بها طواعية (مثل الاسم والبريد الإلكتروني عند تعبئة نموذج اتصل بنا).' : 
              'At Wafeer, we treat your privacy with utmost importance. We do not collect any personally identifiable information when you browse our site, except for the details you voluntarily provide (e.g., name and email when submitting the contact form).'}
          </p>
        </section>

        <section className="space-y-3">
          <h3 className="text-lg font-extrabold text-primary flex items-center gap-2">
            <span>2.</span>
            {isAr ? 'ملفات تعريف الارتباط (Cookies)' : 'Cookies & Tracking'}
          </h3>
          <p className="text-xs md:text-sm opacity-80">
            {isAr ? 
              'نستخدم ملفات تعريف الارتباط لتحسين تجربة التصفح وحفظ تفضيلاتك (مثل حفظ اللغة المفضلة والمتاجر التي قمت بنسخ أكوادها). كما قد نستخدم خدمات تحليلية من طرف ثالث مثل Google Analytics لفهم كيفية تفاعل الزوار مع الموقع وتطوير الأداء باستمرار.' : 
              'We use cookies to enhance your browsing experience and save your preferences (like your preferred language or stores you copied coupons from). We also use third-party analytics services like Google Analytics to understand visitor interactions and improve performance.'}
          </p>
        </section>

        <section className="space-y-3">
          <h3 className="text-lg font-extrabold text-primary flex items-center gap-2">
            <span>3.</span>
            {isAr ? 'إعلانات جوجل أدسنس (Google AdSense)' : 'Google AdSense Advertising'}
          </h3>
          <p className="text-xs md:text-sm opacity-80">
            {isAr ? 
              'يستخدم موقعنا إعلانات جوجل أدسنس لعرض الإعلانات المخصصة للزوار. تستخدم جوجل ملف تعريف الارتباط DART لعرض الإعلانات بناءً على زياراتك لموقعنا والمواقع الأخرى على الإنترنت. يمكنك إلغاء استخدام هذا الملف من خلال زيارة سياسة خصوصية شبكة إعلانات جوجل ومحتواها.' : 
              'Our website displays advertisements via Google AdSense. Google uses the DART cookie to serve personalized ads based on your visits to our site and other internet portals. You can opt out of using the DART cookie by visiting Google Ad & Content Network privacy guidelines.'}
          </p>
        </section>

        <section className="space-y-3">
          <h3 className="text-lg font-extrabold text-primary flex items-center gap-2">
            <span>4.</span>
            {isAr ? 'روابط المتاجر الخارجية (Affiliate Links)' : 'External Store Links (Affiliates)'}
          </h3>
          <p className="text-xs md:text-sm opacity-80">
            {isAr ? 
              'يحتوي موقعنا على روابط إحالة خارجية تؤدي إلى المتاجر الشريكة (مثل نون، نمشي، أمازون وغيرها). عند النقر على هذه الروابط والشراء، قد نتلقى عمولة بسيطة دون أي تكلفة إضافية عليك. نرجو العلم أن هذه المواقع الخارجية لها سياسات خصوصية مستقلة تماماً، ولا نتحمل أي مسؤولية عن محتواها أو ممارساتها.' : 
              'Our website contains affiliate and referral links pointing to partner stores (like Noon, Namshi, Amazon, etc.). When clicking these links and completing a purchase, we may receive a small commission at zero extra cost to you. Please note that these external merchant platforms operate under their own independent privacy guidelines.'}
          </p>
        </section>

        <section className="space-y-3">
          <h3 className="text-lg font-extrabold text-primary flex items-center gap-2">
            <span>5.</span>
            {isAr ? 'أمن وحماية البيانات' : 'Data Security & Protection'}
          </h3>
          <p className="text-xs md:text-sm opacity-80">
            {isAr ? 
              'نطبق معايير أمنية عالية لحماية بياناتك من الوصول غير المصرح به أو التعديل أو الإفصاح. نتأكد دائماً من تشفير الاتصال بالكامل باستخدام بروتوكول HTTPS الآمن لضمان سرية البيانات أثناء نقلها.' : 
              'We employ industry-standard security practices to protect your data from unauthorized access, alteration, or disclosure. All connections are fully encrypted using the HTTPS protocol to guarantee strict data transmission confidentiality.'}
          </p>
        </section>

        <section className="space-y-3">
          <h3 className="text-lg font-extrabold text-primary flex items-center gap-2">
            <span>6.</span>
            {isAr ? 'الموافقة على الشروط' : 'Consent to Terms'}
          </h3>
          <p className="text-xs md:text-sm opacity-80">
            {isAr ? 
              'باستخدامك لمنصتنا، فإنك توافق على سياسة الخصوصية الخاصة بنا وشروط الاستخدام المذكورة. إذا كانت لديك أي استفسارات بخصوص هذه السياسة، يمكنك التواصل معنا مباشرة عبر صفحة اتصل بنا.' : 
              'By utilizing our platform, you hereby consent to our Privacy Policy and agree to its terms. If you have any inquiries regarding this policy, feel free to contact us via our Contact Page.'}
          </p>
        </section>
      </div>
    </motion.div>
  );
};

// ==========================================
// 2. ABOUT US PAGE (من نحن)
// ==========================================
export const AboutUsPage: React.FC<PagesProps> = ({ lang }) => {
  const isAr = lang === 'ar';

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      className="max-w-4xl mx-auto my-8 p-6 md:p-10 bg-card rounded-3xl border border-border-main shadow-xl transition-all duration-300 space-y-10"
      dir={isAr ? 'rtl' : 'ltr'}
    >
      <div className="flex items-center gap-4 pb-4 border-b border-border-main">
        <div className="p-3 bg-primary/10 text-primary rounded-2xl">
          <Info size={32} />
        </div>
        <div>
          <h1 className="text-2xl md:text-3xl font-black text-text-main">
            {isAr ? 'من نحن - منصة وفير' : 'About Us - Wafeer'}
          </h1>
          <p className="text-xs text-text-main opacity-60 mt-1">
            {isAr ? 'المنصة العربية الأسهل لتوفير المال عند التسوق الذكي' : 'The easiest Arab platform to save cash while shopping smartly'}
          </p>
        </div>
      </div>

      {/* Main Grid Intro */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        <div className="space-y-4">
          <h2 className="text-xl font-black text-text-main flex items-center gap-2">
            <Sparkles size={20} className="text-yellow-500 animate-pulse" />
            <span>{isAr ? 'رؤيتنا وقصتنا' : 'Our Vision & Story'}</span>
          </h2>
          <p className="text-xs md:text-sm leading-relaxed text-text-main/80">
            {isAr ? 
              'تأسست منصة وفير برؤية واضحة تهدف إلى تمكين المستهلك العربي ومساعدته على توفير أمواله عند التسوق عبر الإنترنت. ندرك تماماً مدى صعوبة البحث عن كود خصم فعال وحقيقي وسط مئات الأكواد المنتهية أو غير الفعالة، ولهذا قمنا ببناء هذه المنصة الذكية.' : 
              'Wafeer was founded with a clear vision to empower Arab consumers and help them save money while shopping online. We understand how exhausting it is to search for a working, valid coupon code amid hundreds of expired or useless vouchers, which is why we built this smart tool.'}
          </p>
          <p className="text-xs md:text-sm leading-relaxed text-text-main/80">
            {isAr ? 
              'نقوم في وفير بالتحقق اليومي والمستمر من فاعلية الكوبونات وتحديثها لحظة بلحظة، لنقدم لكم تجربة نسخ فائقة السرعة مع حاسبة ذكية لمعرفة التوفير قبل الذهاب للمتجر.' : 
              'At Wafeer, we perform daily verifications of coupon codes to guarantee their functionality, providing you with ultra-fast copy experience and an integrated smart calculator to preview your savings.'}
          </p>
        </div>
        <div className="p-6 bg-primary/5 rounded-3xl border border-primary/10 flex flex-col justify-center items-center text-center space-y-3">
          <div className="text-4xl">🎯</div>
          <h3 className="font-extrabold text-sm text-primary">{isAr ? 'مهمتنا الأسمى' : 'Our Mission'}</h3>
          <p className="text-xs text-text-main/80 leading-relaxed">
            {isAr ? 
              'تبسيط وتسهيل عملية التسوق الموفر وتوفير الجهد والمال لكل متسوق في السعودية، الإمارات، الكويت وباقي دول الخليج والوطن العربي مجاناً بالكامل.' : 
              'Simplifying the thrifty shopping workflow and saving time and cash for every online shopper across Saudi Arabia, UAE, Kuwait, and the wider Arab world 100% free.'}
          </p>
        </div>
      </div>

      {/* Principles / Values */}
      <div className="space-y-6 pt-4 border-t border-border-main">
        <h2 className="text-lg font-black text-text-main">{isAr ? 'ما الذي يجعلنا متميزين؟' : 'What Makes Us Stand Out?'}</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="p-5 bg-bg rounded-2xl border border-border-main space-y-2">
            <div className="text-2xl">⚡</div>
            <h4 className="font-bold text-xs text-text-main">{isAr ? 'تحديث لحظي وفوري' : 'Real-time Updates'}</h4>
            <p className="text-[11px] text-text-main/70 leading-relaxed">
              {isAr ? 'يتم مراجعة الكوبونات وتحديث العروض على مدار الساعة لضمان فعاليتها التامة عند الشراء.' : 'Our coupons are audited and updated 24/7 to guarantee absolute validity at the checkout stage.'}
            </p>
          </div>
          <div className="p-5 bg-bg rounded-2xl border border-border-main space-y-2">
            <div className="text-2xl">🤝</div>
            <h4 className="font-bold text-xs text-text-main">{isAr ? 'شفافية وموثوقية' : 'Transparency & Trust'}</h4>
            <p className="text-[11px] text-text-main/70 leading-relaxed">
              {isAr ? 'لا ندرج إلا أكواداً حقيقية مجربة تمنحك الخصم المعلن عنه بكل مصداقية وبدون تلاعب.' : 'We only display genuine, verified coupon codes that provide the exact declared discount honestly.'}
            </p>
          </div>
          <div className="p-5 bg-bg rounded-2xl border border-border-main space-y-2">
            <div className="text-2xl">💖</div>
            <h4 className="font-bold text-xs text-text-main">{isAr ? 'مجتمعي مئة بالمئة' : '100% Community Centric'}</h4>
            <p className="text-[11px] text-text-main/70 leading-relaxed">
              {isAr ? 'نمتلك مجتمعات تفاعلية في الواتساب ووسائل التواصل لإبلاغك فوراً بالكوبونات السريعة والمحدودة.' : 'We host highly active WhatsApp & social groups to alert you instantly as soon as short-lived deals launch.'}
            </p>
          </div>
        </div>
      </div>

      {/* Heartfelt message */}
      <div className="p-6 bg-gradient-to-r from-primary/10 to-primary-hover/5 rounded-3xl border border-primary/10 flex items-center gap-4 text-xs md:text-sm leading-relaxed text-text-main">
        <Heart className="text-red-500 fill-red-500 animate-pulse flex-shrink-0" size={24} />
        <div>
          <span className="font-bold">{isAr ? 'شكر خاص لزوارنا الكرام: ' : 'A special thank you to our visitors: '}</span>
          {isAr ? 
            'شكراً لثقتكم المستمرة بنا واستخدامكم لمنصتنا. نعدكم بمواصلة التطوير وتقديم أفضل العروض والكوبونات دائماً لجعل تسوقكم تجربة ممتعة وموفرة للحد الأقصى.' : 
            'Thank you for your continuous trust in our platform. We promise to keep developing and adding top-tier deals to make your online shopping experience exceptionally enjoyable.'}
        </div>
      </div>
    </motion.div>
  );
};

// ==========================================
// 3. CONTACT US PAGE (اتصل بنا)
// ==========================================
interface ContactUsProps {
  lang: 'ar' | 'en';
  pushNotification: (type: 'coupon' | 'deal' | 'article', titleAr: string, titleEn: string) => void;
  onAddMessage: (msg: any) => void;
  contactBannerUrl?: string;
  contactLogoUrl?: string;
  contactEmail?: string;
}

export const ContactUsPage: React.FC<ContactUsProps> = ({ 
  lang, 
  pushNotification, 
  onAddMessage,
  contactBannerUrl = 'https://images.unsplash.com/photo-1616077168712-fc6c788bc4ee?q=80&w=1200&auto=format&fit=crop',
  contactLogoUrl = 'https://cdn.jsdelivr.net/gh/microsoft/fluentui-emoji@main/assets/Money%20bag/3D/money_bag_3d.png',
  contactEmail = 'mnour.fm@gmail.com'
}) => {
  const isAr = lang === 'ar';
  
  // Form state
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.email.trim() || !formData.message.trim()) {
      setError(isAr ? 'يرجى ملء جميع الحقول المطلوبة الأساسية.' : 'Please fill out all required fields.');
      return;
    }

    setSubmitting(true);
    setError('');

    setTimeout(() => {
      const newMsg = {
        id: Date.now(),
        name: formData.name,
        email: formData.email,
        subject: formData.subject || (isAr ? 'رسالة تواصل عامة' : 'General Contact'),
        message: formData.message,
        date: new Date().toISOString().replace('T', ' ').substring(0, 16)
      };

      // Callback to add message to parent visitorMessages state
      onAddMessage(newMsg);

      // Trigger standard AI system push notification toast
      pushNotification(
        'deal', 
        `✉️ رسالة جديدة من الزائر: ${formData.name}`, 
        `✉️ New visitor message from: ${formData.name}`
      );

      setSuccess(true);
      setSubmitting(false);
      setFormData({ name: '', email: '', subject: '', message: '' });
    }, 1200);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      className="max-w-5xl mx-auto my-8 bg-card rounded-3xl border border-border-main shadow-xl transition-all duration-300 overflow-hidden"
      dir={isAr ? 'rtl' : 'ltr'}
    >
      {/* Brand Cover Banner */}
      <div className="relative h-48 sm:h-56 md:h-64 w-full bg-slate-900 overflow-hidden">
        <img 
          src={contactBannerUrl} 
          alt="Contact Page Cover Banner" 
          className="w-full h-full object-cover opacity-80 select-none"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent" />
        
        {/* Profile Branding overlap */}
        <div className="absolute bottom-5 left-5 right-5 flex flex-row items-end gap-4">
          <div className="w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24 rounded-2xl bg-white dark:bg-slate-900 border-4 border-card p-2 shadow-lg flex items-center justify-center shrink-0 overflow-hidden">
            <img 
              src={contactLogoUrl} 
              alt="Brand Logo" 
              className="max-w-full max-h-full object-contain"
              referrerPolicy="no-referrer"
              onError={(e) => {
                (e.target as HTMLImageElement).src = 'https://cdn.jsdelivr.net/gh/microsoft/fluentui-emoji@main/assets/Money%20bag/3D/money_bag_3d.png';
              }}
            />
          </div>
          <div className="mb-0.5 text-white">
            <h1 className="text-lg sm:text-xl md:text-3xl font-black tracking-tight drop-shadow-md">
              {isAr ? 'اتصل بنا / اتصل بنظام التوفير' : 'Contact Us'}
            </h1>
            <p className="text-[10px] sm:text-xs md:text-sm text-slate-200/95 font-medium drop-shadow-sm mt-0.5">
              {isAr ? 'يسعدنا دائماً تلقي استفساراتكم واقتراحاتكم لتطوير الخدمة' : 'We are always happy to receive your inquiries and feedback'}
            </p>
          </div>
        </div>
      </div>

      <div className="p-6 md:p-10">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
        {/* Left column: Contact Info (2 cols) */}
        <div className="lg:col-span-2 space-y-6">
          <div className="p-6 bg-bg rounded-2xl border border-border-main space-y-4">
            <h3 className="font-extrabold text-sm text-primary uppercase tracking-wider">{isAr ? 'معلومات التواصل المباشر' : 'Direct Contact Info'}</h3>
            <p className="text-xs text-text-main/70 leading-relaxed">
              {isAr ? 
                'إذا كان لديك متجر إلكتروني وتريد إضافة كود خصم خاص بك، أو تود الإبلاغ عن كود معطل، يسعدنا تواصلك الفوري معنا.' : 
                'If you own an e-commerce brand and want to list your discount code, or want to report a broken voucher, feel free to contact us.'}
            </p>

            <ul className="space-y-4 pt-2">
              <li className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Mail size={16} />
                </div>
                <div>
                  <div className="text-[10px] font-black opacity-60 uppercase">{isAr ? 'البريد الإلكتروني' : 'EMAIL ADDRESS'}</div>
                  <a href={`mailto:${contactEmail}`} className="text-xs font-bold hover:text-primary hover:underline transition">
                    {contactEmail}
                  </a>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-[#25D366]/10 text-[#25D366] flex items-center justify-center flex-shrink-0 mt-0.5">
                  <MessageCircle size={16} />
                </div>
                <div>
                  <div className="text-[10px] font-black opacity-60 uppercase">{isAr ? 'جروب الواتساب الرسمي' : 'OFFICIAL WHATSAPP'}</div>
                  <a href="https://chat.whatsapp.com/your-group-link" target="_blank" rel="noreferrer" className="text-xs font-bold hover:text-[#25D366] hover:underline transition">
                    {isAr ? 'انضم للمجتمع الآن ⚡' : 'Join Community Now ⚡'}
                  </a>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center flex-shrink-0 mt-0.5">
                  <MapPin size={16} />
                </div>
                <div>
                  <div className="text-[10px] font-black opacity-60 uppercase">{isAr ? 'المقر الرئيسي' : 'HEADQUARTERS'}</div>
                  <span className="text-xs font-bold text-text-main/80">
                    {isAr ? 'الرياض، المملكة العربية السعودية' : 'Riyadh, Saudi Arabia'}
                  </span>
                </div>
              </li>
            </ul>
          </div>

          {/* Interactive simulated Vector Map block */}
          <div className="relative h-48 rounded-2xl border border-border-main overflow-hidden bg-primary/5 group flex items-center justify-center text-center p-4">
            <div className="absolute inset-0 bg-cover bg-center filter opacity-20 group-hover:scale-105 transition-all duration-700 select-none pointer-events-none" 
                 style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1524661135-423995f22d0b?q=80&w=400&auto=format&fit=crop")' }} />
            <div className="relative z-10 space-y-2">
              <MapPin className="text-primary mx-auto animate-bounce" size={28} />
              <h4 className="font-extrabold text-xs text-text-main">{isAr ? 'الرياض - شارع العليا' : 'Olaya St, Riyadh'}</h4>
              <p className="text-[10px] text-text-main/60 max-w-xs mx-auto">{isAr ? 'جوجل مابس والزحف البرمجي نشط لأرشفة سيو دقيقة' : 'Geographical coordinates optimized for local SEO markup.'}</p>
            </div>
            <div className="absolute bottom-2 left-2 right-2 bg-black/60 backdrop-blur-sm py-1.5 px-3 rounded-lg text-white text-[9px] font-black tracking-widest text-center">
              {isAr ? '📍 خريطة تفاعلية نشطة' : '📍 ACTIVE LOCAL MAP'}
            </div>
          </div>
        </div>

        {/* Right column: Form (3 cols) */}
        <div className="lg:col-span-3">
          {success ? (
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="p-8 bg-primary/5 border border-primary/20 rounded-3xl text-center space-y-4 flex flex-col justify-center items-center h-full"
            >
              <div className="w-16 h-16 rounded-full bg-primary/10 text-primary flex items-center justify-center animate-bounce">
                <CheckCircle2 size={36} />
              </div>
              <h3 className="text-lg font-black text-primary">
                {isAr ? 'تم إرسال رسالتك بنجاح!' : 'Your message has been sent!'}
              </h3>
              <p className="text-xs text-text-main opacity-80 max-w-sm leading-relaxed">
                {isAr ? 
                  'شكراً لتواصلك معنا. تم استلام الرسالة وحفظها في قاعدة بيانات الموقع وسيقوم فريق وفير بمراجعتها والرد عليك عبر بريدك الإلكتروني قريباً.' : 
                  'Thank you for contacting us. Your message has been safely saved, and the Wafeer support team will get back to you via email very soon.'}
              </p>
              <button 
                onClick={() => setSuccess(false)}
                className="mt-2 text-xs bg-primary text-white font-bold py-2.5 px-5 rounded-xl hover:opacity-90 transition active:scale-95 cursor-pointer shadow-sm"
              >
                {isAr ? 'إرسال رسالة جديدة' : 'Send another message'}
              </button>
            </motion.div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-text-main/80 flex items-center gap-1">
                    <span>{isAr ? 'الاسم الكامل *' : 'Full Name *'}</span>
                  </label>
                  <input 
                    type="text" 
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder={isAr ? 'مثال: محمد أحمد' : 'e.g. John Doe'}
                    className="w-full bg-bg border border-border-main p-3 rounded-xl text-xs font-medium focus:border-primary focus:outline-none transition-colors"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-text-main/80 flex items-center gap-1">
                    <span>{isAr ? 'البريد الإلكتروني *' : 'Email Address *'}</span>
                  </label>
                  <input 
                    type="email" 
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="example@mail.com"
                    className="w-full bg-bg border border-border-main p-3 rounded-xl text-xs font-medium focus:border-primary focus:outline-none transition-colors"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-text-main/80">
                  {isAr ? 'موضوع الرسالة (اختياري)' : 'Subject (Optional)'}
                </label>
                <input 
                  type="text" 
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  placeholder={isAr ? 'مثال: اقتراح إضافة متجر، بلاغ عن كود منتهي' : 'e.g. Store collaboration, broken link report'}
                  className="w-full bg-bg border border-border-main p-3 rounded-xl text-xs font-medium focus:border-primary focus:outline-none transition-colors"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-text-main/80">
                  {isAr ? 'نص الرسالة *' : 'Message Content *'}
                </label>
                <textarea 
                  required
                  rows={5}
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder={isAr ? 'اكتب رسالتك أو استفسارك هنا بكل وضوح...' : 'Write your detailed inquiry here...'}
                  className="w-full bg-bg border border-border-main p-3 rounded-xl text-xs font-medium focus:border-primary focus:outline-none transition-colors resize-none"
                />
              </div>

              {error && (
                <div className="p-3 bg-red-500/10 border border-red-500/20 text-red-500 text-xs rounded-xl font-bold">
                  ⚠️ {error}
                </div>
              )}

              <button 
                type="submit"
                disabled={submitting}
                className="w-full bg-primary hover:bg-primary-hover text-white text-xs font-bold py-3 px-4 rounded-xl shadow-md transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {submitting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>{isAr ? 'جاري الإرسال وحفظ البيانات...' : 'Sending message...'}</span>
                  </>
                ) : (
                  <>
                    <Send size={14} />
                    <span>{isAr ? 'إرسال الرسالة الآن' : 'Send Message Now'}</span>
                  </>
                )}
              </button>
            </form>
          )}
        </div>
      </div>
      </div>
    </motion.div>
  );
};
